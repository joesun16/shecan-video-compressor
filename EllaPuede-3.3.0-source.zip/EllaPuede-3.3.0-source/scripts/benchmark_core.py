#!/usr/bin/env python3
"""Compare the real compression worker against a saved source ZIP at identical quality.

Example:
  ELLAPUEDE_FFMPEG_DIR=/opt/homebrew/bin python scripts/benchmark_core.py \
    --baseline /path/EllaPuede-3.2.1-source.zip --report /tmp/benchmark.json

Uses synthetic testsrc2 clips, records actual pool size and output SSIM, and removes
intermediate videos on exit. Results apply only to the tested OS and encoder.
"""
import argparse
from concurrent.futures import ThreadPoolExecutor
import hashlib
import importlib.util
import json
import logging
import os
from pathlib import Path
import platform
import re
import shutil
import statistics
import subprocess
import sys
import tempfile
import time
import types
import zipfile

ROOT = Path(__file__).resolve().parents[1]


def run_command(command):
    result = subprocess.run(command, stdin=subprocess.DEVNULL, capture_output=True,
                            text=True, encoding='utf-8', errors='replace', timeout=120)
    if result.returncode:
        raise RuntimeError(result.stderr[-2000:])
    return result


def import_sources(archive):
    with zipfile.ZipFile(archive) as package:
        source_name = next(name for name in package.namelist() if name.endswith('/video_compressor.py') or name == 'video_compressor.py')
        old_source = package.read(source_name).decode('utf-8')
    baseline = types.ModuleType('ellapuede_benchmark_baseline')
    baseline.__file__ = str(ROOT / 'video_compressor.py')
    sys.modules[baseline.__name__] = baseline
    exec(compile(old_source, f'{archive}!/{source_name}', 'exec'), baseline.__dict__)
    spec = importlib.util.spec_from_file_location('ellapuede_benchmark_current', ROOT / 'video_compressor.py')
    current = importlib.util.module_from_spec(spec)
    sys.modules[current.__name__] = current
    spec.loader.exec_module(current)
    for module in (baseline, current):
        module.logger.setLevel(logging.ERROR)
    return baseline, current, hashlib.sha256(old_source.encode()).hexdigest()


def measure(module, files, directory, resolution, encoder_key):
    actual_pool_sizes = []
    class MeasuredExecutor(ThreadPoolExecutor):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            actual_pool_sizes.append(self._max_workers)
    previous_executor = module.ThreadPoolExecutor
    module.ThreadPoolExecutor = MeasuredExecutor
    # Simulate metadata already populated in the file list. The old worker still
    # probes each source again; the new worker can reuse that immutable metadata.
    for file in files:
        module.probe_video_info(file['path'])
    worker = module.CompressionWorker(files, dict(
        encoder_key=encoder_key, quality_key='balanced', speed_key='fast',
        resolution=resolution, parallel=8, output_dir=str(directory), keep_larger=True))
    start = time.perf_counter()
    try:
        worker.run()
    finally:
        module.ThreadPoolExecutor = previous_executor
    elapsed = time.perf_counter() - start
    if len(worker.results) != len(files) or any(item['status'] != 'success' for item in worker.results.values()):
        raise RuntimeError(f'Batch did not complete: {worker.results}')
    first_output = worker.results[0]['output_path']
    output_info = module.probe_video_info(first_output)
    return dict(seconds=round(elapsed, 4), actual_parallel=actual_pool_sizes[0],
                peak_ffmpeg=getattr(worker, 'peak_parallel_processes', None),
                actual_encoders=sorted({item['encoder_key'] for item in worker.results.values()}),
                fallback_count=sum(item.get('fallback_used', False) for item in worker.results.values()),
                output_bytes=sum(item['output_size'] for item in worker.results.values()),
                width=output_info['width'], height=output_info['height'],
                output_path=first_output)


def score_output(ffmpeg, source, output, width, height):
    # Compare against the source at the same final resolution. Scale quality is
    # held at Lanczos for both versions; this check is one representative clip.
    filt = f'[0:v]scale={width}:{height}:flags=lanczos,setsar=1[ref];[ref][1:v]ssim'
    result = run_command([ffmpeg, '-hide_banner', '-nostdin', '-i', str(source), '-i', output,
                          '-lavfi', filt, '-an', '-f', 'null', '-'])
    found = re.findall(r'All:([0-9.]+)', result.stderr)
    if not found:
        raise RuntimeError('SSIM score was not reported')
    return float(found[-1])


def verify_filter_pixels(ffmpeg, current):
    checks = []
    for pixel_format in ('yuv420p', 'nv12'):
        hashes = []
        for filtered in (True, False):
            command = [ffmpeg, '-hide_banner', '-loglevel', 'error', '-nostdin',
                       '-f', 'lavfi', '-i', f'testsrc2=size=640x360:rate=24:duration=0.5,format={pixel_format}']
            if filtered:
                command += ['-vf', current.build_scale_filter()]
            command += ['-pix_fmt', 'yuv420p', '-c:v', 'rawvideo', '-f', 'framemd5', '-']
            result = run_command(command)
            frame_lines = [line for line in result.stdout.splitlines() if line and not line.startswith('#')]
            hashes.append(frame_lines)
        if hashes[0] != hashes[1]:
            raise AssertionError(f'Skipping scale changed decoded pixels for {pixel_format}')
        checks.append(dict(source_pixel_format=pixel_format, identical_frames=len(hashes[0])))
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    parser.add_argument('--seconds', type=int, default=4)
    parser.add_argument('--repeat', type=int, default=2)
    parser.add_argument('--encoder', choices=['cpu_h264', 'apple_h264'], default='cpu_h264')
    parser.add_argument('--scenario', choices=['both', 'original_size', 'downscale_1080_to_720'], default='both')
    args = parser.parse_args()
    os.environ['QT_QPA_PLATFORM'] = 'offscreen'
    with tempfile.TemporaryDirectory(prefix='ellapuede-benchmark-') as temporary:
        workspace = Path(temporary)
        os.environ['ELLAPUEDE_DATA_DIR'] = str(workspace / 'config')
        baseline, current, baseline_hash = import_sources(args.baseline)
        ffmpeg = current.get_ffmpeg_path()
        report = dict(platform=platform.platform(), machine=platform.machine(),
                      logical_cpus=os.cpu_count(), baseline_version=baseline.VERSION,
                      current_version=current.VERSION, baseline_source_sha256=baseline_hash,
                      ffmpeg=run_command([ffmpeg, '-version']).stdout.splitlines()[0],
                      settings=dict(encoder_key=args.encoder, quality='balanced', speed='fast', requested_parallel=8,
                                    files=8, source_seconds=args.seconds, fps=30, repetitions=args.repeat),
                      filter_pixel_equivalence=verify_filter_pixels(ffmpeg, current),
                      scenarios={}, note='Synthetic local benchmark; SSIM is one representative file per batch. No native Windows claim. Fallbacks invalidate like-for-like GPU comparisons.')
        for scenario, size, resolution in [('original_size', '1280x720', None), ('downscale_1080_to_720', '1920x1080', 720)]:
            if args.scenario != 'both' and scenario != args.scenario:
                continue
            source = workspace / f'{scenario}-source.mp4'
            run_command([ffmpeg, '-hide_banner', '-loglevel', 'error', '-nostdin',
                         '-f', 'lavfi', '-i', f'testsrc2=size={size}:rate=30:duration={args.seconds}',
                         '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '12', '-pix_fmt', 'yuv420p',
                         '-threads', '4', '-y', str(source)])
            files = []
            for index in range(8):
                path = workspace / f'{scenario}-{index}.mp4'
                shutil.copyfile(source, path)
                files.append(dict(path=str(path), name=path.name, size=path.stat().st_size))
            samples = {'baseline': [], 'current': []}
            for iteration in range(args.repeat):
                order = [('baseline', baseline), ('current', current)]
                if iteration % 2:
                    order.reverse()
                for label, module in order:
                    sample = measure(module, files, workspace / f'{scenario}-{label}-{iteration}', resolution, args.encoder)
                    output = sample.pop('output_path')
                    sample['ssim_representative'] = score_output(ffmpeg, source, output, sample['width'], sample['height'])
                    samples[label].append(sample)
                    print(json.dumps(dict(scenario=scenario, implementation=label, sample=sample)), flush=True)
            old = statistics.median(item['seconds'] for item in samples['baseline'])
            new = statistics.median(item['seconds'] for item in samples['current'])
            report['scenarios'][scenario] = dict(samples=samples, baseline_median_seconds=round(old, 4),
                                                 current_median_seconds=round(new, 4),
                                                 time_reduction_percent=round((old - new) / old * 100, 2),
                                                 throughput_ratio=round(old / new, 3))
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf-8')
        print(f'Report saved: {args.report}', flush=True)


if __name__ == '__main__':
    main()
