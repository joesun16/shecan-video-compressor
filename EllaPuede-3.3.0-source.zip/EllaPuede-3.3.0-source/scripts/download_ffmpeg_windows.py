#!/usr/bin/env python3
"""Fetch a fixed static Windows build, verify SHA256, keep license/provenance."""
from pathlib import Path
import hashlib
import shutil
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parents[1]
URL = 'https://github.com/GyanD/codexffmpeg/releases/download/8.0.1/ffmpeg-8.0.1-essentials_build.zip'
SHA256 = 'e2aaeaa0fdbc397d4794828086424d4aaa2102cef1fb6874f6ffd29c0b88b673'


def main():
    work = ROOT / 'build' / 'ffmpeg-download'
    work.mkdir(parents=True, exist_ok=True)
    archive = work / 'ffmpeg.zip'
    urllib.request.urlretrieve(URL, archive)
    with archive.open('rb') as stream:
        actual = hashlib.file_digest(stream, 'sha256').hexdigest()
    if actual != SHA256:
        raise RuntimeError(f'FFmpeg checksum mismatch: {actual}')
    destination = ROOT / 'ffmpeg'
    destination.mkdir(exist_ok=True)
    with zipfile.ZipFile(archive) as zipped:
        for filename in ('ffmpeg.exe', 'ffprobe.exe', 'LICENSE'):
            entries = [entry for entry in zipped.namelist() if entry.rsplit('/', 1)[-1] == filename]
            if len(entries) != 1:
                raise RuntimeError(f'Expected exactly one {filename} in FFmpeg archive')
            with zipped.open(entries[0]) as src, (destination / filename).open('wb') as dst:
                shutil.copyfileobj(src, dst)
    (destination / 'ffmpeg-source.txt').write_text(
        f'Binary archive: {URL}\nSHA256: {SHA256}\n'
        'FFmpeg source revision: https://github.com/FFmpeg/FFmpeg/commit/894da5ca7d\n'
        'Build configuration: run ffmpeg.exe -buildconf\n', encoding='utf-8')
    print(f'Verified FFmpeg 8.0.1: {destination}')


if __name__ == '__main__':
    main()
