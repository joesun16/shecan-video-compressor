#!/usr/bin/env python3
"""Run the real application executable with a clean PATH and isolated settings."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('executable', type=Path)
    parser.add_argument('--report', type=Path, default=Path('package-test.json'))
    args = parser.parse_args()
    executable = args.executable.resolve()
    report = args.report.resolve()
    report.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='EllaPuede package 测试 ') as tmp:
        env = dict(os.environ, PATH='', ELLAPUEDE_DATA_DIR=str(Path(tmp) / 'settings'),
                   PYTHONIOENCODING='utf-8')
        # Prevent an installed Qt or Python from masking missing package components.
        for key in ('PYTHONPATH', 'PYTHONHOME', 'QT_PLUGIN_PATH', 'QT_QPA_PLATFORM_PLUGIN_PATH'):
            env.pop(key, None)
        process = subprocess.run([str(executable), '--self-test', '--report', str(report)],
                                 cwd=tmp, env=env, timeout=240, capture_output=True)
        for stream in (process.stdout, process.stderr):
            if stream:
                print(stream.decode('utf-8', errors='replace'))
        if not report.exists():
            raise SystemExit(f'App exited {process.returncode} without a self-test report.')
        result = json.loads(report.read_text(encoding='utf-8'))
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if process.returncode != 0 or result.get('status') != 'passed':
            raise SystemExit(f'Packaged self-test failed: return code {process.returncode}')


if __name__ == '__main__':
    main()
