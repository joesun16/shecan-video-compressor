"""Real FFmpeg regressions. Uses native FFmpeg; no GPU is required to run these."""
import hashlib
import os
from pathlib import Path
import subprocess
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

os.environ.setdefault('ELLAPUEDE_DATA_DIR', str(Path(tempfile.gettempdir()) / 'ellapuede-tests'))
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import video_compressor as app


class WorkerTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        try:
            subprocess.run([app.get_ffmpeg_path(), '-version'], check=True,
                           **app._subprocess_kwargs(timeout=10))
        except (OSError, subprocess.SubprocessError) as exc:
            raise unittest.SkipTest(f'Native FFmpeg required: {exc}')

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ellapuede-测试 ')
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def fixture(self, name='输入 video.mp4', size='320x180', duration=0.8, audio=False, odd=False):
        output = self.root / name
        output.parent.mkdir(parents=True, exist_ok=True)
        command = [app.get_ffmpeg_path(), '-hide_banner', '-loglevel', 'error', '-nostdin',
                   '-f', 'lavfi', '-i', f'{"testsrc" if odd else "testsrc2"}=size={size}:rate=24:duration={duration}']
        if audio:
            command += ['-f', 'lavfi', '-i', f'sine=frequency=440:duration={duration}', '-c:a', 'aac', '-b:a', '64k']
        if odd:
            command += ['-c:v', 'ffv1', '-pix_fmt', 'bgr0']
        else:
            command += ['-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '8', '-pix_fmt', 'yuv420p']
        command += ['-threads', '2', '-y', str(output)]
        subprocess.run(command, check=True, **app._subprocess_kwargs(timeout=30))
        return output

    def worker(self, paths, **overrides):
        settings = dict(encoder_key='cpu_h264', quality_key='balanced', speed_key='fast',
                        resolution=None, output_dir=str(self.root / '输出'), parallel=2, keep_larger=True)
        settings.update(overrides)
        files = [dict(path=str(p), name=p.name, size=p.stat().st_size) for p in paths]
        return app.CompressionWorker(files, settings)

    def assert_decodes(self, path):
        subprocess.run([app.get_ffmpeg_path(), '-hide_banner', '-v', 'error', '-nostdin',
                        '-i', str(path), '-f', 'null', '-'], check=True,
                       **app._subprocess_kwargs(timeout=30))

    def assert_no_temporary_outputs(self):
        self.assertEqual(list(self.root.rglob('.ellapuede-*')), [])

    def test_real_unicode_audio_roundtrip_preserves_source(self):
        source = self.fixture(audio=True)
        original = hashlib.sha256(source.read_bytes()).hexdigest()
        worker = self.worker([source])
        worker.run()
        result = worker.results[0]
        self.assertEqual(result['status'], 'success', result)
        self.assertGreater(result['output_size'], 0)
        self.assertEqual(hashlib.sha256(source.read_bytes()).hexdigest(), original)
        info = app.probe_video_info(result['output_path'])
        self.assertEqual(info['width'], 320)
        self.assertIsNotNone(info['audio_index'])
        self.assert_decodes(result['output_path'])
        self.assert_no_temporary_outputs()

    def test_portrait_downscale_and_small_source_not_upscaled(self):
        portrait = self.fixture('竖屏.mp4', '320x568')
        small = self.fixture('small.mp4', '160x90')
        worker = self.worker([portrait, small], resolution=240)
        worker.run()
        self.assertEqual([r['status'] for r in worker.results.values()], ['success', 'success'])
        tall = app.probe_video_info(worker.results[0]['output_path'])
        tiny = app.probe_video_info(worker.results[1]['output_path'])
        self.assertEqual((tall['width'], tall['height']), (240, 426))
        self.assertEqual((tiny['width'], tiny['height']), (160, 90))

    def test_odd_dimensions_encode_as_even_h264(self):
        source = self.fixture('odd.mkv', '321x241', odd=True)
        worker = self.worker([source])
        worker.run()
        result = worker.results[0]
        self.assertEqual(result['status'], 'success', result)
        info = app.probe_video_info(result['output_path'])
        self.assertEqual((info['width'], info['height']), (320, 240))
        self.assert_decodes(result['output_path'])

    def test_rotation_metadata_is_applied_without_stretching(self):
        source = self.fixture('base.mp4', '320x180')
        rotated = self.root / 'rotated.mp4'
        subprocess.run([app.get_ffmpeg_path(), '-v', 'error', '-nostdin', '-display_rotation', '90',
                        '-i', str(source), '-c', 'copy', str(rotated)],
                       check=True, **app._subprocess_kwargs(timeout=30))
        self.assertEqual(app.probe_video_info(str(rotated))['rotation'], 90)
        worker = self.worker([rotated])
        worker.run()
        result = worker.results[0]
        self.assertEqual(result['status'], 'success', result)
        info = app.probe_video_info(result['output_path'])
        self.assertEqual((info['width'], info['height']), (180, 320))
        self.assertEqual(info['rotation'], 0)

    def test_anamorphic_source_preserves_display_aspect(self):
        source = self.fixture('anamorphic-base.mp4', '320x240')
        anamorphic = self.root / 'anamorphic.mp4'
        subprocess.run([app.get_ffmpeg_path(), '-v', 'error', '-nostdin', '-i', str(source),
                        '-vf', 'setsar=4/3', '-c:v', 'libx264', '-crf', '8', str(anamorphic)],
                       check=True, **app._subprocess_kwargs(timeout=30))
        worker = self.worker([anamorphic])
        worker.run()
        result = worker.results[0]
        self.assertEqual(result['status'], 'success', result)
        info = app.probe_video_info(result['output_path'])
        self.assertEqual(info['sample_aspect_ratio'], 1)
        self.assertAlmostEqual(info['width'] / info['height'], 16 / 9, delta=0.01)

    def test_hevc_output_uses_apple_compatible_hvc1_tag(self):
        import json
        source = self.fixture()
        worker = self.worker([source], encoder_key='cpu_h265')
        worker.run()
        result = worker.results[0]
        self.assertEqual(result['status'], 'success', result)
        probe = subprocess.run([app.get_ffprobe_path(), '-v', 'error', '-select_streams', 'v:0',
                                '-show_entries', 'stream=codec_tag_string', '-of', 'json', result['output_path']],
                               check=True, **app._subprocess_kwargs(timeout=30))
        self.assertEqual(json.loads(probe.stdout)['streams'][0]['codec_tag_string'], 'hvc1')
        self.assert_decodes(result['output_path'])

    def test_parallel_same_basenames_and_compressed_input_never_overwrite(self):
        sources = [self.fixture('one/a_compressed.mp4'), self.fixture('two/a_compressed.mp4')]
        hashes = [hashlib.sha256(p.read_bytes()).hexdigest() for p in sources]
        worker = self.worker(sources)
        worker.run()
        outputs = [worker.results[i]['output_path'] for i in range(2)]
        self.assertNotEqual(outputs[0], outputs[1])
        self.assertTrue(all(Path(p).stat().st_size > 0 for p in outputs))
        self.assertEqual([hashlib.sha256(p.read_bytes()).hexdigest() for p in sources], hashes)
        self.assert_no_temporary_outputs()

    def test_hardware_failure_retries_cpu_and_reports_fallback(self):
        source = self.fixture()
        config = dict(app.ENCODER_CONFIGS['cpu_h264'], encoder='nonexistent_hardware_encoder', is_gpu=True)
        with patch.dict(app.ENCODER_CONFIGS, {'test_gpu': config}):
            worker = self.worker([source], encoder_key='test_gpu')
            worker.run()
        result = worker.results[0]
        self.assertEqual(result['status'], 'success', result)
        self.assertTrue(result['fallback_used'])
        self.assertEqual(result['encoder_key'], 'cpu_h264')
        self.assertIn('Unknown encoder', result['fallback_reason'])
        self.assert_decodes(result['output_path'])

    def test_batch_remembers_unavailable_gpu_instead_of_retrying_every_file(self):
        source = self.fixture()
        paths = [source]
        for number in range(2):
            copy = self.root / f'copy-{number}.mp4'
            copy.write_bytes(source.read_bytes())
            paths.append(copy)
        config = dict(app.ENCODER_CONFIGS['cpu_h264'], encoder='nonexistent_hardware_encoder', is_gpu=True)
        with patch.dict(app.ENCODER_CONFIGS, {'test_gpu': config}):
            worker = self.worker(paths, encoder_key='test_gpu', parallel=1)
            with patch.object(worker, '_encode', wraps=worker._encode) as encode:
                worker.run()
        gpu_attempts = [call for call in encode.call_args_list if 'nonexistent_hardware_encoder' in call.args[1]]
        self.assertEqual(len(gpu_attempts), 1)
        self.assertEqual(len(worker.results), 3)
        self.assertTrue(all(result['status'] == 'success' for result in worker.results.values()))
        self.assertTrue(all(result['fallback_used'] for result in worker.results.values()))

    def test_eight_real_encodes_can_be_active_at_once(self):
        source = self.fixture(duration=1.5)
        paths = [source]
        for number in range(7):
            copy = self.root / f'parallel-{number}.mp4'
            copy.write_bytes(source.read_bytes())
            paths.append(copy)
        worker = self.worker(paths, parallel=8)
        build = worker._build_command
        def realtime(*args):
            command = build(*args)
            command.insert(command.index('-i'), '-re')
            return command
        with patch.object(worker, '_build_command', side_effect=realtime):
            worker.run()
        self.assertEqual(worker.effective_parallel, 8)
        self.assertEqual(worker.peak_parallel_processes, 8)
        self.assertEqual(len(worker.results), 8)
        self.assertTrue(all(result['status'] == 'success' for result in worker.results.values()), worker.results)

    def test_list_metadata_is_reused_during_compression_without_changing_quality(self):
        source = self.fixture()
        with patch.object(app, '_probe_video_info_uncached', wraps=app._probe_video_info_uncached) as probe:
            app.probe_video_info(str(source))
            worker = self.worker([source])
            with patch.object(worker, '_encode', wraps=worker._encode) as encode:
                worker.run()
        input_calls = [call for call in probe.call_args_list if str(call.args[0]) == str(source)]
        self.assertEqual(len(input_calls), 1)
        command = encode.call_args.args[1]
        self.assertNotIn('-vf', command)
        self.assertEqual(command[command.index('-crf') + 1], '23')
        self.assertEqual(command[command.index('-preset') + 1], 'veryfast')
        self.assertEqual(command[command.index('-pix_fmt') + 1], 'yuv420p')
        self.assertEqual(worker.results[0]['status'], 'success')

    def test_larger_output_is_reported_as_original_retained(self):
        source = self.fixture()
        worker = self.worker([source], keep_larger=False)
        real_encode = worker._encode
        def encode_with_large_metadata(index, command, duration):
            code, error = real_encode(index, command, duration)
            # MP4 tolerates a trailing free box; use valid container padding rather than a fake worker result.
            import struct
            with open(command[-1], 'ab') as output:
                output.write(struct.pack('>I4s', source.stat().st_size + 8, b'free'))
                output.write(b'\0' * source.stat().st_size)
            return code, error
        with patch.object(worker, '_encode', side_effect=encode_with_large_metadata):
            worker.run()
        result = worker.results[0]
        self.assertEqual(result['status'], 'kept_original', result)
        self.assertEqual(result['output_path'], str(source))
        self.assertEqual(list((self.root / '输出').iterdir()), [])

    def test_bad_input_reports_error_and_leaves_no_output(self):
        source = self.root / 'bad.mp4'
        source.write_bytes(b'not media')
        worker = self.worker([source])
        worker.run()
        self.assertEqual(worker.results[0]['status'], 'failed')
        self.assertTrue(worker.results[0]['error'])
        self.assert_no_temporary_outputs()

    def test_hdr_is_explicitly_rejected_before_any_output(self):
        source = self.fixture()
        metadata = app.probe_video_info(str(source))
        metadata['color_transfer'] = 'smpte2084'
        worker = self.worker([source])
        with patch.object(app, 'probe_video_info', return_value=metadata):
            worker.run()
        self.assertEqual(worker.results[0]['status'], 'failed')
        self.assertIn('HDR', worker.results[0]['error'])
        self.assertFalse((self.root / '输出').exists())

    def test_stop_interrupts_a_live_encode_and_removes_partial_outputs(self):
        source = self.fixture(duration=5)
        worker = self.worker([source])
        build = worker._build_command
        def realtime(*args):
            command = build(*args)
            command.insert(command.index('-i'), '-re')
            return command
        with patch.object(worker, '_build_command', side_effect=realtime):
            thread = threading.Thread(target=worker.run)
            thread.start()
            deadline = time.monotonic() + 5
            while time.monotonic() < deadline:
                with worker._lock:
                    active = bool(worker._processes)
                if active:
                    break
                time.sleep(0.02)
            self.assertTrue(active, 'FFmpeg never started')
            start = time.monotonic()
            worker.stop()
            thread.join(timeout=5)
        self.assertFalse(thread.is_alive(), 'Stop left the worker running')
        self.assertLess(time.monotonic() - start, 5)
        self.assertEqual(worker.results[0]['status'], 'cancelled')
        self.assert_no_temporary_outputs()
        self.assertEqual(list((self.root / '输出').iterdir()), [])


if __name__ == '__main__':
    unittest.main()
