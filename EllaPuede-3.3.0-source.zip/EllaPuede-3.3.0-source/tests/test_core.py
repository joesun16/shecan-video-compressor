"""Fast regression checks for encoder truthfulness, media metadata and safe naming."""
import json
import os
from pathlib import Path
import subprocess
import tempfile
import threading
import time
import unittest
from unittest.mock import patch

os.environ.setdefault('ELLAPUEDE_DATA_DIR', str(Path(tempfile.gettempdir()) / 'ellapuede-tests'))
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import video_compressor as app


class CoreTests(unittest.TestCase):
    def setUp(self):
        with app._VIDEO_INFO_LOCK:
            app._VIDEO_INFO_CACHE.clear()

    def test_windows_subprocess_has_valid_console_handles_and_unicode(self):
        with patch.object(app, 'IS_WIN', True):
            kwargs = app._subprocess_kwargs(timeout=3)
        self.assertEqual(kwargs['stdin'], subprocess.DEVNULL)
        self.assertEqual(kwargs['encoding'], 'utf-8')
        self.assertEqual(kwargs['errors'], 'replace')
        self.assertEqual(kwargs['creationflags'], 0x08000000)
        self.assertTrue(kwargs['capture_output'])

    def test_compiled_nvidia_is_hidden_when_real_encode_fails(self):
        cpu = dict(app.ENCODER_CONFIGS['cpu_h264'])
        nvidia = dict(cpu, encoder='h264_nvenc', quality_param='-cq', is_gpu=True)
        listing = subprocess.CompletedProcess([], 0, ' V....D libx264 H.264\n V....D h264_nvenc NVENC\n', '')
        success = subprocess.CompletedProcess([], 0, '', '')
        failure = subprocess.CompletedProcess([], 1, '', 'Cannot load nvcuda.dll')
        with patch.dict(app.ENCODER_CONFIGS, {'cpu_h264': cpu, 'nvidia': nvidia}, clear=True), \
             patch.object(app.subprocess, 'run', side_effect=[listing, success, failure]) as run:
            detected = app.detect_available_encoders()
        self.assertEqual(detected, ['cpu_h264'])
        self.assertEqual(run.call_count, 3)
        self.assertIn('-frames:v', run.call_args_list[-1].args[0])
        self.assertIn('nvcuda', app.ENCODER_PROBE_ERRORS['nvidia'])
        self.assertEqual(app.get_auto_encoder(detected), 'cpu_h264')
        self.assertIsNone(app.get_auto_encoder([]))

    def test_missing_ffmpeg_is_not_advertised_as_working_cpu(self):
        with patch.object(app.subprocess, 'run', side_effect=FileNotFoundError('ffmpeg absent')):
            self.assertEqual(app.detect_available_encoders(), [])

    def test_metadata_selects_real_video_and_default_audio(self):
        metadata = {
            'streams': [
                {'index': 0, 'codec_type': 'video', 'disposition': {'attached_pic': 1}},
                {'index': 1, 'codec_type': 'audio', 'codec_name': 'mp3'},
                {'index': 2, 'codec_type': 'video', 'width': 720, 'height': 480,
                 'sample_aspect_ratio': '8:9', 'side_data_list': [{'rotation': -90}]},
                {'index': 3, 'codec_type': 'audio', 'codec_name': 'aac', 'bit_rate': '64000',
                 'disposition': {'default': 1}},
            ], 'format': {'duration': '3.25'},
        }
        with patch.object(app, '_probe_command', return_value=(0, json.dumps(metadata), '')):
            info = app.probe_video_info('测试.mp4')
        self.assertTrue(info['valid'])
        self.assertEqual(info['video_index'], 2)
        self.assertEqual(info['audio_index'], 3)
        self.assertEqual(info['rotation'], 270)
        self.assertAlmostEqual(info['sample_aspect_ratio'], 8 / 9)
        self.assertEqual(info['audio_bitrate'], 64000)

    def test_probe_failure_has_actionable_error(self):
        with patch.object(app, '_probe_command', return_value=(1, '', 'moov atom not found')):
            info = app.probe_video_info('broken.mp4')
        self.assertFalse(info['valid'])
        self.assertIn('moov atom', info['error'])

    def test_output_names_never_overwrite_input_or_existing_output(self):
        with tempfile.TemporaryDirectory() as directory:
            original = Path(directory) / '会议_compressed.mp4'
            original.write_bytes(b'original')
            existing = Path(directory) / '会议_compressed_2.mp4'
            existing.write_bytes(b'prior result')
            worker = app.CompressionWorker([{'path': str(original)}], {})
            output, identity = worker._reserve_output(str(original))
            self.assertEqual(Path(output).name, '会议_compressed_3.mp4')
            self.assertTrue(worker._owns_reservation(output, identity))
            self.assertEqual(original.read_bytes(), b'original')
            self.assertEqual(existing.read_bytes(), b'prior result')
            worker._cleanup_file(output)

    def test_two_instances_reserve_distinct_names(self):
        with tempfile.TemporaryDirectory() as directory:
            original = Path(directory) / 'clip.mp4'
            original.touch()
            a = app.CompressionWorker([{'path': str(original)}], {})
            b = app.CompressionWorker([{'path': str(original)}], {})
            first, _ = a._reserve_output(str(original))
            second, _ = b._reserve_output(str(original))
            self.assertNotEqual(first, second)

    def test_replaced_reservation_is_not_deleted(self):
        with tempfile.TemporaryDirectory() as directory:
            original = Path(directory) / 'clip.mp4'
            original.touch()
            worker = app.CompressionWorker([{'path': str(original)}], {})
            output, identity = worker._reserve_output(str(original))
            Path(output).write_bytes(b'someone else wrote data')
            self.assertFalse(worker._owns_reservation(output, identity))

    def test_metadata_cache_reuses_unchanged_file_and_invalidates_file_change(self):
        with tempfile.TemporaryDirectory() as directory:
            source = Path(directory) / 'video.mp4'
            source.write_bytes(b'first')
            info = {'valid': True, 'duration': 4.0, 'error': ''}
            with patch.object(app, '_probe_video_info_uncached', return_value=info) as probe:
                app.probe_video_info(str(source))
                cached = app.probe_video_info(str(source))
                cached['duration'] = 999
                self.assertEqual(app.probe_video_info(str(source))['duration'], 4.0)
                self.assertEqual(probe.call_count, 1)
                source.write_bytes(b'changed, different size')
                app.probe_video_info(str(source))
                self.assertEqual(probe.call_count, 2)

    def test_simultaneous_metadata_requests_share_one_probe(self):
        from concurrent.futures import ThreadPoolExecutor
        started, release = threading.Event(), threading.Event()
        def inspect(*args):
            started.set()
            release.wait(2)
            return {'valid': True, 'duration': 4.0, 'error': ''}
        with patch.object(app, '_video_cache_key', return_value=('same-video',)), \
             patch.object(app, '_probe_video_info_uncached', side_effect=inspect) as probe, \
             ThreadPoolExecutor(max_workers=2) as pool:
            first = pool.submit(app.probe_video_info, 'same.mp4')
            self.assertTrue(started.wait(2))
            second = pool.submit(app.probe_video_info, 'same.mp4')
            release.set()
            self.assertEqual(first.result()['duration'], second.result()['duration'])
            self.assertEqual(probe.call_count, 1)

    def test_metadata_changed_during_probe_is_not_used_or_cached(self):
        info = {'valid': True, 'duration': 4, 'width': 1920, 'height': 1080, 'error': ''}
        with patch.object(app, '_video_cache_key', side_effect=[('before',), ('after',)]), \
             patch.object(app, '_probe_video_info_uncached', return_value=info):
            result = app.probe_video_info('changing.mp4')
        self.assertFalse(result['valid'])
        self.assertTrue(result['error'])
        self.assertEqual(result['duration'], 0)
        self.assertFalse(app._VIDEO_INFO_CACHE)

    def test_metadata_pool_cancels_and_prunes_queued_work(self):
        started = threading.Event()
        callbacks = []
        def inspect(filepath, event):
            started.set()
            event.wait(2)
            return {'valid': False, 'duration': 0}
        with patch.object(app, 'probe_video_info', side_effect=inspect):
            pool = app.VideoInfoPool(lambda *args: callbacks.append(args), max_workers=1)
            pool.submit('one', 'first.mp4')
            self.assertTrue(started.wait(2))
            pool.submit('two', 'second.mp4')
            pool.cancel_pending()
            deadline = time.monotonic() + 2
            while pool._futures and time.monotonic() < deadline:
                time.sleep(0.01)
            self.assertEqual(callbacks, [])
            self.assertFalse(pool._futures)
            pool.shutdown()

    def test_cpu_parallel_eight_starts_eight_tasks_without_hidden_cap(self):
        barrier = threading.Barrier(8, timeout=3)
        worker = app.CompressionWorker([{'path': f'/source/{i}.mp4'} for i in range(8)],
                                      {'encoder_key': 'cpu_h264', 'parallel': 8})
        reached = []
        def compress(index, *args):
            barrier.wait()
            reached.append(index)
        with patch.object(worker, '_compress_one', side_effect=compress):
            worker.run()
        self.assertEqual(worker.effective_parallel, 8)
        self.assertEqual(sorted(reached), list(range(8)))
        self.assertGreaterEqual(worker.thread_budget['encode'], 1)

    def test_only_required_files_go_through_scaling(self):
        square = {'width': 1920, 'height': 1080, 'sample_aspect_ratio': 1, 'pix_fmt': 'yuv420p'}
        self.assertFalse(app.needs_scale_filter(square))
        self.assertFalse(app.needs_scale_filter(square, 1080))
        self.assertTrue(app.needs_scale_filter(square, 720))
        self.assertTrue(app.needs_scale_filter(dict(square, width=1919)))
        self.assertTrue(app.needs_scale_filter(dict(square, sample_aspect_ratio=4 / 3)))
        self.assertTrue(app.needs_scale_filter(dict(square, pix_fmt='yuv444p')))

    def test_permanent_gpu_failure_is_remembered_but_busy_session_is_not(self):
        worker = app.CompressionWorker([], {})
        worker._remember_hardware_failure('nvidia', 'Cannot load nvcuda.dll')
        worker._remember_hardware_failure('apple_h264', 'Cannot create compression session: -12908')
        self.assertIn('nvidia', worker._disabled_encoders)
        self.assertNotIn('apple_h264', worker._disabled_encoders)

    def test_nvenc_generic_failure_tail_does_not_disable_the_batch(self):
        for detail in ('Width 4608 exceeds 4096\nNo capable devices found',
                       'OpenEncodeSessionEx failed: out of memory\nNo NVENC capable devices found'):
            worker = app.CompressionWorker([], {})
            worker._remember_hardware_failure('nvidia', detail)
            self.assertNotIn('nvidia', worker._disabled_encoders)


if __name__ == '__main__':
    unittest.main()
