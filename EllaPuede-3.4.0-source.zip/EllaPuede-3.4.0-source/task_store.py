"""Transactional queue checkpoints; deliberately independent of Qt and codecs.

The application owns an exclusive instance lock before loading/cleaning a queue.
No task is started by this module. Source/output validation uses file identity and
stat metadata, so it never reads entire videos merely to restore the queue.
"""
from __future__ import annotations

from contextlib import contextmanager
import json
import math
import os
from pathlib import Path
import shutil
import sqlite3
import stat
import threading
import time
import uuid


SCHEMA_VERSION = 1
_ACTIVE = {'running', 'preparing', 'compressing'}
_COMPLETE = {'success', 'kept_original'}
_STATUSES = _ACTIVE | _COMPLETE | {'pending', 'queued', 'waiting', 'interrupted', 'cancelled', 'failed'}
_FILE_FIELDS = {'id', 'path', 'name', 'size', 'duration_text', 'settings', 'status',
                'source_identity', 'priority', 'excluded'}
_RESULT_FIELDS = {'status', 'output_path', 'input_size', 'output_size', 'encoder_key',
                  'fallback_used', 'fallback_reason', 'error', 'recovery_reason',
                  'source_identity', 'output_identity', 'settings',
                  'error_kind', 'error_details', 'fallback_error_kind'}
_SETTING_FIELDS = {'encoder_key', 'available_encoders', 'quality_key', 'speed_key',
                   'resolution', 'output_dir', 'parallel', 'keep_larger',
                   'adaptive_parallel', 'resource_mode'}
_RECOVERY_MESSAGES = {
    'interrupted': '上次处理未完成，可继续处理。 / Previous processing was interrupted; ready to retry.',
    'source_missing': '找不到原视频，请恢复文件后重试。 / Source video is unavailable; restore it and retry.',
    'source_changed': '原视频已变化，需要重新处理。 / Source video changed; process it again.',
    'output_missing': '上次输出已移走或删除，需要重新处理。 / Previous output is missing; process it again.',
    'output_changed': '上次输出已变化，需要重新处理。 / Previous output changed; process it again.',
}


class TaskStoreError(RuntimeError):
    """Persistence failed; the caller must make this visible to the user."""


class TaskStoreCorruptError(TaskStoreError):
    def __init__(self, path, backup_path, reason):
        self.path = str(path)
        self.backup_path = str(backup_path) if backup_path else None
        suffix = f' Preserved copy: {self.backup_path}' if backup_path else ' Original file was left unchanged.'
        super().__init__(f'Cannot read saved queue: {reason}.{suffix}')


def capture_identity(path):
    """Identity of a readable regular file, or None when absent/unavailable."""
    try:
        info = os.stat(path)
        if not stat.S_ISREG(info.st_mode):
            return None
        return {'size': info.st_size, 'mtime_ns': info.st_mtime_ns,
                'dev': info.st_dev, 'ino': info.st_ino}
    except (OSError, TypeError, ValueError):
        return None


def _canonical(path):
    return os.path.normcase(os.path.realpath(os.path.abspath(path)))


def _safe_value(value, depth=0):
    if depth > 8:
        raise ValueError('Queue data is nested too deeply')
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float) and math.isfinite(value):
        return value
    if isinstance(value, (list, tuple)):
        return [_safe_value(item, depth + 1) for item in value]
    if isinstance(value, dict) and all(isinstance(k, str) for k in value):
        return {key: _safe_value(item, depth + 1) for key, item in value.items()}
    raise ValueError('Queue contains unsupported data; only JSON values are allowed')


def _identity(value):
    if value is None:
        return None
    if not isinstance(value, dict) or set(value) != {'size', 'mtime_ns', 'dev', 'ino'}:
        raise ValueError('Invalid saved file identity')
    if any(type(item) is not int or item < 0 for item in value.values()):
        raise ValueError('Invalid saved file identity')
    return dict(value)


def _clean_fields(value, fields):
    if not isinstance(value, dict):
        raise ValueError('Queue entries must be dictionaries')
    clean = {key: _safe_value(item) for key, item in value.items() if key in fields}
    if 'settings' in clean:
        settings = clean['settings']
        if not isinstance(settings, dict):
            raise ValueError('Task settings must be a dictionary')
        clean['settings'] = {k: v for k, v in settings.items() if k in _SETTING_FIELDS}
    for key in ('source_identity', 'output_identity'):
        if key in clean:
            clean[key] = _identity(clean[key])
    if 'status' in clean and clean['status'] not in _STATUSES:
        raise ValueError('Unknown task status')
    return clean


def _dump(value):
    return json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(',', ':'))


def _recovery_result(previous, reason):
    result = dict(previous or {})
    result.update(status='failed' if reason == 'source_missing' else 'interrupted',
                  recovery_reason=reason, error=_RECOVERY_MESSAGES[reason])
    return result


class TaskStore:
    """Snapshot saves and per-task results commit atomically with FULL sync.

    Results use UI row indices at the API boundary and stable task IDs on disk.
    Set a task's status to ``queued`` (or ``pending``) and remove its result to
    explicitly reset it. A stale ``running`` GUI snapshot cannot erase a result
    already committed by a worker. Pass a fresh source_identity when retrying a
    changed source. Do not share this queue between simultaneously active apps.
    """
    def __init__(self, path):
        self.path = Path(path).absolute()
        self._lock = threading.RLock()
        self._broken = False
        self.path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with self._connect() as connection:
                check = connection.execute('PRAGMA quick_check').fetchone()
                if not check or check[0] != 'ok':
                    raise sqlite3.DatabaseError('database integrity check failed')
                connection.execute('BEGIN IMMEDIATE')
                connection.execute('CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL)')
                version = connection.execute("SELECT value FROM meta WHERE key='schema_version'").fetchone()
                if version and version[0] != str(SCHEMA_VERSION):
                    connection.rollback()
                    raise TaskStoreError(f'Unsupported queue schema {version[0]}; saved file was left unchanged')
                connection.execute("INSERT OR IGNORE INTO meta VALUES ('schema_version', ?)", (str(SCHEMA_VERSION),))
                connection.execute('CREATE TABLE IF NOT EXISTS tasks (id TEXT PRIMARY KEY, position INTEGER NOT NULL, payload TEXT NOT NULL, result TEXT)')
                connection.execute('CREATE TABLE IF NOT EXISTS artifacts (task_id TEXT PRIMARY KEY, payload TEXT NOT NULL)')
                connection.commit()
                # Malformed JSON is corruption too; detect before any save.
                self._read_rows(connection)
                for (payload,) in connection.execute('SELECT payload FROM artifacts'):
                    self._parse_artifact(payload)
        except (sqlite3.DatabaseError, ValueError, TypeError, KeyError) as exc:
            self._corrupt(exc)
        except OSError as exc:
            raise TaskStoreError(str(exc)) from exc

    @contextmanager
    def _connect(self):
        if self._broken:
            raise TaskStoreError('This saved queue is unavailable; preserved file will not be overwritten')
        connection = sqlite3.connect(str(self.path), timeout=10, isolation_level=None)
        try:
            connection.execute('PRAGMA synchronous=FULL')
            yield connection
        finally:
            connection.close()

    def _corrupt(self, reason):
        self._broken = True
        backup = self.path.with_name(self.path.name + '.corrupt-' + time.strftime('%Y%m%d-%H%M%S') + '-' + uuid.uuid4().hex[:8])
        try:
            shutil.copy2(self.path, backup)
            for suffix in ('-journal', '-wal', '-shm'):
                sidecar = Path(str(self.path) + suffix)
                if sidecar.exists():
                    shutil.copy2(sidecar, Path(str(backup) + suffix))
        except OSError:
            backup = None
        raise TaskStoreCorruptError(self.path, backup, str(reason)) from reason

    def _read_rows(self, connection):
        rows = []
        for task_id, payload, raw_result in connection.execute('SELECT id, payload, result FROM tasks ORDER BY position'):
            item = _clean_fields(json.loads(payload), _FILE_FIELDS)
            if item.get('id') != task_id or not isinstance(item.get('path'), str) or not os.path.isabs(item['path']):
                raise ValueError('Invalid saved task identifier or path')
            result = _clean_fields(json.loads(raw_result), _RESULT_FIELDS) if raw_result is not None else None
            rows.append((item, result))
        return rows

    def save(self, files, results):
        """Replace queue order/content in one transaction; explicit empty clears it."""
        if not isinstance(files, list) or not isinstance(results, dict):
            raise ValueError('Expected a file list and results dictionary')
        prepared, seen = [], set()
        for index, item in enumerate(files):
            entry = _clean_fields(item, _FILE_FIELDS)
            task_id = entry.get('id')
            if not isinstance(task_id, str) or not task_id or task_id in seen:
                raise ValueError('Every task needs a unique, nonempty stable ID')
            seen.add(task_id)
            if not isinstance(entry.get('path'), str) or not entry['path']:
                raise ValueError('Every task needs a source path')
            entry['path'] = os.path.abspath(entry['path'])
            entry.setdefault('name', os.path.basename(entry['path']))
            entry.setdefault('status', 'pending')
            result = _clean_fields(results[index], _RESULT_FIELDS) if index in results else None
            prepared.append((entry, result))
        try:
            with self._lock, self._connect() as connection:
                connection.execute('BEGIN IMMEDIATE')
                old = {item['id']: (item, result) for item, result in self._read_rows(connection)}
                rows = []
                for index, (entry, result) in enumerate(prepared):
                    old_entry, old_result = old.get(entry['id'], ({}, None))
                    same_source = old_entry.get('path') == entry['path']
                    if 'source_identity' not in entry:
                        entry['source_identity'] = old_entry.get('source_identity') if same_source else capture_identity(entry['path'])
                    if (same_source and entry['status'] == 'waiting'
                            and old_entry.get('status') in _ACTIVE):
                        entry['status'] = old_entry['status']
                    if result is None and entry['status'] in (_ACTIVE | {'waiting'}) and same_source and old_result is not None:
                        result = old_result
                    if result is not None:
                        result.setdefault('source_identity', entry['source_identity'])
                        if result.get('status') in _COMPLETE:
                            prior_output = old_result.get('output_identity') if old_result and old_result.get('output_path') == result.get('output_path') else None
                            result.setdefault('output_identity', prior_output or capture_identity(result.get('output_path')))
                        entry['status'] = result.get('status', entry['status'])
                    rows.append((entry['id'], index, _dump(entry), _dump(result) if result is not None else None))
                connection.execute('DELETE FROM tasks')
                connection.executemany('INSERT INTO tasks VALUES (?, ?, ?, ?)', rows)
                for entry, result in prepared:
                    if result:
                        self._discard_cleaned_artifact(connection, entry['id'], result)
                connection.commit()
        except sqlite3.DatabaseError as exc:
            raise TaskStoreError(f'Could not save queue: {exc}') from exc

    def load(self):
        """Return checked tasks without changing the saved evidence or starting work."""
        try:
            with self._lock, self._connect() as connection:
                rows = self._read_rows(connection)
        except (sqlite3.DatabaseError, ValueError, TypeError, KeyError) as exc:
            self._corrupt(exc)
        files, results = [], {}
        for index, (entry, result) in enumerate(rows):
            current = capture_identity(entry['path'])
            previous = (result or {}).get('source_identity') or entry.get('source_identity')
            reason = None
            if current is None:
                reason = 'source_missing'
            elif previous is None or previous != current:
                reason = 'source_changed'
            elif result and result.get('status') in _COMPLETE:
                output = result.get('output_path') or (entry['path'] if result['status'] == 'kept_original' else '')
                output_current = capture_identity(output)
                if output_current is None:
                    reason = 'output_missing'
                elif result.get('output_identity') != output_current:
                    reason = 'output_changed'
            elif entry.get('status') in _ACTIVE or (result or {}).get('status') in _ACTIVE:
                reason = 'interrupted'
            if reason:
                result = _recovery_result(result, reason)
                entry['status'] = result['status']
            elif result:
                entry['status'] = result.get('status', entry['status'])
            files.append(entry)
            if result is not None:
                results[index] = result
        return files, results

    def update_result(self, task_id, result):
        """Commit a worker result before emitting the GUI signal; unknown IDs fail."""
        clean = _clean_fields(result, _RESULT_FIELDS)
        if not clean.get('status'):
            raise ValueError('A result needs a status')
        try:
            with self._lock, self._connect() as connection:
                connection.execute('BEGIN IMMEDIATE')
                row = connection.execute('SELECT payload FROM tasks WHERE id=?', (task_id,)).fetchone()
                if row is None:
                    raise TaskStoreError('Cannot checkpoint a task that is absent from the saved queue')
                entry = _clean_fields(json.loads(row[0]), _FILE_FIELDS)
                clean.setdefault('source_identity', entry.get('source_identity'))
                if clean['status'] in _COMPLETE:
                    clean.setdefault('output_identity', capture_identity(clean.get('output_path')))
                entry['status'] = clean['status']
                connection.execute('UPDATE tasks SET payload=?, result=? WHERE id=?', (_dump(entry), _dump(clean), task_id))
                self._discard_cleaned_artifact(connection, task_id, clean)
                connection.commit()
        except sqlite3.DatabaseError as exc:
            raise TaskStoreError(f'Could not checkpoint task: {exc}') from exc

    def record_artifacts(self, task_id, temp_path, out_path, reservation):
        """Record exact owned files before encoding; never claims an existing video."""
        temp_path, out_path = os.path.abspath(temp_path), os.path.abspath(out_path)
        temp = os.stat(temp_path, follow_symlinks=False)
        output = os.stat(out_path, follow_symlinks=False)
        directory = os.stat(os.path.dirname(temp_path))
        if (not Path(temp_path).name.startswith('.ellapuede-') or not temp_path.endswith('.mp4')
                or not stat.S_ISREG(temp.st_mode) or not stat.S_ISREG(output.st_mode)
                or temp.st_nlink != 1 or output.st_nlink != 1
                or temp.st_size != 0 or output.st_size != 0
                or (output.st_dev, output.st_ino) != tuple(reservation)
                or _canonical(os.path.dirname(temp_path)) != _canonical(os.path.dirname(out_path))):
            raise TaskStoreError('Refusing to record files without verified temporary/reservation ownership')
        payload = {'temp_path': os.path.realpath(temp_path), 'out_path': os.path.realpath(out_path),
                   'temp_identity': [temp.st_dev, temp.st_ino], 'out_identity': list(reservation),
                   'directory_identity': [directory.st_dev, directory.st_ino]}
        try:
            with self._lock, self._connect() as connection:
                connection.execute('BEGIN IMMEDIATE')
                sources = {_canonical(item['path']) for item, _ in self._read_rows(connection)}
                if _canonical(temp_path) in sources or _canonical(out_path) in sources:
                    raise TaskStoreError('Refusing to record a queue source as a temporary output')
                row = connection.execute('SELECT payload FROM tasks WHERE id=?', (task_id,)).fetchone()
                if not row:
                    raise TaskStoreError('Cannot record artifacts for an unknown task')
                entry = _clean_fields(json.loads(row[0]), _FILE_FIELDS)
                entry['status'] = 'running'
                connection.execute('UPDATE tasks SET payload=? WHERE id=?', (_dump(entry), task_id))
                connection.execute('INSERT OR REPLACE INTO artifacts VALUES (?, ?)', (task_id, _dump(payload)))
                connection.commit()
        except sqlite3.DatabaseError as exc:
            raise TaskStoreError(f'Could not checkpoint temporary files: {exc}') from exc

    @staticmethod
    def _parse_artifact(raw):
        item = json.loads(raw)
        if not isinstance(item, dict) or set(item) != {'temp_path', 'out_path', 'temp_identity', 'out_identity', 'directory_identity'}:
            raise ValueError('Invalid artifact checkpoint')
        for key in ('temp_path', 'out_path'):
            if not isinstance(item[key], str) or not os.path.isabs(item[key]):
                raise ValueError('Invalid artifact path')
        for key in ('temp_identity', 'out_identity', 'directory_identity'):
            if not isinstance(item[key], list) or len(item[key]) != 2 or any(type(n) is not int or n < 0 for n in item[key]):
                raise ValueError('Invalid artifact identity')
        return item

    def _discard_cleaned_artifact(self, connection, task_id, result):
        row = connection.execute('SELECT payload FROM artifacts WHERE task_id=?', (task_id,)).fetchone()
        if not row:
            return
        artifact = self._parse_artifact(row[0])
        # A result callback follows worker cleanup. Keep evidence if cleanup did
        # not finish; successful renames intentionally leave a completed output.
        if not os.path.lexists(artifact['temp_path']) and (
                not os.path.lexists(artifact['out_path']) or
                (result.get('status') == 'success' and result.get('output_path') and
                 _canonical(result['output_path']) == _canonical(artifact['out_path']))):
            connection.execute('DELETE FROM artifacts WHERE task_id=?', (task_id,))

    def recovery_cleanup(self):
        """Remove only owned crash leftovers, after the app acquires its instance lock.

        Identity checks deliberately skip replacements, links, nonempty reserved
        output files and completed outputs. Skips remain recorded for inspection.
        """
        report = {'removed': [], 'skipped': [], 'errors': []}
        try:
            with self._lock, self._connect() as connection:
                rows = self._read_rows(connection)
                protected = {_canonical(entry['path']) for entry, _ in rows}
                protected.update(_canonical(result['output_path']) for _, result in rows
                                 if result and result.get('status') in _COMPLETE and result.get('output_path'))
                for task_id, raw in connection.execute('SELECT task_id, payload FROM artifacts').fetchall():
                    artifact = self._parse_artifact(raw)
                    retained = False
                    for kind in ('temp', 'out'):
                        path = artifact[kind + '_path']
                        try:
                            if not os.path.lexists(path):
                                continue
                            safe_name = kind == 'out' or (Path(path).name.startswith('.ellapuede-') and path.endswith('.mp4'))
                            directory = os.stat(os.path.dirname(path), follow_symlinks=False)
                            info = os.stat(path, follow_symlinks=False)
                            safe = (safe_name and _canonical(path) not in protected
                                    and os.path.realpath(path) == path
                                    and stat.S_ISDIR(directory.st_mode)
                                    and [directory.st_dev, directory.st_ino] == artifact['directory_identity']
                                    and stat.S_ISREG(info.st_mode) and info.st_nlink == 1
                                    and info.st_ino != 0
                                    and [info.st_dev, info.st_ino] == artifact[kind + '_identity']
                                    and (kind == 'temp' or info.st_size == 0))
                            if not safe:
                                report['skipped'].append(path)
                                retained = True
                                continue
                            os.unlink(path)
                            report['removed'].append(path)
                        except OSError as exc:
                            report['errors'].append({'path': path, 'error': str(exc)})
                            retained = True
                    if not retained:
                        connection.execute('DELETE FROM artifacts WHERE task_id=?', (task_id,))
        except (sqlite3.DatabaseError, ValueError, TypeError, KeyError) as exc:
            raise TaskStoreError(f'Could not inspect crash leftovers: {exc}') from exc
        return report
