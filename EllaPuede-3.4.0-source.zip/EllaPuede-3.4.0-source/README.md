# EllaPuede 视频压缩工具 3.4.0

用于 macOS 和 Windows 的本地批量视频压缩工具。视频在本机处理，原文件保留。

## 3.4.0 更新

- **连续任务队列**：压缩时可以继续添加视频；等待项可以优先处理或单独取消。已完成结果可以立即查看。
- **暂停与继续**：暂停队列只停止启动新任务，正在处理的文件会完成；继续后接着处理等待项。停止会终止当前处理，中断的文件再次处理时从头编码。
- **任务恢复**：队列、每项任务的设置和已完成结果保存在本机。重新打开后恢复列表，由用户核对后继续；不会自动开始编码。源文件或输出已经变化时会标明需要重新处理。
- **固定任务设置**：开始处理后，每项任务保留自己的质量、分辨率、编码策略和输出目录。修改上方设置用于新任务；已有任务需明确选择「用当前设置重新排队」才应用新设置。
- **清晰的策略与结果**：不支持软件速度预设的硬件显示「由硬件管理」，不再停留在灰色的「平衡」。没有变小的结果明确说明未生成新文件，任务详情保留本项设置和实际使用的编码器。
- **可解释的错误与资源限制**：区分磁盘空间、权限、损坏输入、显卡繁忙等失败原因。仅识别为硬件问题时尝试 CPU 回退；回退任务同时最多 2 项。主动选择 CPU 时仍遵守设置的并行上限，最高 8 项。
- **验收补充**：打包验收增加真实运行中的追加、暂停、继续、取消、优先顺序、独立任务设置，以及重启任务记录后继续处理的检查。保留原生中英文布局与真实八文件压缩、完整解码验收。

本轮着重减少整批工作的中断与返工，不把并行数量增加视为所有视频都会提速的证据。混合任务与动态追加时不显示依据不足的剩余时间估计。

## 3.3.0 更新

- 并行数可设为 **1–8**，压缩任务按所选并行数执行；默认仍采用温和设置。提高并行数是否更快取决于视频、CPU/GPU、内存和磁盘。
- 文件夹在后台导入，批量添加视频时主界面保持响应。
- 当前队列有未完成项时，只续跑这些文件；已完成项须通过「重新压缩」或右键「重新压缩选中项」明确重跑。
- 复用未变化文件的元信息，并跳过不需要的缩放处理。
- 压缩进度补充剩余时间估计，统一菜单间距与配色，保留简洁的默认界面。
- 打包验收增加并行范围、设置传递、真实下拉菜单截图和八文件真实压缩检查。

## 3.2.1 界面更新

- 简化主界面，减少重复提示，重新整理操作区和压缩设置。
- 重绘应用图标，统一控件与下拉箭头，并将 SVG 控件资源随应用一起打包。
- 保留 3.2 系列的硬件实测、自动回退、安全输出与压缩验收机制。

## 3.2 系列功能改进

- **真实硬件检测**：用一次短视频编码验证 GPU 与驱动是否可用，只有通过的硬件编码器才会显示；默认自动选择。FFmpeg 宣称支持某编码器不再等同于用户有对应显卡。
- **更可靠的 Windows 压缩**：统一隐藏 FFmpeg 子进程窗口、处理标准输入输出及 UTF-8 日志，支持中文路径；编码失败保留诊断信息。
- **安全输出**：防止覆盖已有文件，失败和取消清理临时输出，输出变大时保留原视频，并区分成功、保留原文件、失败和取消。
- **硬件失败自动恢复**：实际任务中硬件不可用时回退 CPU；导出结果记录实际使用的编码器。
- **同步版本与图标**：应用、安装程序及构建产物保持同一版本号。
- **打包测试**：在每个目标操作系统打开真实窗口，使用打包内的 FFmpeg 压缩中文名称视频，再解码验证成品；Windows 还测试安装后的程序。

支持批量拖放、并行处理、中英文切换、H.264/H.265、质量与分辨率选择。
GPU 是否出现取决于当前设备、驱动以及实际编码测试结果。H.264 为兼容性优先的默认格式。

## 使用

1. 添加视频或将视频拖入窗口。
2. 保持自动编码模式，按需要选择质量、分辨率和输出目录。
3. 如需更多并行任务，展开「高级设置」，将并行上限设为 1–8。数值更高不一定更快。
4. 开始压缩后可继续添加视频；需要临时停下来时选择「暂停队列」，让正在处理的文件完成。
5. 右键任务可取消、优先处理或重新排队；双击任务可查看本项设置、结果和保存位置。
6. 重新打开工具后，先核对恢复的任务再继续。已完成结果保留，中断文件从头处理。

Windows：使用 `EllaPuede视频压缩工具_3.4.0_Windows_x64_Setup.exe`，或解压便携包后运行其中的 `.exe`。便携包必须完整解压，不能只复制主程序。

macOS：选择对应 Apple Silicon（arm64）或 Intel（x64）的 DMG，将应用拖到 Applications。应用内附 FFmpeg，无需自行配置 PATH。

当前构建工作流上传测试产物到 GitHub Actions，不会自动创建公开 Release。没有通过对应系统测试的构建，不能视为已验收。CI 的无显卡 Windows 虚拟机可以验证 CPU 路径和无 GPU 的自动检测行为；NVIDIA、AMD、Intel GPU 仍需要有对应硬件的机器验收。

输出仅保留主要视频流与一条默认音轨，不保留字幕及其他音轨；HDR 暂不转换。需要保留这些内容的交付不能直接使用当前版本替代完整转码流程。

## 从源码运行

使用 Python 3.13，并安装与本机系统、架构匹配的 FFmpeg 和 FFprobe。

```sh
python3 -m pip install -r requirements.txt
python3 video_compressor.py
```

Windows 使用 `python` 替代 `python3`。可将 FFmpeg、FFprobe 放入项目的 `ffmpeg/` 目录；开发测试也可设置 `ELLAPUEDE_FFMPEG_DIR` 指定目录。`ELLAPUEDE_DATA_DIR` 可用于隔离测试配置和日志。

## 构建与验证

必须在目标操作系统上构建，不能在 macOS 上用 PyInstaller 直接生成 Windows 程序。Python、Qt、FFmpeg 应匹配目标 CPU 架构。

```sh
python3 -m pip install -r requirements-build.txt
python3 -m unittest discover -s tests -v
```

Windows PowerShell：

```powershell
python scripts/download_ffmpeg_windows.py
python scripts/build_app.py --ffmpeg-dir ffmpeg
python scripts/run_package_test.py "dist/EllaPuede视频压缩工具/EllaPuede视频压缩工具.exe" --report windows-package-test.json
& "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe" installer.iss
```

Windows 下载固定的 [FFmpeg 8.0.1 静态构建](https://github.com/GyanD/codexffmpeg/releases/tag/8.0.1)，按发布资产的 SHA-256 校验后使用。

macOS：

```sh
brew install ffmpeg
python3 scripts/build_app.py --ffmpeg-dir "$(brew --prefix ffmpeg)/bin"
python3 scripts/run_package_test.py "dist/EllaPuede视频压缩工具.app/Contents/MacOS/EllaPuede视频压缩工具" --report macos-package-test.json
```

`EllaPuede.spec` 将 FFmpeg 作为二进制依赖交给 PyInstaller，自动收集 macOS 动态库并处理签名。构建前检查 FFmpeg 架构，避免将 Intel FFmpeg 混入 Apple Silicon 应用而依赖 Rosetta。`build-inputs.json` 记录 Python、依赖版本、FFmpeg 版本、输入二进制及应用源码 SHA-256，包含持久队列模块 `task_store.py`。Python 依赖已锁定；macOS Homebrew 及系统运行器版本会变动，因此构建输入记录是追溯依据，不声称产物逐字节可重复。

打包测试以空 PATH、独立配置目录运行，验证不依赖开发机的 FFmpeg。JSON 报告、窗口及下拉菜单截图、构建输入记录随 CI 上传。安装后的 Windows 程序也执行相同测试。

性能基准只代表报告里指定的设备、素材与编码参数；小样本的某次改善不能推断为所有视频或所有电脑都会更快。八并行验收证明设置能执行，不等于八并行总比两并行更快。

应用采用本地临时签名；对外分发时应由维护者另外配置 Windows 代码签名及 Apple Developer 签名、公证。

## 手动验收重点

- 普通 Windows 10/11 x64 用户：完整解压后，中文用户名、含空格路径正常压缩。
- 无可用 GPU：自动选择 CPU，界面不会出现不可用显卡配置。
- 有 NVIDIA、AMD、Intel GPU：短编码测试成功后显示相应选项，实际压缩能结束；驱动/会话异常时回退 CPU。
- macOS Apple Silicon / Intel：使用对应安装包，正常启动、添加视频、压缩和播放输出。
- 同名文件、重复运行、取消、大于 2 GB 文件、输出变大、损坏输入：原视频和已有输出不得被覆盖或删除。
- 运行中追加不同设置的视频，暂停后让活动任务结束，再继续：任务顺序、各项设置和结果一一对应。
- 关闭后重新打开：完成项不重复处理，中断项仍使用保存的设置；源文件被移动、替换或输出丢失时有明确反馈。
- 存储空间不足、记录不可写、同时启动第二个窗口：不可静默覆盖任务记录；恢复失败必须在界面提示。

## 开发依据与 Windows 验收边界

已核对归档仓库 README、完整 Git 历史，以及工作库的 `shecan-platform/docs/01_旧项目资产清单.md` 和 `03_执行日志.md`。资产清单与日志证明历史上有三个压缩工具副本，但其中的技术栈描述较旧；当前实现以本仓库 PyQt6 代码为准。未在所查 Markdown/文本资料中找到这款工具独立的完整开发规格。

| 历史证据 | 能确认的事实 | 当前应对 |
| --- | --- | --- |
| `d321c46`、`8fb599c`（v2.5） | 从首次运行下载 FFmpeg 改为打包内置 | FFmpeg 与 FFprobe 一起打包，清空 PATH 测试 |
| `8d3f508`（v3.0.3） | ffprobe 路径曾错误替换目录名称 | 仅替换可执行文件名，并真实读取输出元数据 |
| `02117cd`（v3.0.6） | Windows `_internal/ffmpeg` 与应用目录定位曾不一致 | 打包实际执行二进制并校验定位 |
| `24191f0`（v3.0.8） | 曾尝试 NVENC 参数、流映射调整并开始保存错误输出 | 根据实际编码探测和失败日志处理，不依赖“列出编码器”等同于“设备可用” |
| `970ad68`（v3.1） | CI 只检查应用启动后 8 秒仍存活 | 当前增加真实压缩、完整解码及安装后程序验收 |

历史提交说明不是失败机器的诊断日志，不能据此确认唯一根因。例如，可选 `-map` 是 [FFmpeg 正式支持的语法](https://www.ffmpeg.org/ffmpeg-all.html)，而旧 NVENC 高质量码率模式属于 [NVIDIA 弃用迁移范围](https://docs.nvidia.com/video-technologies/video-codec-sdk/12.1/pdf/Deprecation_Notices.pdf)。Windows 无控制台程序的标准流可能为 `None`，这是 [PyInstaller 明确说明的行为](https://pyinstaller.org/en/stable/common-issues-and-pitfalls.html)；压缩子进程必须显式处理输入输出及文本解码。

3.3.0 曾在 Windows Server 2022 无显卡运行器完成 60 项回归、真实八并行、中文/空格路径安装和卸载验收；这些历史结果不自动代表 3.4.0 通过。每个新包必须使用本次源码与产物重新执行测试并保留报告。实体 Windows 10/11 的 NVIDIA/AMD/Intel 驱动、多任务会话上限和长时间压力测试仍须对应设备验收。Mac 测试、模拟 Windows 分支或只检查 `.exe` 存在，均不能替代 Windows 安装包的实际压缩验收。并行设为 8 不保证硬件支持 8 个编码会话，硬件失败仍需可靠回退并保留诊断信息。

## 第三方软件

见 `THIRD_PARTY_NOTICES.txt`。打包的 FFmpeg、PyQt6 和 Qt 分别遵循上游许可证。对外分发时应随具体依赖构建保留完整许可证及相应源代码获取方式。
