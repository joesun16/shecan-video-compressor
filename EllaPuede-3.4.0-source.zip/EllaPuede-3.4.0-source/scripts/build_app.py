#!/usr/bin/env python3
"""Build with matched host architecture; preserve input provenance in the app."""
from __future__ import annotations
import argparse
import ast
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
VERSION = '3.4.0'


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--ffmpeg-dir', type=Path, required=True,
                        help='Directory containing ffmpeg and ffprobe for this OS/architecture')
    args = parser.parse_args()
    if platform.system() not in ('Darwin', 'Windows'):
        parser.error('Build on Windows or macOS; cross compilation is not supported.')
    # Fail before producing artifacts when app and package metadata drift.
    for filename, variable in (('video_compressor.py', 'VERSION'), ('EllaPuede.spec', 'version')):
        tree = ast.parse((ROOT / filename).read_text(encoding='utf-8'))
        values = [ast.literal_eval(node.value) for node in tree.body
                  if isinstance(node, ast.Assign) and any(
                      isinstance(target, ast.Name) and target.id == variable for target in node.targets)]
        if values != [VERSION]:
            parser.error(f'{filename} version {values} does not match build version {VERSION}')
    if f'#define AppVersion "{VERSION}"' not in (ROOT / 'installer.iss').read_text(encoding='utf-8'):
        parser.error('Windows installer version does not match build version')
    ffdir = args.ffmpeg_dir.resolve()
    suffix = '.exe' if platform.system() == 'Windows' else ''
    manifest = {'app_version': VERSION, 'platform': platform.platform(),
                'architecture': platform.machine(), 'python': platform.python_version(),
                'packages': {}, 'binaries': {}, 'source_sha256': {}}
    for filename in ('video_compressor.py', 'task_store.py', 'package_self_test.py', 'EllaPuede.spec',
                     'icon.png', 'icon.icns', 'icon.ico',
                     'ui-chevron.svg', 'ui-up.svg', 'ui-down.svg'):
        with (ROOT / filename).open('rb') as stream:
            manifest['source_sha256'][filename] = hashlib.file_digest(stream, 'sha256').hexdigest()
    for package in ('PyQt6', 'PyQt6-Qt6', 'PyQt6-sip', 'pyinstaller', 'pyinstaller-hooks-contrib'):
        manifest['packages'][package] = importlib.metadata.version(package)
    for name in ('ffmpeg', 'ffprobe'):
        path = ffdir / (name + suffix)
        if not path.is_file():
            parser.error(f'Missing {path}')
        if platform.system() == 'Darwin':
            archs = subprocess.check_output(['/usr/bin/lipo', '-archs', str(path)], text=True).split()
            if platform.machine() not in archs:
                parser.error(f'{name} architecture {archs} does not match Python {platform.machine()}. '
                             'Provide native binaries; do not silently depend on Rosetta.')
        result = subprocess.run([str(path), '-version'], capture_output=True, text=True,
                                encoding='utf-8', errors='replace', check=True, timeout=15)
        with path.open('rb') as stream:
            digest = hashlib.file_digest(stream, 'sha256').hexdigest()
        manifest['binaries'][name] = {
            'version': result.stdout.splitlines()[0], 'sha256': digest,
            'build_configuration': next((line for line in result.stdout.splitlines()
                                         if line.startswith('configuration:')), '')}
    (ROOT / 'build-inputs.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    env = dict(os.environ, ELLAPUEDE_BUILD_FFMPEG_DIR=str(ffdir),
               PYINSTALLER_CONFIG_DIR=str(ROOT / 'build' / 'pyinstaller-cache'))
    subprocess.run([sys.executable, '-m', 'PyInstaller', '--noconfirm', '--clean',
                    str(ROOT / 'EllaPuede.spec')], cwd=ROOT, env=env, check=True)
    if platform.system() == 'Darwin':
        subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict',
                        str(ROOT / 'dist' / 'EllaPuede视频压缩工具.app')], check=True)
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
