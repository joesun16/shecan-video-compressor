"""Restart, transaction and ownership tests without a GUI or real video encoder."""
import json
import os
from pathlib import Path
import sqlite3
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

from task_store import TaskStore, TaskStoreError, TaskStoreCorruptError, capture_identity


class TaskStoreTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.path = self.root / '队列 store.sqlite3'
        self.source = self.root / 'MixedCase 视频.MOV'
        self.source.write_bytes(b'original video contents')
        self.output = self.root / 'Compressed result.mp4'
        self.output.write_bytes(b'result')
        self.store = TaskStore(self.path)

    def entry(self, task_id='video-1', **extra):
        item = {'id': task_id, 'path': str(self.source), 'name': self.source.name,
                'size': self.source.stat().st_size, 'duration_text': '00:01',
                'settings': {'resolution': 180, 'quality_key': 'balanced',
                             'output_dir': str(self.root), 'parallel': 8}}
        item.update(extra)
        return item

    def result(self, **extra):
        result = {'status': 'success', 'output_path': str(self.output),
                  'input_size': self.source.stat().st_size, 'output_size': self.output.stat().st_size,
                  'encoder_key': 'cpu_h264'}
        result.update(extra)
        return result

    def artifacts(self, task_id='video-1'):
        temp = self.root / '.ellapuede-owned.mp4'
        output = self.root / 'reserved_compressed.mp4'
        temp.write_bytes(b'')
        output.write_bytes(b'')
        reservation = (output.stat().st_dev, output.stat().st_ino)
        self.store.record_artifacts(task_id, str(temp), str(output), reservation)
        temp.write_bytes(b'partial encoded video')
        return temp, output

    def test_restart_preserves_ids_order_settings_and_completed_outputs(self):
        self.store.save([self.entry('second', status='running'), self.entry('first')], {1: self.result()})
        files, results = TaskStore(self.path).load()
        self.assertEqual([item['id'] for item in files], ['second', 'first'])
        self.assertEqual(files[0]['settings']['resolution'], 180)
        self.assertEqual(files[0]['settings']['parallel'], 8)
        self.assertEqual(files[0]['path'], str(self.source))
        self.assertEqual(results[0]['status'], 'interrupted')
        self.assertEqual(results[0]['recovery_reason'], 'interrupted')
        self.assertEqual(results[1]['status'], 'success')
        self.assertEqual(results[1]['output_identity'], capture_identity(self.output))

    def test_pending_queue_is_restored_without_starting_or_creating_results(self):
        self.store.save([self.entry()], {})
        files, results = TaskStore(self.path).load()
        self.assertEqual(files[0]['status'], 'pending')
        self.assertEqual(results, {})

    def test_all_active_statuses_become_interrupted(self):
        for status in ('running', 'preparing', 'compressing'):
            with self.subTest(status=status):
                self.store.save([self.entry(status=status)], {})
                files, results = self.store.load()
                self.assertEqual(files[0]['status'], 'interrupted')
                self.assertEqual(results[0]['recovery_reason'], 'interrupted')

    def test_source_replacement_invalidates_completed_and_pending_tasks(self):
        self.store.save([self.entry('completed'), self.entry('pending')], {0: self.result()})
        replacement = self.root / 'replacement'
        replacement.write_bytes(self.source.read_bytes())
        os.replace(replacement, self.source)
        files, results = self.store.load()
        self.assertEqual([results[i]['recovery_reason'] for i in (0, 1)], ['source_changed'] * 2)
        self.assertEqual(files[0]['status'], 'interrupted')
        self.assertTrue(self.output.exists())

    def test_source_missing_is_retained_with_actionable_failure(self):
        self.store.save([self.entry()], {0: self.result()})
        self.source.unlink()
        files, results = self.store.load()
        self.assertEqual(len(files), 1)
        self.assertEqual(results[0]['status'], 'failed')
        self.assertEqual(results[0]['recovery_reason'], 'source_missing')
        self.assertTrue(results[0]['error'])

    def test_missing_and_modified_outputs_cannot_appear_completed(self):
        self.store.save([self.entry()], {0: self.result()})
        self.output.write_bytes(b'changed result')
        self.assertEqual(self.store.load()[1][0]['recovery_reason'], 'output_changed')
        self.output.unlink()
        self.assertEqual(self.store.load()[1][0]['recovery_reason'], 'output_missing')

    def test_kept_original_validated_against_source(self):
        self.store.save([self.entry()], {0: self.result(status='kept_original', output_path=str(self.source))})
        self.assertEqual(self.store.load()[1][0]['status'], 'kept_original')
        self.source.write_bytes(b'changed source')
        self.assertEqual(self.store.load()[1][0]['recovery_reason'], 'source_changed')

    def test_direct_checkpoint_survives_stale_running_gui_snapshot(self):
        files = [self.entry(status='running')]
        self.store.save(files, {})
        self.store.update_result('video-1', self.result())
        self.store.save(files, {})
        self.assertEqual(TaskStore(self.path).load()[1][0]['status'], 'success')
        # Metadata saves must not bless a subsequently modified output.
        self.output.write_bytes(b'externally edited result')
        self.store.save(files, {})
        self.assertEqual(self.store.load()[1][0]['recovery_reason'], 'output_changed')

    def test_explicit_reset_refreshes_settings_and_source_identity(self):
        self.store.save([self.entry()], {0: self.result()})
        self.source.write_bytes(b'new input')
        self.store.save([self.entry(status='queued', source_identity=capture_identity(self.source),
                                    settings={'resolution': 360, 'parallel': 4})], {})
        files, results = self.store.load()
        self.assertEqual(results, {})
        self.assertEqual(files[0]['settings'], {'resolution': 360, 'parallel': 4})
        self.assertEqual(files[0]['status'], 'queued')

    def test_remove_reorder_and_clear_only_happen_on_explicit_save(self):
        self.store.save([self.entry('a'), self.entry('b'), self.entry('c')], {2: self.result()})
        files, results = self.store.load()
        files.pop(0)
        self.assertEqual(len(self.store.load()[0]), 3)
        self.store.save([files[1], files[0]], {0: results[2]})
        saved, results = self.store.load()
        self.assertEqual([entry['id'] for entry in saved], ['c', 'b'])
        self.assertEqual(results[0]['status'], 'success')
        self.store.save([], {})
        self.assertEqual(self.store.load(), ([], {}))

    def test_invalid_json_or_duplicate_id_rejected_without_losing_saved_queue(self):
        self.store.save([self.entry()], {})
        with self.assertRaises(ValueError):
            self.store.save([self.entry(settings={'quality_key': lambda: 'bad'})], {})
        with self.assertRaises(ValueError):
            self.store.save([self.entry(), self.entry()], {})
        self.assertEqual(len(self.store.load()[0]), 1)

    def test_failed_sql_transaction_rolls_back_original_snapshot(self):
        self.store.save([self.entry()], {})
        with sqlite3.connect(self.path) as connection:
            connection.execute("CREATE TRIGGER reject_new BEFORE INSERT ON tasks WHEN NEW.id='bad' BEGIN SELECT RAISE(FAIL, 'simulated disk failure'); END")
        with self.assertRaises(TaskStoreError):
            self.store.save([self.entry('new'), self.entry('bad')], {})
        files, _ = self.store.load()
        self.assertEqual([item['id'] for item in files], ['video-1'])

    def test_worker_checkpoint_rejects_unknown_id(self):
        with self.assertRaises(TaskStoreError):
            self.store.update_result('missing', self.result())
        self.assertEqual(self.store.load(), ([], {}))

    def test_concurrent_worker_checkpoints_do_not_lose_results(self):
        self.store.save([self.entry(str(i), status='running') for i in range(8)], {})
        failures = []
        def checkpoint(index):
            try:
                self.store.update_result(str(index), self.result())
            except Exception as exc:
                failures.append(exc)
        threads = [threading.Thread(target=checkpoint, args=(i,)) for i in range(8)]
        for thread in threads:
            thread.start()
        for thread in threads:
            thread.join()
        self.assertEqual(failures, [])
        self.assertEqual(len(TaskStore(self.path).load()[1]), 8)

    def test_corruption_keeps_original_and_quarantine_copy(self):
        self.path.write_bytes(b'not a SQLite database\x00private queue evidence')
        original = self.path.read_bytes()
        with self.assertRaises(TaskStoreCorruptError) as caught:
            TaskStore(self.path)
        self.assertEqual(self.path.read_bytes(), original)
        self.assertEqual(Path(caught.exception.backup_path).read_bytes(), original)

    def test_malformed_payload_prevents_open_and_cannot_be_overwritten(self):
        self.store.save([self.entry()], {})
        with sqlite3.connect(self.path) as connection:
            connection.execute("UPDATE tasks SET payload='broken json'")
        with self.assertRaises(TaskStoreCorruptError):
            self.store.load()
        with self.assertRaises(TaskStoreError):
            self.store.save([], {})
        with sqlite3.connect(self.path) as connection:
            self.assertEqual(connection.execute('SELECT payload FROM tasks').fetchone()[0], 'broken json')

    def test_unknown_fields_are_excluded_from_snapshot(self):
        self.store.save([self.entry(ui_widget=object(), settings={'resolution': 180, 'private_token': 'do not save'})], {})
        entry = self.store.load()[0][0]
        self.assertNotIn('ui_widget', entry)
        self.assertNotIn('private_token', entry['settings'])

    def test_waiting_snapshot_preserves_checkpoint_and_explicit_queue_flags(self):
        entry = self.entry(status='waiting', priority=-2, excluded=True)
        self.store.save([entry], {})
        self.store.update_result('video-1', self.result(error_kind='none', error_details='detail'))
        self.store.save([entry], {})
        files, results = self.store.load()
        self.assertEqual(files[0]['priority'], -2)
        self.assertTrue(files[0]['excluded'])
        self.assertEqual(results[0]['status'], 'success')
        self.assertEqual(results[0]['error_details'], 'detail')

    def test_completed_callback_prunes_manifest_after_successful_rename(self):
        self.store.save([self.entry(status='running')], {})
        temp, output = self.artifacts()
        os.replace(temp, output)
        self.store.update_result('video-1', self.result(output_path=str(output)))
        with sqlite3.connect(self.path) as connection:
            self.assertEqual(connection.execute('SELECT count(*) FROM artifacts').fetchone()[0], 0)
        self.assertTrue(output.exists())

    def test_waiting_gui_snapshot_cannot_erase_recorded_running_checkpoint(self):
        entry = self.entry(status='waiting')
        self.store.save([entry], {})
        self.artifacts()
        self.store.save([entry], {})
        self.assertEqual(self.store.load()[1][0]['recovery_reason'], 'interrupted')

    def test_process_hard_exit_restores_committed_queue_and_cleans_only_own_files(self):
        script = r'''
import os, sqlite3, sys
from pathlib import Path
from task_store import TaskStore
database, source = map(Path, sys.argv[1:])
store = TaskStore(database)
store.save([{'id': 'hard-exit', 'path': str(source), 'status': 'queued',
             'settings': {'resolution': 180, 'parallel': 8}}], {})
temp = database.parent / '.ellapuede-hard-exit.mp4'
output = database.parent / 'reserved-after-crash.mp4'
temp.touch()
output.touch()
identity = output.stat()
store.record_artifacts('hard-exit', str(temp), str(output), (identity.st_dev, identity.st_ino))
temp.write_bytes(b'partial encoding')
# Interrupt a subsequent write before commit: the prior snapshot must survive.
connection = sqlite3.connect(database, isolation_level=None)
connection.execute('PRAGMA cache_size=1')
connection.execute('BEGIN IMMEDIATE')
connection.execute('DELETE FROM tasks')
os._exit(23)
'''
        child = subprocess.run([sys.executable, '-c', script, str(self.path), str(self.source)],
                               cwd=Path(__file__).resolve().parents[1], capture_output=True, timeout=15)
        self.assertEqual(child.returncode, 23, child.stderr.decode('utf-8', errors='replace'))
        store = TaskStore(self.path)
        files, results = store.load()
        self.assertEqual(files[0]['id'], 'hard-exit')
        self.assertEqual(files[0]['settings'], {'resolution': 180, 'parallel': 8})
        self.assertEqual(results[0]['status'], 'interrupted')
        self.assertEqual(results[0]['recovery_reason'], 'interrupted')
        report = store.recovery_cleanup()
        self.assertEqual(len(report['removed']), 2)
        self.assertEqual(report['errors'], [])
        self.assertEqual(self.source.read_bytes(), b'original video contents')

    def test_recovery_removes_only_recorded_owned_partial_and_empty_reservation(self):
        self.store.save([self.entry(status='running')], {})
        temp, output = self.artifacts()
        report = TaskStore(self.path).recovery_cleanup()
        self.assertCountEqual(report['removed'], [str(temp.resolve()), str(output.resolve())])
        self.assertEqual(report['errors'], [])
        self.assertTrue(self.source.exists())
        self.assertFalse(temp.exists())
        self.assertFalse(output.exists())
        self.assertEqual(self.store.recovery_cleanup()['removed'], [])

    def test_recovery_preserves_replaced_temp_and_nonempty_reserved_output(self):
        self.store.save([self.entry(status='running')], {})
        temp, output = self.artifacts()
        replacement = self.root / 'user-file'
        replacement.write_bytes(b'user video')
        os.replace(replacement, temp)
        output.write_bytes(b'user result')
        report = self.store.recovery_cleanup()
        self.assertCountEqual(report['skipped'], [str(temp.resolve()), str(output.resolve())])
        self.assertEqual(temp.read_bytes(), b'user video')
        self.assertEqual(output.read_bytes(), b'user result')

    def test_recovery_preserves_symlink_target_and_completed_output(self):
        self.store.save([self.entry(status='running')], {})
        temp, output = self.artifacts()
        temp.unlink()
        try:
            temp.symlink_to(self.source)
        except OSError:
            self.skipTest('Creating symlinks is unavailable for this account')
        self.store.update_result('video-1', self.result(output_path=str(output), output_size=0))
        report = self.store.recovery_cleanup()
        self.assertEqual(report['removed'], [])
        self.assertTrue(temp.is_symlink())
        self.assertTrue(output.exists())
        self.assertEqual(self.source.read_bytes(), b'original video contents')

    def test_artifact_record_refuses_to_claim_source_even_if_empty(self):
        self.source.write_bytes(b'')
        self.store.save([self.entry(status='running')], {})
        temp = self.root / '.ellapuede-test.mp4'
        temp.touch()
        info = self.source.stat()
        with self.assertRaises(TaskStoreError):
            self.store.record_artifacts('video-1', str(temp), str(self.source), (info.st_dev, info.st_ino))
        self.assertTrue(self.source.exists())


if __name__ == '__main__':
    unittest.main()
