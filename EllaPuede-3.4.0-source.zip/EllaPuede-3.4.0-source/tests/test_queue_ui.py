"""Real Qt queue lifecycle: persistence, live additions and independent goals."""
import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import hashlib
import json
from pathlib import Path
import subprocess
import tempfile
import time
import unittest
from unittest.mock import patch
from PyQt6.QtCore import QCoreApplication, QEvent
from PyQt6.QtWidgets import QApplication
import video_compressor as vc
from task_store import TaskStore

class QueueUiTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setStyle('Fusion')

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='ellapuede-queue-ui-')
        self.root = Path(self.temp.name)
        self.windows = []
        self.window = self.window_at(self.root / 'tasks.sqlite3')

    def tearDown(self):
        for w in reversed(self.windows):
            if w.worker:
                w.worker.stop(); w.worker.wait(5000); self.app.processEvents()
            if w.import_worker:
                w.import_worker.stop(); w.import_worker.wait(5000); self.app.processEvents()
            w.close(); w.deleteLater()
        self.app.processEvents()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        self.temp.cleanup()

    def window_at(self, path):
        w = vc.MainWindow(auto_check=False, queue_path=str(path))
        w._on_environment_ready(['cpu_h264'], '')
        w.output_edit.setText(str(self.root / 'outputs'))
        w.keep_larger_check.setChecked(True)
        w.parallel_spin.setValue(1)
        self.windows.append(w)
        return w

    def wait(self, predicate, seconds=10):
        end = time.monotonic() + seconds
        while time.monotonic() < end:
            self.app.processEvents()
            if predicate(): return
            time.sleep(.01)
        self.fail('Qt queue operation did not finish')

    def fixture(self, name):
        path = self.root / name
        subprocess.run([vc.get_ffmpeg_path(), '-v', 'error', '-nostdin', '-f', 'lavfi', '-i',
                        'testsrc2=size=640x360:rate=24:duration=1.5', '-c:v', 'libx264', '-preset',
                        'ultrafast', '-crf', '10', '-threads', '1', '-y', str(path)],
                       check=True, **vc._subprocess_kwargs(timeout=20))
        return path

    def test_real_live_queue_snapshots_pause_cancel_priority_and_recovery(self):
        paths = [self.fixture(f'clip-{i}.mp4') for i in range(3)]
        hashes = [hashlib.sha256(p.read_bytes()).hexdigest() for p in paths]
        w = self.window
        w.add_files([str(p) for p in paths[:2]])
        w.resolution_combo.setCurrentIndex(4)
        original = vc.CompressionWorker._build_command
        def paced(worker, *args, **kwargs):
            cmd = original(worker, *args, **kwargs)
            cmd.insert(cmd.index('-i'), '-re')
            return cmd
        with patch.object(vc.CompressionWorker, '_build_command', paced):
            w.start_compression()
            self.wait(lambda: bool(w.worker.active_indices()))
            w.toggle_queue_pause()
            w.resolution_combo.setCurrentIndex(2)
            w.add_files([str(paths[2])])
            self.wait(lambda: 0 in w.results)
            self.assertTrue(w._is_compressing)
            self.assertEqual(w.worker.active_indices(), [])
            self.assertEqual(w.worker.pending_indices(), [1, 2])
            self.assertFalse(w.open_output_btn.isHidden())
            self.assertEqual(w.files[0]['settings']['resolution'], 360)
            self.assertEqual(w.files[2]['settings']['resolution'], 720)
            w.prioritize_rows([2]); w.cancel_rows([1]); self.app.processEvents()
            self.assertEqual(w.worker.pending_indices(), [2])
            w.toggle_queue_pause()
            self.wait(lambda: not w._is_compressing)
        self.assertEqual([w.results[i]['status'] for i in range(3)], ['success', 'cancelled', 'success'])
        self.assertNotIn(1, w._pending_rows())
        for i in (0, 2):
            subprocess.run([vc.get_ffmpeg_path(), '-v', 'error', '-i', w.results[i]['output_path'], '-f', 'null', '-'],
                           check=True, **vc._subprocess_kwargs(timeout=20))
        self.assertEqual(hashes, [hashlib.sha256(p.read_bytes()).hexdigest() for p in paths])
        files, results = TaskStore(self.root / 'tasks.sqlite3').load()
        self.assertEqual(results[0]['status'], 'success')
        self.assertEqual(results[2]['settings']['resolution'], 720)
        self.assertTrue(files[1]['excluded'])
        self.assertEqual(list((self.root / 'outputs').glob('.ellapuede-*')), [])

    def test_restart_retains_goal_and_never_autostarts(self):
        path = self.fixture('resume.mp4'); w = self.window
        w.add_files([str(path)])
        w.files[0]['settings'] = dict(w._current_settings(), resolution=180)
        w.files[0]['status'] = 'running'; w._persist_queue(); w.close()
        restored = self.window_at(self.root / 'tasks.sqlite3')
        self.assertFalse(restored._is_compressing)
        self.assertEqual(restored.results[0]['status'], 'interrupted')
        restored.resolution_combo.setCurrentIndex(2); restored.start_compression()
        self.wait(lambda: not restored._is_compressing)
        self.assertEqual(restored.results[0]['status'], 'success', restored.results[0])
        info = vc.probe_video_info(restored.results[0]['output_path'])
        self.assertEqual((info['width'], info['height']), (320, 180))

    def test_second_window_cannot_overwrite_owned_queue(self):
        self.window.add_files([str(self.fixture('locked.mp4'))])
        second = self.window_at(self.root / 'tasks.sqlite3')
        self.assertTrue(second._queue_blocked)
        self.assertFalse(second.start_btn.isEnabled())
        second.clear_files(); second.close()
        files, _ = TaskStore(self.root / 'tasks.sqlite3').load()
        self.assertEqual(len(files), 1)

    def test_persistence_failure_prevents_new_run(self):
        self.window.add_files([str(self.fixture('save-failure.mp4'))])
        with patch.object(self.window._task_store, 'save', side_effect=OSError('disk unavailable')), patch.object(vc, 'CompressionWorker') as worker:
            self.window.start_compression()
            worker.assert_not_called()
            self.assertTrue(self.window._store_error)
            self.assertFalse(self.window.queue_notice.isHidden())

    def test_active_import_finishes_after_old_worker_closed_and_runs_late_batch(self):
        w = self.window; path = self.fixture('late.mp4')
        w._import_settings = w._current_settings(); w._is_importing = True; w._import_start_count = 0
        entry = {'id': 'late', 'path': str(path), 'name': path.name, 'size': path.stat().st_size}
        w._on_import_batch([entry])
        self.assertEqual(w._late_rows, [0])
        with patch.object(w, 'start_compression') as start:
            w._on_import_finished()
            start.assert_called_once_with(rows=[0])

    def test_diagnostics_omit_sensitive_paths_and_raw_errors(self):
        path = self.fixture('customer-secret.mp4'); w = self.window; w.add_files([str(path)])
        w.results[0] = {'status': 'failed', 'error_kind': 'invalid_input', 'error': str(path),
                        'error_details': str(path), 'output_path': str(path)}
        target = self.root / 'diagnostics.json'
        with patch.object(vc.QFileDialog, 'getSaveFileName', return_value=(str(target), '')):
            w.export_diagnostics()
        content = target.read_text()
        self.assertNotIn('customer-secret', content); self.assertNotIn(self.temp.name, content)
        self.assertEqual(json.loads(content)['results'][0]['error_kind'], 'invalid_input')

    def test_hardware_managed_strategy_has_no_disabled_fake_choice(self):
        w = self.window
        with patch.dict(vc.ENCODER_CONFIGS, {'test_hardware': {'has_preset': False}}):
            w._on_environment_ready(['test_hardware'], ''); w.encoder_combo.setCurrentIndex(1)
            self.assertTrue(w.speed_combo.isHidden()); self.assertFalse(w.speed_auto_label.isHidden())

if __name__ == '__main__': unittest.main()
