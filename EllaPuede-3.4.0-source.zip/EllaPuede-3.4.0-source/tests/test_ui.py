"""Native Qt regressions; no GUI desktop or real hardware is required.

These tests validate Qt state and signals on the host OS. They do not replace
the native Windows packaging/FFmpeg smoke tests in CI.
"""
import os
import sys
import tempfile
import threading
import time
import unittest
from pathlib import Path
from unittest.mock import Mock, patch

os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
_DATA = tempfile.TemporaryDirectory(prefix="ellapuede-ui-tests-", ignore_cleanup_errors=True)
os.environ["ELLAPUEDE_DATA_DIR"] = _DATA.name
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from PyQt6.QtCore import QCoreApplication, QEvent, QPoint, QRect, Qt, QTimer
from PyQt6.QtGui import QCloseEvent
from PyQt6.QtTest import QTest
from PyQt6.QtWidgets import (
    QApplication, QAbstractItemView, QPushButton, QStyle, QStyleOptionComboBox,
    QStyleOptionSpinBox,
)

import video_compressor as vc


class DeferredInfoPool:
    """Keep metadata unresolved so tests can reproduce stale-result races."""

    def __init__(self, callback, max_workers=4):
        self.callback = callback
        self.submitted = []

    def submit(self, token, filepath):
        self.submitted.append((token, filepath))

    def shutdown(self):
        pass


class MainWindowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.app = QApplication.instance() or QApplication([])
        cls.app.setStyle("Fusion")

    def setUp(self):
        self.original_language = vc.LM.current
        self.temp = tempfile.TemporaryDirectory(prefix="ellapuede-ui-files-")
        self.pool_patch = patch.object(vc, "VideoInfoPool", DeferredInfoPool)
        self.pool_patch.start()
        self.warning_patch = patch.object(vc.QMessageBox, "warning")
        self.warning_patch.start()
        self.info_patch = patch.object(vc.QMessageBox, "information")
        self.info_patch.start()
        self.window = vc.MainWindow(auto_check=False)

    def tearDown(self):
        importer = getattr(self.window, "import_worker", None)
        if importer is not None:
            importer.stop()
            importer.wait(3000)
            self.app.processEvents()
        self.window.import_worker = None
        self.window._is_importing = False
        self.window.worker = None
        self.window.environment_worker = None
        self.window._set_compressing(False)
        self.window.close()
        self.window.deleteLater()
        QCoreApplication.sendPostedEvents(None, QEvent.Type.DeferredDelete)
        self.info_patch.stop()
        self.warning_patch.stop()
        self.pool_patch.stop()
        self.temp.cleanup()
        vc.LM.current = self.original_language

    def ready(self):
        self.window._on_environment_ready(["cpu_h264"], "")

    def make_video(self, name):
        path = Path(self.temp.name) / name
        path.write_bytes(b"test fixture; metadata is mocked\n" * 32)
        return path

    def wait_until(self, predicate, timeout=3):
        deadline = time.monotonic() + timeout
        while not predicate() and time.monotonic() < deadline:
            self.app.processEvents()
            QTest.qWait(5)
        self.app.processEvents()
        self.assertTrue(predicate(), "Background operation did not finish in time")

    def test_start_stays_disabled_until_environment_is_ready(self):
        self.assertFalse(self.window.start_btn.isEnabled())
        self.window._set_compressing(False)
        self.assertFalse(self.window.start_btn.isEnabled())
        self.ready()
        self.assertTrue(self.window._environment_ready)

    def test_unavailable_environment_does_not_enable_start_after_unlock(self):
        self.window._on_environment_ready([], "FFmpeg or FFprobe unavailable")
        self.window._set_compressing(False)
        self.assertFalse(self.window.start_btn.isEnabled())
        self.assertFalse(self.window._environment_ready)

    def test_encoder_choices_include_only_successfully_probed_devices(self):
        self.ready()
        keys = self.window.available_encoder_keys
        self.assertIn("cpu_h264", keys)
        self.assertTrue(set(keys).issubset({"auto", "cpu_h264"}))
        self.assertNotIn("nvidia", keys)
        self.assertNotIn("amd", keys)
        self.assertNotIn("intel", keys)
        self.assertEqual(keys[self.window.encoder_combo.currentIndex()], "auto")

    def test_duplicate_paths_in_one_batch_are_added_once(self):
        path = self.make_video("中文 MyVideo.MP4")
        (path.parent / "sub").mkdir()
        alias = path.parent / "sub" / ".." / path.name
        candidates = [str(path), str(path), str(alias)]
        if os.name == "nt":
            # Windows aliases must deduplicate without lowercasing the name
            # shown to the user or the path handed to FFmpeg.
            candidates.insert(0, str(path).swapcase())
        self.window.add_files(candidates)
        self.assertEqual(len(self.window.files), 1)
        self.assertEqual(self.window.table.rowCount(), 1)
        self.assertEqual(len(self.window.info_pool.submitted), 1)
        self.assertEqual(self.window.files[0]["path"], os.path.realpath(path))
        self.assertEqual(self.window.files[0]["name"], path.name)
        self.assertEqual(self.window.table.item(0, 0).text(), path.name)

    def test_delayed_metadata_tracks_file_identity_after_row_removal(self):
        first = self.make_video("first.mp4")
        second = self.make_video("second.mp4")
        self.window.add_files([str(first), str(second)])
        first_token = self.window.files[0]["id"]
        second_token = self.window.files[1]["id"]
        self.window.table.selectRow(0)
        self.window.remove_selected()
        before = self.window.table.item(0, 1).text()
        self.window._on_video_info_from_pool(first_token, "9:59")
        self.assertEqual(self.window.table.item(0, 1).text(), before)
        self.window._on_video_info_from_pool(second_token, "1:23")
        self.assertEqual(self.window.table.item(0, 1).text(), "1:23")

    def test_metadata_from_cleared_queue_cannot_change_readded_same_path(self):
        path = self.make_video("same.mp4")
        self.window.add_files([str(path)])
        old_token = self.window.files[0]["id"]
        self.window.clear_files()
        self.window.add_files([str(path)])
        self.assertNotEqual(self.window.files[0]["id"], old_token)
        before = self.window.table.item(0, 1).text()
        self.window._on_video_info_from_pool(old_token, "9:59")
        self.assertEqual(self.window.table.item(0, 1).text(), before)

    def test_metadata_table_cannot_be_edited_into_false_file_names(self):
        self.assertEqual(
            self.window.table.editTriggers(),
            QAbstractItemView.EditTrigger.NoEditTriggers,
        )

    def test_compression_allows_new_jobs_but_protects_active_rows(self):
        self.ready()
        first = self.make_video("first.mp4")
        second = self.make_video("second.mp4")
        self.window.add_files([str(first)])
        self.window.table.selectRow(0)
        self.window._set_compressing(True)
        self.assertTrue(self.window.output_edit.isEnabled())
        self.assertTrue(self.window.add_file_btn.isEnabled())
        self.window.add_files([str(second)])
        self.window.remove_selected()
        self.window.clear_files()
        self.assertEqual([f["path"] for f in self.window.files], [os.path.realpath(first), os.path.realpath(second)])
        self.assertFalse(self.window.start_btn.isEnabled())
        self.assertTrue(self.window.stop_btn.isEnabled())
        self.assertFalse(self.window.parallel_spin.isEnabled())

    def test_close_defers_while_compression_thread_is_running(self):
        worker = Mock()
        worker.isRunning.return_value = True
        self.window.worker = worker
        self.window._set_compressing(True)
        event = QCloseEvent()
        self.window.closeEvent(event)
        self.assertFalse(event.isAccepted())
        self.assertTrue(self.window._close_pending)
        worker.stop.assert_called()

    def test_close_defers_while_environment_thread_is_running(self):
        detector = Mock()
        detector.isRunning.return_value = True
        self.window.environment_worker = detector
        event = QCloseEvent()
        self.window.closeEvent(event)
        self.assertFalse(event.isAccepted())
        self.assertTrue(self.window._close_pending)

    def test_language_switch_cannot_interrupt_active_compression(self):
        self.ready()
        path = self.make_video("active.mp4")
        self.window.add_files([str(path)])
        token = self.window.files[0]["id"]
        language = vc.get_lang()
        self.window._set_compressing(True)
        self.assertFalse(self.window.language_menu.isEnabled())
        self.window.switch_language("en" if language == "zh" else "zh")
        self.assertEqual(vc.get_lang(), language)
        self.assertEqual(self.window.files[0]["id"], token)
        self.assertTrue(self.window._is_compressing)

    def test_summary_signal_does_not_unlock_start_before_thread_finished(self):
        self.ready()
        self.window.add_files([str(self.make_video("finishing.mp4"))])
        self.window._set_compressing(True)
        self.window.on_all_done(1, 0, 1, 100, 50, False)
        self.assertTrue(self.window._is_compressing)
        self.assertFalse(self.window.start_btn.isEnabled())

    def test_language_switch_preserves_queue_and_user_settings(self):
        self.ready()
        path = self.make_video("keep me.mp4")
        self.window.add_files([str(path)])
        previous_id = self.window.files[0]["id"]
        self.window.output_edit.setText(self.temp.name)
        self.window.quality_combo.setCurrentIndex(2)
        self.window.resolution_combo.setCurrentIndex(2)
        language = "en" if vc.get_lang() == "zh" else "zh"
        self.window.switch_language(language)
        self.assertEqual(vc.get_lang(), language)
        self.assertEqual(len(self.window.files), 1)
        self.assertEqual(self.window.files[0]["id"], previous_id)
        self.assertEqual(self.window.output_edit.text(), self.temp.name)
        self.assertEqual(self.window.quality_combo.currentIndex(), 2)
        self.assertEqual(self.window.resolution_combo.currentIndex(), 2)

    def test_large_video_sizes_survive_qt_signals(self):
        worker = vc.CompressionWorker([], {"encoder_key": "cpu_h264"})
        results = []
        summaries = []
        worker.file_done.connect(lambda *args: results.append(args))
        worker.all_done.connect(lambda *args: summaries.append(args))
        in_size, out_size = 6 * 1024**3, 3 * 1024**3
        worker.file_done.emit(0, True, out_size)
        worker.all_done.emit(1, 0, 1, in_size, out_size, False)
        self.assertEqual(results, [(0, True, out_size)])
        self.assertEqual(summaries, [(1, 0, 1, in_size, out_size, False)])

    def test_simple_view_hides_advanced_settings_by_default(self):
        self.window.show()
        self.app.processEvents()
        self.assertFalse(self.window.advanced_btn.isChecked())
        self.assertFalse(self.window.advanced_panel.isVisible())
        self.assertFalse(self.window.encoder_combo.isVisible())
        self.assertFalse(self.window.parallel_spin.isVisible())
        self.assertTrue(self.window.quality_combo.isVisible())
        self.assertTrue(self.window.resolution_combo.isVisible())
        self.assertTrue(self.window.output_edit.isVisible())

    def test_output_action_requires_a_successful_result(self):
        self.ready()
        self.window.show()
        self.window.add_files([str(self.make_video("source.mp4"))])
        self.assertTrue(self.window.open_output_btn.isHidden())
        for status in ("kept_original", "failed", "cancelled"):
            with self.subTest(status=status):
                self.window.on_result_detail(0, {"status": status})
                self.window._set_compressing(False)
                self.assertTrue(self.window.open_output_btn.isHidden())
        output = self.make_video("source_compressed.mp4")
        self.window.on_result_detail(0, {
            "status": "success", "output_path": str(output), "output_size": 123,
        })
        self.window._set_compressing(False)
        self.assertFalse(self.window.open_output_btn.isHidden())
        self.window.clear_files()
        self.assertTrue(self.window.open_output_btn.isHidden())

    def test_chinese_and_english_combo_labels_fit_the_edit_field(self):
        # Exercise every shipped device label, including Windows-only labels,
        # while mocking detection so this remains a host-independent UI check.
        keys = ["cpu_h264", "cpu_h265", "apple_h264", "apple_h265", "nvidia", "amd", "intel"]
        for language in ("zh", "en"):
            self.window.switch_language(language)
            self.window._on_environment_ready(keys, "")
            self.window.show()
            self.window.advanced_btn.setChecked(True)
            self.window.resize(self.window.minimumWidth(), self.window.minimumHeight())
            self.app.processEvents()
            for name in ("quality_combo", "resolution_combo", "encoder_combo", "speed_combo"):
                combo = getattr(self.window, name)
                for index in range(combo.count()):
                    combo.setCurrentIndex(index)
                    self.app.processEvents()
                    option = QStyleOptionComboBox()
                    combo.initStyleOption(option)
                    edit = combo.style().subControlRect(
                        QStyle.ComplexControl.CC_ComboBox, option,
                        QStyle.SubControl.SC_ComboBoxEditField, combo,
                    )
                    with self.subTest(language=language, control=name, label=combo.currentText()):
                        self.assertGreaterEqual(
                            edit.width(), combo.fontMetrics().horizontalAdvance(combo.currentText()),
                            "Selected text must fit without clipping into the dropdown arrow",
                        )

    def test_expanded_settings_and_guide_do_not_overlap_the_queue(self):
        self.ready()
        self.window.show()
        for language in ("zh", "en"):
            self.window.switch_language(language)
            central = self.window.centralWidget()

            def bounds(widget):
                return QRect(widget.mapTo(central, QPoint(0, 0)), widget.size())

            self.window.advanced_btn.setChecked(True)
            for show_guide in (False, True):
                self.window.guide_btn.setChecked(show_guide)
                self.window._toggle_guide()
                for extra_width in (200, 0):
                    with self.subTest(language=language, guide=show_guide, extra_width=extra_width):
                        self.window.resize(self.window.minimumWidth() + extra_width, self.window.minimumHeight())
                        self.app.processEvents()
                        sections = [
                            self.window.advanced_panel, self.window.output_edit, self.window.drop_area,
                            self.window.add_file_btn, self.window.table, self.window.start_btn,
                        ]
                        for before, after in zip(sections, sections[1:]):
                            self.assertLess(bounds(before).bottom(), bounds(after).top())
                        for widget in sections:
                            self.assertTrue(central.rect().contains(bounds(widget)))
                        self.assertGreaterEqual(self.window.table.height(), 145)
                        if show_guide:
                            self.assertTrue(bounds(self.window.advanced_panel).contains(bounds(self.window.guide_panel)))

    def test_collapsed_advanced_values_are_used_for_compression(self):
        self.ready()
        self.window.add_files([str(self.make_video("advanced.mp4"))])
        self.window.advanced_btn.setChecked(True)
        self.window.encoder_combo.setCurrentIndex(self.window.available_encoder_keys.index("cpu_h264"))
        self.window.speed_combo.setCurrentIndex(2)
        self.window.parallel_spin.setValue(8)
        self.window.keep_larger_check.setChecked(True)
        self.window.advanced_btn.setChecked(False)
        with patch.object(vc, "CompressionWorker") as worker_class:
            self.window.start_compression()
            settings = worker_class.call_args.args[1]
        self.assertEqual(settings["encoder_key"], "cpu_h264")
        self.assertEqual(settings["speed_key"], "high_compress")
        self.assertEqual(settings["parallel"], 8)
        self.assertTrue(settings["keep_larger"])

    def test_parallel_eight_is_available_and_survives_preference_restore(self):
        self.assertEqual(self.window.parallel_spin.maximum(), 8)
        self.window.parallel_spin.setValue(8)
        preferences = self.window._preferences()
        self.window.parallel_spin.setValue(2)
        self.window._apply_preferences(preferences)
        self.assertEqual(self.window.parallel_spin.value(), 8)

    def test_resume_only_processes_unfinished_files_and_preserves_completed_results(self):
        self.ready()
        files = [self.make_video(f"item-{number}.mp4") for number in range(5)]
        self.window.add_files([str(path) for path in files])
        self.window.results = {
            0: {"status": "success", "output_size": 50, "output_path": str(files[0])},
            1: {"status": "kept_original"},
            2: {"status": "cancelled"},
            3: {"status": "failed", "error": "retry this file"},
        }
        self.window.update_count()
        with patch.object(vc, "CompressionWorker") as worker_class:
            self.window.start_compression()
            queued, _settings = worker_class.call_args.args
        self.assertEqual([entry["path"] for entry in queued], [os.path.realpath(path) for path in files[2:]])
        self.assertEqual(self.window._run_rows, [2, 3, 4])
        self.assertEqual(self.window.results[0]["status"], "success")
        self.assertEqual(self.window.results[1]["status"], "kept_original")

    def test_start_after_all_files_finished_explicitly_allows_recompression(self):
        self.ready()
        files = [self.make_video(f"done-{number}.mp4") for number in range(2)]
        self.window.add_files([str(path) for path in files])
        self.window.results = {0: {"status": "success", "output_size": 50}, 1: {"status": "kept_original"}}
        self.window.update_count()
        self.assertNotEqual(self.window.start_btn.text(), vc.tr("start"))
        with patch.object(vc, "CompressionWorker") as worker_class:
            self.window.start_compression()
            queued, _settings = worker_class.call_args.args
        self.assertEqual([entry["path"] for entry in queued], [os.path.realpath(path) for path in files])
        self.assertEqual(self.window._run_rows, [0, 1])

    def test_popup_rows_are_spacious_and_keyboard_selection_works(self):
        self.ready()
        self.window.show()
        self.window.advanced_btn.setChecked(True)
        self.app.processEvents()
        for name in ("quality_combo", "resolution_combo", "encoder_combo", "speed_combo"):
            with self.subTest(control=name):
                combo = getattr(self.window, name)
                combo.setCurrentIndex(0)
                combo.showPopup()
                self.app.processEvents()
                view = combo.view()
                self.assertTrue(view.isVisible())
                for index in range(combo.count()):
                    row = view.visualRect(combo.model().index(index, 0))
                    self.assertGreaterEqual(row.height(), 32, "Popup items must not use the cramped native row height")
                    self.assertGreaterEqual(row.width(), combo.fontMetrics().horizontalAdvance(combo.itemText(index)))
                QTest.keyClick(view, Qt.Key.Key_End)
                QTest.keyClick(view, Qt.Key.Key_Return)
                self.app.processEvents()
                self.assertEqual(combo.currentIndex(), combo.count() - 1)
                combo.hidePopup()

    def test_visible_input_fields_leave_space_for_text_and_arrow_controls(self):
        self.ready()
        self.window.show()
        self.window.advanced_btn.setChecked(True)
        self.window.parallel_spin.setValue(8)
        self.app.processEvents()
        for name in ("quality_combo", "resolution_combo", "encoder_combo", "speed_combo"):
            combo = getattr(self.window, name)
            self.assertGreaterEqual(combo.height(), 34, name)
        spin = self.window.parallel_spin
        option = QStyleOptionSpinBox()
        spin.initStyleOption(option)
        rectangles = {
            name: spin.style().subControlRect(QStyle.ComplexControl.CC_SpinBox, option, part, spin)
            for name, part in (
                ("text", QStyle.SubControl.SC_SpinBoxEditField),
                ("up", QStyle.SubControl.SC_SpinBoxUp),
                ("down", QStyle.SubControl.SC_SpinBoxDown),
            )
        }
        self.assertGreaterEqual(rectangles["text"].width(), spin.fontMetrics().horizontalAdvance(spin.text()))
        self.assertFalse(rectangles["text"].intersects(rectangles["up"]))
        self.assertFalse(rectangles["text"].intersects(rectangles["down"]))

    def test_import_scans_off_the_gui_thread_and_keeps_event_loop_responsive(self):
        self.ready()
        path = self.make_video("slow-folder.mp4")
        entered, release = threading.Event(), threading.Event()
        scan_threads = []
        main_thread = threading.get_ident()

        def slow_candidates(_worker):
            scan_threads.append(threading.get_ident())
            entered.set()
            release.wait(3)
            yield str(path)

        try:
            with patch.object(vc.FileImportWorker, "_candidates", slow_candidates):
                self.window.import_paths([self.temp.name])
                self.assertTrue(entered.wait(1))
                self.assertNotEqual(scan_threads, [main_thread])
                ticks = []
                QTimer.singleShot(0, lambda: ticks.append(True))
                self.app.processEvents()
                self.assertEqual(ticks, [True])
                self.assertTrue(self.window._is_importing)
                self.assertFalse(self.window.start_btn.isEnabled())
                self.assertFalse(self.window.language_menu.isEnabled())
                self.assertFalse(self.window.clear_btn.isEnabled())
                self.assertTrue(self.window.stop_btn.isEnabled())
                release.set()
                self.wait_until(lambda: not self.window._is_importing)
        finally:
            release.set()
        self.assertEqual([entry["path"] for entry in self.window.files], [os.path.realpath(path)])
        self.assertTrue(self.window.start_btn.isEnabled())

    def test_directory_import_recurses_and_deduplicates_across_batches(self):
        self.ready()
        root = Path(self.temp.name)
        nested = root / "子目录" / "nested"
        nested.mkdir(parents=True)
        existing = self.make_video("already.MP4")
        expected = {os.path.realpath(existing)}
        for index in range(130):
            path = nested / f"clip-{index}.MOV"
            path.write_bytes(b"fixture")
            expected.add(os.path.realpath(path))
        (nested / "ignored.txt").write_text("not a video", encoding="utf-8")
        (nested / "directory.mp4").mkdir()
        self.window.add_files([str(existing)])
        candidates = [str(root), str(nested), str(existing)]
        if os.name == "nt":
            candidates.extend([str(nested).swapcase(), str(existing).swapcase()])
        self.window.import_paths(candidates)
        self.wait_until(lambda: not self.window._is_importing)
        actual = [entry["path"] for entry in self.window.files]
        self.assertEqual(set(actual), expected)
        self.assertEqual(len(actual), len(expected))
        self.assertEqual(self.window.table.rowCount(), len(expected))
        for row, entry in enumerate(self.window.files):
            self.assertEqual(entry["name"], os.path.basename(entry["path"]))
            self.assertEqual(self.window.table.item(row, 0).text(), entry["name"])
            self.assertTrue(entry["name"].endswith((".MP4", ".MOV")))

    def test_import_cancellation_keeps_added_rows_and_discards_queued_batches(self):
        self.ready()
        files = [self.make_video(f"cancel-import-{index}.mp4") for index in range(200)]
        accepted_at_stop = []
        original_slot = self.window._on_import_batch

        def stop_after_first_batch(entries):
            original_slot(entries)
            if not accepted_at_stop:
                accepted_at_stop.append(len(self.window.files))
                self.window.stop_compression()

        with patch.object(self.window, "_on_import_batch", stop_after_first_batch):
            self.window.import_paths([str(path) for path in files])
            self.wait_until(lambda: not self.window._is_importing)
        self.assertEqual(accepted_at_stop, [64])
        self.assertEqual(len(self.window.files), accepted_at_stop[0])
        self.assertEqual(self.window.table.rowCount(), accepted_at_stop[0])
        self.assertEqual(self.window.progress_label.text(), vc.tr("import_stopped").format(count=64))
        self.assertTrue(self.window.start_btn.isEnabled())

    def test_close_waits_for_an_actual_import_thread_and_discards_its_pending_file(self):
        path = self.make_video("close-import.mp4")
        entered, release = threading.Event(), threading.Event()

        def slow_candidates(_worker):
            entered.set()
            release.wait(3)
            yield str(path)

        self.window.show()
        try:
            with patch.object(vc.FileImportWorker, "_candidates", slow_candidates):
                self.window.import_paths([str(path)])
                self.assertTrue(entered.wait(1))
                event = QCloseEvent()
                self.window.closeEvent(event)
                self.assertFalse(event.isAccepted())
                self.assertTrue(self.window._close_pending)
                release.set()
                self.wait_until(lambda: self.window.import_worker is None)
        finally:
            release.set()
        self.assertFalse(self.window.isVisible())
        self.assertEqual(self.window.files, [])

    def test_duplicate_import_after_completion_does_not_leave_importing_status(self):
        self.ready()
        path = self.make_video("already-done.mp4")
        self.window.add_files([str(path)])
        self.window.results[0] = {"status": "success", "output_size": 123}
        self.window.update_count()
        self.window.import_paths([str(path)])
        self.wait_until(lambda: not self.window._is_importing)
        self.assertEqual(len(self.window.files), 1)
        self.assertEqual(self.window.progress_label.text(), vc.tr("import_empty"))
        self.assertEqual(self.window.start_btn.text(), vc.tr("recompress"))


if __name__ == "__main__":
    unittest.main()
