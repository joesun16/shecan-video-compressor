#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
EllaPuede 视频批量压缩工具 V3.3.0
跨平台支持 (macOS / Windows)
FFmpeg 内置，双语界面，并行压缩
"""

import sys
import os
import subprocess
import re
import platform
import multiprocessing
import json
import threading
import logging
import uuid
import time
from logging.handlers import RotatingFileHandler
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QComboBox, QProgressBar, QFileDialog,
    QTableWidget, QTableWidgetItem, QHeaderView, QFrame, QLineEdit,
    QAbstractItemView, QDialog, QMessageBox, QSpinBox,
    QScrollArea, QMenu, QCheckBox, QListView, QStyledItemDelegate,
    QStyle, QStyleOptionComboBox
)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QLocale, QTimer, QUrl, QLockFile
from PyQt6.QtGui import QColor, QAction, QShortcut, QKeySequence, QIcon, QDesktopServices
from task_store import TaskStore, capture_identity

# ============ 常量 ============
VERSION = '3.4.0'
APP_NAME = 'EllaPuede'
IS_MAC = platform.system() == 'Darwin'
IS_WIN = platform.system() == 'Windows'
CPU_COUNT = multiprocessing.cpu_count()

VIDEO_EXTENSIONS = {
    '.mp4', '.mkv', '.avi', '.mov', '.wmv', '.flv',
    '.webm', '.m4v', '.mpg', '.mpeg', '.ts', '.3gp', '.vob'
}

VIDEO_FILTER_STR = ' '.join(f'*{ext}' for ext in sorted(VIDEO_EXTENSIONS))

RESOLUTION_OPTIONS = [
    ('keep_original', None),
    ('1080p', 1080),
    ('720p', 720),
    ('480p', 480),
    ('360p', 360),
]

# ============ 日志 ============
DATA_DIR = os.environ.get('ELLAPUEDE_DATA_DIR')
if DATA_DIR:
    LOG_DIR = os.path.join(DATA_DIR, 'logs')
elif IS_WIN:
    LOG_DIR = os.path.join(os.environ.get('LOCALAPPDATA', os.path.expanduser('~')),
                           APP_NAME, 'VideoCompressor', 'logs')
else:
    LOG_DIR = os.path.expanduser(f'~/Library/Logs/{APP_NAME}/VideoCompressor')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
try:
    os.makedirs(LOG_DIR, exist_ok=True)
    handler = RotatingFileHandler(os.path.join(LOG_DIR, 'app.log'),
                                  maxBytes=2_000_000, backupCount=3, encoding='utf-8')
    handler.setFormatter(logging.Formatter('%(asctime)s [%(levelname)s] %(message)s'))
    logger.addHandler(handler)
except OSError:
    logger.addHandler(logging.NullHandler())
if sys.stderr is not None:
    logger.addHandler(logging.StreamHandler())


# ============ 语言管理 ============
TEXTS = {
    'zh': {
        'app_title': f'{APP_NAME} 视频压缩工具',
        'batch_compress': '视频批量压缩',
        'encoder_mode': '编码模式',
        'quality': '质量',
        'speed': '速度',
        'resolution': '分辨率',
        'output_dir': '输出目录',
        'output_placeholder': '默认保存到原文件所在目录',
        'select': '选择',
        'clear': '清除',
        'drop_hint': '拖放视频文件到这里，或点击选择',
        'format_hint': '支持 MP4、MKV、AVI、MOV 等格式',
        'add_files': '添加文件',
        'add_folder': '添加文件夹',
        'remove_selected': '移除选中',
        'clear_list': '清空列表',
        'start': '开始压缩',
        'stop': '停止',
        'ready': '就绪',
        'preparing': '准备中...',
        'compressing': '压缩中',
        'waiting': '等待',
        'failed': '失败',
        'cancelled': '已取消',
        'stopping': '正在停止...',
        'stopped': '已停止',
        'col_filename': '文件名',
        'col_duration': '时长',
        'col_size': '大小',
        'col_progress': '进度',
        'col_output': '压缩后',
        'col_status': '状态',
        'high_quality': '高质量',
        'balanced': '平衡',
        'small_size': '小体积',
        'extreme': '极致压缩',
        'fast': '快速',
        'high_compress': '高压缩',
        'keep_original': '保持原始',
        'compress_done': '压缩完成',
        'compress_stopped': '压缩已停止',
        'files_processed': '成功处理:',
        'files_failed': '失败:',
        'original_size': '原始大小:',
        'compressed_size': '压缩后:',
        'space_saved': '节省空间:',
        'size_increased': '体积增加:',
        'ok': '确定',
        'hint': '提示',
        'error': '错误',
        'add_files_first': '请先添加视频文件',
        'select_output': '选择输出目录',
        'select_video': '选择视频文件',
        'select_folder': '选择文件夹',
        'video_files': '视频文件',
        'all_files': '所有文件',
        'cannot_create_dir': '无法创建输出目录',
        'language': '语言',
        'chinese': '中文',
        'english': 'English',
        'restart_hint': '语言切换将在重启后生效',
        'ffmpeg_ready': '● FFmpeg 就绪',
        'ffmpeg_not_found': '● FFmpeg 未找到',
        'ffmpeg_error_mac': '请安装 FFmpeg:\nbrew install ffmpeg\n或从 https://ffmpeg.org 下载',
        'ffmpeg_error_win': '请安装 FFmpeg:\n从 https://ffmpeg.org 下载并添加到系统 PATH',
        'missing_dep': '缺少依赖',
        'parallel': '并行数',
        'parallel_tip': '同时压缩的文件数量（GPU编码建议2-4，CPU编码建议1-2）',
        'file_count': '共 {count} 个文件，{size}',
        'processing': '处理中 {current}/{total}',
        'done': '完成 {completed}/{total}',
        'size_increased_auto': '压缩后体积增大，已自动删除输出文件',
        # 编码器名称 — 使用内部 key，不再用翻译文本做 dict key
        'enc_cpu_h264': 'CPU H.264 (兼容性最好)',
        'enc_cpu_h265': 'CPU H.265 (体积更小)',
        'enc_apple_h264': 'Apple GPU H.264 (推荐)',
        'enc_apple_h265': 'Apple GPU H.265',
        'enc_nvidia': 'NVIDIA GPU (N卡加速)',
        'enc_amd': 'AMD GPU (A卡加速)',
        'enc_intel': 'Intel GPU (核显加速)',
        # 编码器提示
        'info_apple': '使用 Apple 硬件加速，速度快',
        'info_nvidia': '使用 NVIDIA GPU 加速',
        'info_amd': '使用 AMD GPU 加速',
        'info_intel': '使用 Intel 核显加速',
        'info_h265': 'H.265 编码，体积更小但兼容性稍差',
        'info_cpu': 'CPU 编码，兼容性最好',
        'speed_not_available': '当前编码器不支持速度调节',
        'guide_toggle': '💡 参数指南',
        'guide_content': (
            '<b>🎯 常见场景推荐组合：</b><br><br>'
            '<b>📱 发社交媒体（微信/抖音）</b><br>'
            '编码：Apple GPU H.264 ｜ 质量：小体积 ｜ 分辨率：720p<br>'
            '→ 体积小，上传快，画质够用<br><br>'
            '<b>💾 存档备份（节省硬盘空间）</b><br>'
            '编码：CPU H.265 ｜ 质量：平衡 ｜ 速度：高压缩 ｜ 分辨率：保持原始<br>'
            '→ 压缩率最高，速度较慢，适合挂机跑<br><br>'
            '<b>🎬 剪辑素材（保留画质）</b><br>'
            '编码：Apple GPU H.264 ｜ 质量：高质量 ｜ 分辨率：保持原始<br>'
            '→ 速度快，画质损失极小<br><br>'
            '<b>📧 邮件/网盘传输（极致压缩）</b><br>'
            '编码：CPU H.265 ｜ 质量：极致压缩 ｜ 速度：高压缩 ｜ 分辨率：480p<br>'
            '→ 体积最小，适合大批量传输<br><br>'
            '<b>⚡ 快速批量处理</b><br>'
            '编码：Apple GPU H.264 ｜ 质量：平衡 ｜ 并行数：3-4<br>'
            '→ GPU 加速 + 多文件并行，速度最快'
        ),
    },
    'en': {
        'app_title': f'{APP_NAME} Video Compressor',
        'batch_compress': 'Batch Video Compression',
        'encoder_mode': 'Encoder',
        'quality': 'Quality',
        'speed': 'Speed',
        'resolution': 'Resolution',
        'output_dir': 'Output',
        'output_placeholder': 'Default: same as source file',
        'select': 'Browse',
        'clear': 'Clear',
        'drop_hint': 'Drop video files here, or click to select',
        'format_hint': 'Supports MP4, MKV, AVI, MOV, etc.',
        'add_files': 'Add Files',
        'add_folder': 'Add Folder',
        'remove_selected': 'Remove',
        'clear_list': 'Clear All',
        'start': 'Start',
        'stop': 'Stop',
        'ready': 'Ready',
        'preparing': 'Preparing...',
        'compressing': 'Compressing',
        'waiting': 'Waiting',
        'failed': 'Failed',
        'cancelled': 'Cancelled',
        'stopping': 'Stopping...',
        'stopped': 'Stopped',
        'col_filename': 'Filename',
        'col_duration': 'Duration',
        'col_size': 'Size',
        'col_progress': 'Progress',
        'col_output': 'Output',
        'col_status': 'Status',
        'high_quality': 'High Quality',
        'balanced': 'Balanced',
        'small_size': 'Small Size',
        'extreme': 'Extreme',
        'fast': 'Fast',
        'high_compress': 'High Compress',
        'keep_original': 'Original',
        'compress_done': 'Compression Complete',
        'compress_stopped': 'Compression Stopped',
        'files_processed': 'Processed:',
        'files_failed': 'Failed:',
        'original_size': 'Original:',
        'compressed_size': 'Compressed:',
        'space_saved': 'Saved:',
        'size_increased': 'Increased:',
        'ok': 'OK',
        'hint': 'Info',
        'error': 'Error',
        'add_files_first': 'Please add video files first',
        'select_output': 'Select Output Directory',
        'select_video': 'Select Video Files',
        'select_folder': 'Select Folder',
        'video_files': 'Video Files',
        'all_files': 'All Files',
        'cannot_create_dir': 'Cannot create output directory',
        'language': 'Language',
        'chinese': '中文',
        'english': 'English',
        'restart_hint': 'Language change will take effect after restart',
        'ffmpeg_ready': '● FFmpeg Ready',
        'ffmpeg_not_found': '● FFmpeg Not Found',
        'ffmpeg_error_mac': 'Please install FFmpeg:\nbrew install ffmpeg\nor download from https://ffmpeg.org',
        'ffmpeg_error_win': 'Please install FFmpeg:\nDownload from https://ffmpeg.org and add to PATH',
        'missing_dep': 'Missing Dependency',
        'parallel': 'Parallel',
        'parallel_tip': 'Number of simultaneous compressions (GPU: 2-4, CPU: 1-2)',
        'file_count': '{count} files, {size}',
        'processing': 'Processing {current}/{total}',
        'done': 'Done {completed}/{total}',
        'size_increased_auto': 'Output larger than input, auto-deleted',
        # Encoder names
        'enc_cpu_h264': 'CPU H.264 (Best Compatibility)',
        'enc_cpu_h265': 'CPU H.265 (Smaller Size)',
        'enc_apple_h264': 'Apple GPU H.264 (Recommended)',
        'enc_apple_h265': 'Apple GPU H.265',
        'enc_nvidia': 'NVIDIA GPU (Hardware Accel)',
        'enc_amd': 'AMD GPU (Hardware Accel)',
        'enc_intel': 'Intel GPU (Quick Sync)',
        # Encoder info
        'info_apple': 'Apple hardware acceleration, fast',
        'info_nvidia': 'NVIDIA GPU acceleration',
        'info_amd': 'AMD GPU acceleration',
        'info_intel': 'Intel Quick Sync acceleration',
        'info_h265': 'H.265 codec, smaller but less compatible',
        'info_cpu': 'CPU encoding, best compatibility',
        'speed_not_available': 'Speed control not available for this encoder',
        'guide_toggle': '💡 Guide',
        'guide_content': (
            '<b>🎯 Recommended Presets:</b><br><br>'
            '<b>📱 Social Media (small & fast)</b><br>'
            'Encoder: Apple GPU H.264 ｜ Quality: Small Size ｜ Resolution: 720p<br>'
            '→ Small file, fast upload, good enough quality<br><br>'
            '<b>💾 Archive (save disk space)</b><br>'
            'Encoder: CPU H.265 ｜ Quality: Balanced ｜ Speed: High Compress ｜ Resolution: Original<br>'
            '→ Best compression ratio, slower, good for batch overnight<br><br>'
            '<b>🎬 Editing Source (preserve quality)</b><br>'
            'Encoder: Apple GPU H.264 ｜ Quality: High Quality ｜ Resolution: Original<br>'
            '→ Fast, minimal quality loss<br><br>'
            '<b>📧 Email/Cloud Transfer (extreme)</b><br>'
            'Encoder: CPU H.265 ｜ Quality: Extreme ｜ Speed: High Compress ｜ Resolution: 480p<br>'
            '→ Smallest file size, good for bulk transfer<br><br>'
            '<b>⚡ Fast Batch Processing</b><br>'
            'Encoder: Apple GPU H.264 ｜ Quality: Balanced ｜ Parallel: 3-4<br>'
            '→ GPU acceleration + parallel, fastest throughput'
        ),
    }
}


TEXTS['zh'].update({
    'resume': '继续压缩', 'recompress': '重新压缩', 'recompress_selected': '重新压缩选中项',
    'importing': '正在导入 · 已添加 {count} 个视频', 'stop_import': '停止导入',
    'import_empty': '未发现新视频', 'import_stopped': '已停止导入 · 添加 {count} 个视频',
    'pending_count': '{count} 个视频待处理 · 已完成项不会重复压缩',
    'elapsed': '用时 {time}', 'remaining': '预计剩余 {time}',
    'parallel_tip': '最多同时处理 8 个视频。建议从 2 开始；并行越高不一定越快。',
    'enc_auto': '自动（推荐）', 'advanced': '高级设置', 'simple_title': 'EllaPuede 视频压缩', 'hardware_auto': '自动加速 · {device}', 'hardware_manual': '使用 {device}', 'source_safe': '原视频保留，结果另存', 'detecting': '正在实测本机编码能力…',
    'auto_info': '自动使用：{encoder}；硬件失败时回退 CPU',
    'keep_larger': '保留体积更大的结果（用于转格式/分辨率）',
    'kept_original': '保留原文件', 'success': '已完成', 'open_output': '打开结果目录',
    'open_logs': '打开日志', 'details': '查看结果 / 错误详情',
    'retry_failed': '重试失败项', 'refresh_hardware': '重新检测硬件', 'tools': '工具',
    'safety_note': '原文件始终保留；默认跳过体积更大的结果。MP4 输出保留主视频和默认音轨，不保留字幕。',
    'no_hardware': '没有通过实测的编码器。请查看日志并重新安装完整应用。',
    'guide_toggle': '参数指南',
    'guide_content': '<b>日常分享</b>：自动选择 · 小体积 · 720p。<br><br>'
        '<b>保留细节</b>：自动选择 · 高质量 · 保持原始。压缩有损，请先检查结果。<br><br>'
        '<b>更小输出</b>：CPU H.265 · 平衡 · 精细编码；更慢，部分设备兼容性较弱。<br><br>'
        '<b>批量处理</b>：先用并行数 2；过高会争抢资源。分辨率只缩小，不放大。<br><br>'
        '硬件模式只显示实测试编码成功的选项。HDR 视频需要先转换为 SDR。',
    'ffmpeg_not_found': '环境不可用', 'ffmpeg_ready': '本机检测完成',
    'ffmpeg_error_mac': '内置 FFmpeg / FFprobe 不完整或无法运行。请重新安装完整应用，详情见日志。',
    'ffmpeg_error_win': '内置 FFmpeg / FFprobe 不完整或无法运行。请重新安装完整应用，勿单独移动 EXE。详情见日志。',
    'files_processed': '生成结果:', 'files_kept': '保留原文件:',
})
TEXTS['en'].update({
    'resume': 'Continue', 'recompress': 'Compress again', 'recompress_selected': 'Compress selected again',
    'importing': 'Importing · {count} videos added', 'stop_import': 'Stop import',
    'import_empty': 'No new videos found', 'import_stopped': 'Import stopped · {count} videos added',
    'pending_count': '{count} videos pending · completed items are skipped',
    'elapsed': 'Elapsed {time}', 'remaining': 'About {time} remaining',
    'parallel_tip': 'Process up to 8 videos at once. Start with 2; more jobs are not always faster.',
    'enc_auto': 'Automatic (recommended)', 'advanced': 'Advanced', 'simple_title': 'EllaPuede Video Compressor', 'hardware_auto': 'Auto · {device}', 'hardware_manual': 'Using {device}', 'source_safe': 'Originals are kept; results saved separately', 'detecting': 'Testing local encoders…',
    'auto_info': 'Using: {encoder}; CPU fallback on hardware failure',
    'keep_larger': 'Keep larger results (format / resolution conversion)',
    'kept_original': 'Original kept', 'success': 'Completed', 'open_output': 'Open output folder',
    'open_logs': 'Open logs', 'details': 'Result / error details', 'retry_failed': 'Retry failed',
    'refresh_hardware': 'Detect hardware again', 'tools': 'Tools',
    'safety_note': 'Sources are always kept. Larger results are skipped by default. MP4 keeps primary video/audio tracks; no subtitles.',
    'no_hardware': 'No encoder passed the test. Check logs and reinstall the complete application.',
    'guide_toggle': 'Guide',
    'guide_content': '<b>Everyday sharing</b>: Automatic · Small Size · 720p.<br><br>'
        '<b>Keep detail</b>: Automatic · High Quality · Original. Compression is lossy; inspect results first.<br><br>'
        '<b>Smaller output</b>: CPU H.265 · Balanced · Thorough. Slower and less widely compatible.<br><br>'
        '<b>Batch</b>: Start with parallel 2. More jobs can compete for resources. Resolution never upscales.<br><br>'
        'Only tested encoders are shown. Convert HDR to SDR before compression.',
    'ffmpeg_ready': 'Local check complete', 'ffmpeg_not_found': 'Environment unavailable',
    'ffmpeg_error_mac': 'Bundled FFmpeg / FFprobe is missing or cannot run. Reinstall the full application. See logs for details.',
    'ffmpeg_error_win': 'Bundled FFmpeg / FFprobe is missing or cannot run. Reinstall the full app; do not move the EXE alone. See logs.',
    'files_processed': 'Outputs created:', 'files_kept': 'Originals kept:',
})


TEXTS['zh'].update({
    'parallel': '并行上限', 'speed': '编码策略', 'high_compress': '精细编码',
    'speed_auto': '由硬件管理', 'speed_not_available': '此硬件使用自动编码策略；不会应用软件编码速度预设。',
    'pause_queue': '暂停队列', 'resume_queue': '继续队列',
    'pause_tip': '暂停启动新任务，正在处理的文件会完成。',
    'queue_paused': '队列已暂停 · 正在处理 {active} 项，等待 {pending} 项',
    'queue_running': '已处理 {done}/{total} · 运行 {active} · 等待 {pending}',
    'cancel_selected': '取消选中任务', 'prioritize': '优先处理选中项',
    'apply_settings': '用当前设置重新排队', 'new_task_settings': '设置用于新任务；已排队任务保留原设置',
    'restored': '已恢复 {count} 个任务，请核对后继续；中断文件将从头处理',
    'interrupted': '已中断，可重新处理', 'queued': '等待', 'running': '压缩中',
    'store_error': '任务记录保存失败。当前结果可用，但退出后可能无法恢复：{error}',
    'store_locked': '另一个 EllaPuede 窗口正在使用任务记录，请先关闭它。',
    'store_unavailable': '任务记录不可用，请先解决此问题后再开始：{error}',
    'result_kept': '未生成新文件：结果没有变小，已保留原视频',
    'result_saved': '已完成 · 减少 {percent:.0f}%',
    'result_larger': '已完成 · 增加 {percent:.0f}%',
    'batch_summary': '已生成 {success} 项 · 未变小 {kept} 项 · 失败 {failed} 项 · 取消 {cancelled} 项',
    'task_settings': '本任务设置', 'space_saved': '输出体积减少:', 'saved': '输出体积减少',
    'settings_summary': '{quality} · {resolution} · 最多 {parallel} 项并行{larger}',
    'larger_summary': ' · 保留更大结果', 'retry_from_start': '中断文件从头处理；已完成结果保留',
    'import_report': '已添加 {added} 项 · 重复 {duplicate} 项 · 不支持 {unsupported} 项 · 无法读取 {unreadable} 项',
    'diagnostics': '导出诊断信息', 'diagnostics_saved': '诊断信息已保存；文件名和完整路径已隐藏。',
})
TEXTS['en'].update({
    'parallel': 'Job limit', 'speed': 'Encoding effort', 'high_compress': 'Thorough',
    'speed_auto': 'Hardware managed', 'speed_not_available': 'This hardware uses its automatic encoding policy; software speed presets do not apply.',
    'pause_queue': 'Pause queue', 'resume_queue': 'Resume queue',
    'pause_tip': 'Stop launching new jobs; running files will finish.',
    'queue_paused': 'Queue paused · {active} running, {pending} waiting',
    'queue_running': 'Processed {done}/{total} · Running {active} · Waiting {pending}',
    'cancel_selected': 'Cancel selected jobs', 'prioritize': 'Run selected next',
    'apply_settings': 'Requeue with current settings', 'new_task_settings': 'Settings apply to new jobs; queued jobs keep their settings',
    'restored': 'Restored {count} jobs. Review before continuing; interrupted files restart from the beginning.',
    'interrupted': 'Interrupted; can retry', 'queued': 'Waiting', 'running': 'Compressing',
    'store_error': 'Could not save task history. Current results are available, but recovery may fail: {error}',
    'store_locked': 'Another EllaPuede window is using this queue. Close it first.',
    'store_unavailable': 'Task history is unavailable. Resolve this before starting: {error}',
    'result_kept': 'No new file: output was not smaller; the original is retained',
    'result_saved': 'Done · {percent:.0f}% smaller',
    'result_larger': 'Done · {percent:.0f}% larger',
    'batch_summary': 'Created {success} · Not smaller {kept} · Failed {failed} · Cancelled {cancelled}',
    'task_settings': 'Job settings', 'space_saved': 'Output size reduction:', 'saved': 'Output size reduction',
    'settings_summary': '{quality} · {resolution} · Up to {parallel} jobs{larger}',
    'larger_summary': ' · Keep larger outputs', 'retry_from_start': 'Interrupted files restart; completed outputs are kept',
    'import_report': 'Added {added} · Duplicate {duplicate} · Unsupported {unsupported} · Unreadable {unreadable}',
    'diagnostics': 'Export diagnostics', 'diagnostics_saved': 'Diagnostics saved with filenames and full paths removed.',
})


class LanguageManager:
    _instance = None

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._init()
        return cls._instance

    def _init(self):
        self.current = None
        self._load_saved_language()

    def _get_config_path(self):
        if DATA_DIR:
            return os.path.join(DATA_DIR, 'config.json')
        if IS_WIN:
            base = os.environ.get('LOCALAPPDATA', os.path.expanduser('~'))
            return os.path.join(base, APP_NAME, 'VideoCompressor', 'config.json')
        return os.path.expanduser(f'~/Library/Application Support/{APP_NAME}/VideoCompressor/config.json')

    def _load_saved_language(self):
        config_path = self._get_config_path()
        try:
            if os.path.exists(config_path):
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    if config.get('language') in ('zh', 'en'):
                        self.current = config['language']
                        return
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Failed to load language config: {e}")
        # Isolated self-tests never migrate a real user configuration.
        if not DATA_DIR:
            self._migrate_old_config(config_path)
        if self.current not in ('zh', 'en'):
            self._detect_system_language()

    def _migrate_old_config(self, new_path):
        """从旧 SheCan 路径迁移配置"""
        if IS_WIN:
            base = os.environ.get('LOCALAPPDATA', os.path.expanduser('~'))
            old_path = os.path.join(base, 'SheCan', 'VideoCompressor', 'config.json')
        else:
            old_path = os.path.expanduser('~/Library/Application Support/SheCan/VideoCompressor/config.json')
        try:
            if os.path.exists(old_path) and not os.path.exists(new_path):
                with open(old_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                os.makedirs(os.path.dirname(new_path), exist_ok=True)
                with open(new_path, 'w', encoding='utf-8') as f:
                    json.dump(config, f)
                if config.get('language') in ('zh', 'en'):
                    self.current = config['language']
                logger.info(f"Migrated config from {old_path}")
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Config migration failed: {e}")

    def _detect_system_language(self):
        try:
            if IS_MAC:
                result = subprocess.run(
                    ['defaults', 'read', '-g', 'AppleLanguages'],
                    capture_output=True, text=True, timeout=2
                )
                if 'zh' in result.stdout.lower():
                    self.current = 'zh'
                    return
        except (subprocess.TimeoutExpired, OSError):
            pass
        try:
            locale_name = QLocale.system().name()
            if locale_name.startswith('zh'):
                self.current = 'zh'
                return
        except Exception:
            pass
        self.current = 'en'

    def save_language(self, lang):
        if lang not in ('zh', 'en'):
            return
        self.current = lang
        config_path = self._get_config_path()
        try:
            os.makedirs(os.path.dirname(config_path), exist_ok=True)
            config = {}
            if os.path.exists(config_path):
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
            config['language'] = lang
            with open(config_path, 'w', encoding='utf-8') as f:
                json.dump(config, f)
        except (json.JSONDecodeError, OSError) as e:
            logger.warning(f"Failed to save language: {e}")

    def get(self):
        return self.current


LM = LanguageManager()


def get_lang():
    return LM.get()


def tr(key):
    """翻译函数 — 从预构建的字典中查找"""
    return TEXTS.get(get_lang(), TEXTS['zh']).get(key, key)


# ============ FFmpeg 路径 ============
def get_ffmpeg_path():
    """Resolve bundled binaries first, including PyInstaller 6's _internal layout."""
    import shutil
    name = 'ffmpeg.exe' if IS_WIN else 'ffmpeg'
    candidates = []
    if getattr(sys, 'frozen', False):
        root = Path(sys.executable).parent
        if hasattr(sys, '_MEIPASS'):
            candidates.append(Path(sys._MEIPASS) / 'ffmpeg' / name)
        candidates.extend([root / 'ffmpeg' / name, root / '_internal' / 'ffmpeg' / name])
        if IS_MAC:
            candidates.append(root.parent / 'Resources' / 'ffmpeg' / name)
    elif os.environ.get('ELLAPUEDE_FFMPEG_DIR'):
        candidates.append(Path(os.environ['ELLAPUEDE_FFMPEG_DIR']) / name)
    candidates.append(Path(__file__).resolve().parent / 'ffmpeg' / name)
    if not IS_WIN:
        candidates.extend(Path(p) for p in (
            '/opt/homebrew/bin/ffmpeg', '/usr/local/bin/ffmpeg',
            os.path.expanduser('~/bin/ffmpeg')))
    for candidate in candidates:
        if candidate.is_file():
            return str(candidate)
    return shutil.which(name) or name


def get_ffprobe_path():
    import shutil
    name = 'ffprobe.exe' if IS_WIN else 'ffprobe'
    sibling = Path(get_ffmpeg_path()).parent / name
    if sibling.is_file():
        return str(sibling)
    return shutil.which(name) or name


def _subprocess_kwargs(capture=True, text=True, timeout=None):
    """Never inherit absent console handles in a Windows --windowed executable."""
    kwargs = {'stdin': subprocess.DEVNULL}
    if capture:
        kwargs['capture_output'] = True
    if text:
        kwargs.update(text=True, encoding='utf-8', errors='replace')
    if timeout is not None:
        kwargs['timeout'] = timeout
    if IS_WIN:
        kwargs['creationflags'] = getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)
    return kwargs


# ============ 编码器配置（与翻译解耦）============
ENCODER_CONFIGS = {
    'cpu_h264': {
        'encoder': 'libx264', 'quality_param': '-crf',
        'quality_map': {'high': '18', 'balanced': '23', 'small': '30', 'extreme': '35'},
        'has_preset': True,
        'preset_map': {'fast': 'veryfast', 'balanced': 'medium', 'high_compress': 'slow'},
        'is_gpu': False, 'info_key': 'info_cpu',
    },
    'cpu_h265': {
        'encoder': 'libx265', 'quality_param': '-crf',
        'quality_map': {'high': '22', 'balanced': '28', 'small': '35', 'extreme': '40'},
        'has_preset': True,
        'preset_map': {'fast': 'veryfast', 'balanced': 'medium', 'high_compress': 'slow'},
        'is_gpu': False, 'info_key': 'info_h265',
    },
}
if IS_MAC:
    for key, encoder in [('apple_h264', 'h264_videotoolbox'), ('apple_h265', 'hevc_videotoolbox')]:
        ENCODER_CONFIGS[key] = {
            'encoder': encoder, 'quality_param': '-b:v', 'quality_map': 'dynamic',
            'has_preset': False, 'preset_map': {}, 'is_gpu': True, 'info_key': 'info_apple',
        }
if IS_WIN:
    ENCODER_CONFIGS.update({
        'nvidia': {
            'encoder': 'h264_nvenc', 'quality_param': '-cq',
            'quality_map': {'high': '19', 'balanced': '23', 'small': '28', 'extreme': '32'},
            'has_preset': True,
            'preset_map': {'fast': 'p2', 'balanced': 'p4', 'high_compress': 'p6'},
            'is_gpu': True, 'info_key': 'info_nvidia',
        },
        'amd': {
            'encoder': 'h264_amf', 'quality_param': '-qp_i',
            'quality_map': {'high': '18', 'balanced': '23', 'small': '28', 'extreme': '32'},
            'has_preset': False, 'preset_map': {}, 'is_gpu': True, 'info_key': 'info_amd',
        },
        'intel': {
            'encoder': 'h264_qsv', 'quality_param': '-global_quality',
            'quality_map': {'high': '20', 'balanced': '25', 'small': '30', 'extreme': '35'},
            'has_preset': True,
            'preset_map': {'fast': 'veryfast', 'balanced': 'medium', 'high_compress': 'slow'},
            'is_gpu': True, 'info_key': 'info_intel',
        },
    })

QUALITY_KEYS = ['high', 'balanced', 'small', 'extreme']
QUALITY_TR_KEYS = ['high_quality', 'balanced', 'small_size', 'extreme']
SPEED_KEYS = ['fast', 'balanced', 'high_compress']
SPEED_TR_KEYS = ['fast', 'balanced', 'high_compress']
ENCODER_PROBE_ERRORS = {}


def get_quality_internal_key(display_text):
    return next((key for key, label in zip(QUALITY_KEYS, QUALITY_TR_KEYS)
                 if display_text == tr(label)), 'balanced')


def get_speed_internal_key(display_text):
    return next((key for key, label in zip(SPEED_KEYS, SPEED_TR_KEYS)
                 if display_text == tr(label)), 'balanced')


def compute_dynamic_bitrate(quality_key, target_height, is_h265=False):
    bitrate_table = {
        2160: [20.0, 12.0, 6.0, 3.0], 1080: [8.0, 4.0, 2.0, 1.0],
        720: [5.0, 2.5, 1.2, 0.6], 480: [3.0, 1.5, 0.8, 0.4],
        360: [2.0, 1.0, 0.5, 0.25],
    }
    qi = QUALITY_KEYS.index(quality_key) if quality_key in QUALITY_KEYS else 1
    closest = min(bitrate_table, key=lambda h: abs(h - target_height))
    rate = bitrate_table[closest][qi] * (0.7 if is_h265 else 1)
    return f'{rate:g}M'


def _encoder_arguments(config, quality='balanced', speed='balanced', height=1080):
    encoder = config['encoder']
    args = ['-c:v', encoder]
    if config['quality_map'] == 'dynamic':
        args += ['-b:v', compute_dynamic_bitrate(quality, height, 'hevc' in encoder),
                 '-allow_sw', '0']
    else:
        value = config['quality_map'].get(quality, '23')
        args += [config['quality_param'], value]
        if encoder == 'h264_nvenc':
            args += ['-rc', 'vbr', '-b:v', '0']
        elif encoder == 'h264_amf':
            args += ['-rc', 'cqp', '-qp_p', value, '-qp_b', value]
    if config.get('has_preset'):
        args += ['-preset', config['preset_map'].get(speed, 'medium')]
    if encoder in ('libx265', 'hevc_videotoolbox'):
        args += ['-tag:v', 'hvc1']
    return args


def detect_available_encoders():
    """The codec list describes a build, not the user's GPU: verify a real encode."""
    available = []
    ENCODER_PROBE_ERRORS.clear()
    ffmpeg = get_ffmpeg_path()
    try:
        result = subprocess.run([ffmpeg, '-hide_banner', '-encoders'],
                                **_subprocess_kwargs(timeout=10))
        if result.returncode:
            raise RuntimeError((result.stderr or '').strip()[-1500:])
        built = set(re.findall(r'^\s*[A-Z.]{6}\s+(\S+)', result.stdout or '', re.MULTILINE))
        for key, config in ENCODER_CONFIGS.items():
            if config['encoder'] not in built:
                ENCODER_PROBE_ERRORS[key] = 'Encoder is not included in this FFmpeg build.'
                continue
            cmd = [ffmpeg, '-hide_banner', '-nostdin', '-loglevel', 'error',
                   '-f', 'lavfi', '-i', 'color=c=black:s=256x256:r=24:d=0.125',
                   '-frames:v', '3', '-an', '-pix_fmt', 'yuv420p']
            cmd += _encoder_arguments(config, speed='fast', height=360)
            cmd += ['-threads', '2', '-f', 'null', '-']
            try:
                probe = subprocess.run(cmd, **_subprocess_kwargs(timeout=15))
                if probe.returncode == 0:
                    available.append(key)
                else:
                    ENCODER_PROBE_ERRORS[key] = (probe.stderr or 'Encoder initialization failed.')[-1800:]
            except (OSError, subprocess.TimeoutExpired) as exc:
                ENCODER_PROBE_ERRORS[key] = str(exc)
    except (OSError, RuntimeError, subprocess.TimeoutExpired) as exc:
        ENCODER_PROBE_ERRORS['ffmpeg'] = str(exc)
        logger.error('FFmpeg detection failed: %s', exc)
    logger.info('Verified encoders: %s; unavailable: %s', available, ENCODER_PROBE_ERRORS)
    return available


def get_auto_encoder(available=None):
    if available is None:
        available = detect_available_encoders()
    for key in ('apple_h264', 'nvidia', 'intel', 'amd', 'cpu_h264', 'cpu_h265'):
        if key in available:
            return key
    return None


def _core_message(zh, en):
    return zh if get_lang() == 'zh' else en


def _probe_command(cmd, cancel_event=None, timeout=15):
    """Bound metadata work and make Stop interrupt a stuck FFprobe as well."""
    import time
    kwargs = _subprocess_kwargs(capture=False)
    with subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kwargs) as process:
        deadline = time.monotonic() + timeout
        try:
            while True:
                if cancel_event is not None and cancel_event.is_set():
                    raise InterruptedError('Cancelled')
                if time.monotonic() > deadline:
                    raise TimeoutError('FFprobe timed out')
                try:
                    stdout, stderr = process.communicate(timeout=0.2)
                    return process.returncode, stdout, stderr
                except subprocess.TimeoutExpired:
                    pass
        except BaseException:
            process.kill()
            process.communicate()
            raise


_VIDEO_INFO_CACHE = {}
_VIDEO_INFO_PENDING = {}
_VIDEO_INFO_LOCK = threading.Lock()
_VIDEO_INFO_CACHE_LIMIT = 1024


def _video_cache_key(filepath):
    """Do not reuse metadata after a source or the selected FFprobe has changed."""
    try:
        path = os.path.realpath(os.path.abspath(filepath))
        stat = os.stat(path)
        probe = get_ffprobe_path()
        probe_stat = os.stat(probe)
        return (path, stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns,
                probe, probe_stat.st_size, probe_stat.st_mtime_ns)
    except OSError:
        return None


def probe_video_info(filepath, cancel_event=None):
    """Share one metadata probe between the file list and compression workers."""
    key = _video_cache_key(filepath)
    if key is None:
        return _probe_video_info_uncached(filepath, cancel_event)
    while True:
        if cancel_event is not None and cancel_event.is_set():
            return {'valid': False, 'duration': 0, 'error': _core_message('已取消', 'Cancelled')}
        with _VIDEO_INFO_LOCK:
            cached = _VIDEO_INFO_CACHE.pop(key, None)
            if cached is not None:
                _VIDEO_INFO_CACHE[key] = cached
                return dict(cached)
            pending = _VIDEO_INFO_PENDING.get(key)
            if pending is None:
                pending = threading.Event()
                _VIDEO_INFO_PENDING[key] = pending
                break
        pending.wait(0.05)
        key = _video_cache_key(filepath)
        if key is None:
            return _probe_video_info_uncached(filepath, cancel_event)
    try:
        info = _probe_video_info_uncached(filepath, cancel_event)
        if info.get('valid'):
            if _video_cache_key(filepath) != key:
                info = dict(info, valid=False, duration=0, error=_core_message(
                    '读取期间文件或探测组件发生变化，请重试。',
                    'The file or metadata tool changed while being read. Please retry.'))
            else:
                with _VIDEO_INFO_LOCK:
                    _VIDEO_INFO_CACHE[key] = dict(info)
                    while len(_VIDEO_INFO_CACHE) > _VIDEO_INFO_CACHE_LIMIT:
                        _VIDEO_INFO_CACHE.pop(next(iter(_VIDEO_INFO_CACHE)))
        return info
    finally:
        with _VIDEO_INFO_LOCK:
            _VIDEO_INFO_PENDING.pop(key, None)
            pending.set()


def _probe_video_info_uncached(filepath, cancel_event=None):
    """Inspect streams once; retain actionable errors instead of pretending 1080p."""
    import math
    info = {'duration': 0.0, 'width': 0, 'height': 0, 'audio_codec': '',
            'audio_bitrate': 0, 'video_index': None, 'audio_index': None,
            'rotation': 0, 'sample_aspect_ratio': 1.0, 'color_transfer': '', 'pix_fmt': '',
            'valid': False, 'error': ''}
    try:
        command = [get_ffprobe_path(), '-v', 'error', '-show_streams', '-show_format',
                   '-of', 'json', os.path.abspath(filepath)]
        code, stdout, stderr = _probe_command(command, cancel_event)
        if code:
            raise ValueError(stderr.strip()[-1800:] or f'FFprobe exited with code {code}')
        data = json.loads(stdout)
        streams = data.get('streams', [])
        videos = [stream for stream in streams if stream.get('codec_type') == 'video'
                  and not stream.get('disposition', {}).get('attached_pic')]
        if not videos:
            raise ValueError(_core_message('未找到可压缩的视频流。', 'No video stream found.'))
        video = next((s for s in videos if s.get('disposition', {}).get('default')), videos[0])
        info['video_index'] = video['index']
        info['width'], info['height'] = int(video.get('width', 0)), int(video.get('height', 0))
        if info['width'] < 2 or info['height'] < 2:
            raise ValueError('Video dimensions are missing or invalid.')
        sar = video.get('sample_aspect_ratio', '1:1').split(':')
        if len(sar) == 2 and sar[0].isdigit() and sar[1].isdigit() and int(sar[1]):
            info['sample_aspect_ratio'] = int(sar[0]) / int(sar[1]) or 1.0
        rotation = video.get('tags', {}).get('rotate', 0)
        for side_data in video.get('side_data_list', []):
            if 'rotation' in side_data:
                rotation = side_data['rotation']
        info['rotation'] = int(float(rotation)) % 360
        try:
            numerator, denominator = str(video.get('avg_frame_rate') or video.get('r_frame_rate') or '0/1').split('/')
            info['frame_rate'] = float(numerator) / float(denominator)
        except (ValueError, ZeroDivisionError):
            info['frame_rate'] = 0.0
        try:
            info['video_duration'] = float(video.get('duration') or 0)
        except (TypeError, ValueError):
            info['video_duration'] = 0.0
        info['color_transfer'] = video.get('color_transfer', '')
        info['pix_fmt'] = video.get('pix_fmt', '')
        raw_duration = data.get('format', {}).get('duration') or video.get('duration') or 0
        try:
            duration = float(raw_duration)
        except (TypeError, ValueError):
            duration = 0.0
        info['duration'] = duration if math.isfinite(duration) and duration > 0 else 0.0
        audios = [s for s in streams if s.get('codec_type') == 'audio']
        if audios:
            audio = next((s for s in audios if s.get('disposition', {}).get('default')), audios[0])
            info['audio_index'] = audio['index']
            info['audio_codec'] = audio.get('codec_name', '')
            raw_bitrate = str(audio.get('bit_rate', '0'))
            info['audio_bitrate'] = int(raw_bitrate) if raw_bitrate.isdigit() else 0
        info['valid'] = True
    except InterruptedError:
        info['error'] = _core_message('已取消', 'Cancelled')
    except (OSError, ValueError, KeyError, TypeError, TimeoutError) as exc:
        info['error'] = str(exc)
        logger.warning('Failed to probe %s: %s', filepath, exc)
    return info


def build_scale_filter(resolution=None):
    """Keep display aspect, portrait orientation, even dimensions, and never upscale."""
    factor = '1'
    if isinstance(resolution, int) and resolution > 0:
        short_edge = resolution
        long_edge = int(round(resolution * 16 / 9))
        factor = f'min(1,min({short_edge}/min(iw*sar,ih),{long_edge}/max(iw*sar,ih)))'
    width = f'max(2,trunc(iw*sar*{factor}/2)*2)'
    height = f'max(2,trunc(ih*{factor}/2)*2)'
    return f"scale=w='{width}':h='{height}':flags=lanczos,setsar=1,format=yuv420p"


def needs_scale_filter(info, resolution=None):
    """Leave normal, already-small square-pixel video out of the scaler entirely."""
    width, height = info.get('width', 0), info.get('height', 0)
    if not width or not height or width % 2 or height % 2:
        return True
    if abs(info.get('sample_aspect_ratio', 1.0) - 1.0) > 0.000001:
        return True
    # Other source formats can require chroma resampling or bit-depth reduction.
    # Preserve their existing Lanczos conversion rather than changing its quality.
    if info.get('pix_fmt') not in ('yuv420p', 'nv12'):
        return True
    if isinstance(resolution, int) and resolution > 0:
        return min(width, height) > resolution or max(width, height) > round(resolution * 16 / 9)
    return False


# ============ 格式化工具 ============
def fmt_size(size):
    """格式化文件大小"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size < 1024:
            return f"{size:.1f} {unit}"
        size /= 1024
    return f"{size:.1f} PB"


def fmt_duration(seconds):
    """格式化时长"""
    if seconds <= 0:
        return "-"
    s = int(seconds)
    m, s = divmod(s, 60)
    h, m = divmod(m, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


# ============ 结果弹窗 ============
class ResultDialog(QDialog):
    def __init__(self, parent, completed, failed, total, input_size, output_size, was_stopped=False, kept=0):
        super().__init__(parent)
        title_key = 'compress_stopped' if was_stopped else 'compress_done'
        self.setWindowTitle(tr(title_key))
        self.setMinimumSize(380, 280)
        self.setStyleSheet("QDialog { background: #f6f7f9; }")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(10)

        title = QLabel(tr(title_key))
        title.setStyleSheet("font-size: 18px; font-weight: 600; color: #1e293b;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        info_data = [
            (tr('files_processed'), f"{max(0, completed - kept)}/{total}", "#252b36"),
        ]
        if kept:
            info_data.append((tr('files_kept'), str(kept), "#687386"))
        if failed > 0:
            info_data.append((tr('files_failed'), str(failed), "#bd2525"))

        if input_size > 0 and completed > 0:
            info_data.append((tr('original_size'), fmt_size(input_size), "#252b36"))
            info_data.append((tr('compressed_size'), fmt_size(output_size), "#252b36"))
            saved = input_size - output_size
            ratio = abs(saved) / input_size * 100
            if saved > 0:
                info_data.append((tr('space_saved'), f"-{fmt_size(saved)} ({ratio:.0f}%)", "#157246"))
            elif saved < 0:
                info_data.append((tr('size_increased'), f"+{fmt_size(abs(saved))} ({ratio:.0f}%)", "#956216"))

        for label, value, color in info_data:
            row = QHBoxLayout()
            l = QLabel(label)
            l.setStyleSheet("font-size: 13px; color: #687386;")
            v = QLabel(value)
            v.setStyleSheet(f"font-size: 13px; font-weight: 500; color: {color};")
            row.addWidget(l)
            row.addStretch()
            row.addWidget(v)
            layout.addLayout(row)

        layout.addStretch()

        ok_btn = QPushButton(tr('ok'))
        ok_btn.setObjectName('primary')
        ok_btn.setMinimumHeight(36)
        ok_btn.clicked.connect(self.accept)
        layout.addWidget(ok_btn)


# ============ 视频信息工作线程（线程池化）============
class VideoInfoPool:
    """使用线程池获取视频信息，避免无限创建 QThread"""

    def __init__(self, callback, max_workers=4):
        self.callback = callback
        self.pool = ThreadPoolExecutor(max_workers=max_workers)
        self._futures = set()
        self._lock = threading.Lock()
        self._cancel_event = threading.Event()
        self._closed = False

    def submit(self, row, filepath):
        with self._lock:
            if self._closed:
                return
            future = self.pool.submit(self._get_info, row, filepath, self._cancel_event)
            self._futures.add(future)
        future.add_done_callback(self._forget_future)

    def _forget_future(self, future):
        with self._lock:
            self._futures.discard(future)

    def _get_info(self, row, filepath, cancel_event):
        try:
            info = probe_video_info(filepath, cancel_event)
            if not cancel_event.is_set():
                self.callback(row, fmt_duration(info.get('duration', 0)))
        except Exception as e:
            logger.warning(f"Failed to get duration for row {row}: {e}")
            if not cancel_event.is_set():
                self.callback(row, "-")

    def cancel_pending(self):
        """Clear the old generation, including probes already waiting on FFprobe."""
        with self._lock:
            self._cancel_event.set()
            self._cancel_event = threading.Event()
            futures = list(self._futures)
        for future in futures:
            future.cancel()

    def shutdown(self):
        with self._lock:
            self._closed = True
        self.cancel_pending()
        self.pool.shutdown(wait=False, cancel_futures=True)


# ============ 并行压缩工作线程 ============
class CompressionWorker(QThread):
    """A live queue which owns every temporary output and child process."""
    progress = pyqtSignal(int, int, str)
    file_done = pyqtSignal(int, bool, object)
    all_done = pyqtSignal(int, int, int, object, object, bool)
    result_detail = pyqtSignal(int, object)
    task_state = pyqtSignal(int, str)
    persistence_error = pyqtSignal(str)

    class TaskFailure(RuntimeError):
        def __init__(self, kind, detail):
            super().__init__(detail)
            self.kind = kind

    def __init__(self, files, settings):
        super().__init__()
        from collections import deque
        from copy import deepcopy
        self.files = []
        self.settings = deepcopy(settings)
        self._lock = threading.RLock()
        self._condition = threading.Condition(self._lock)
        self._pending = deque()
        self._active = set()
        self._committed = set()
        self._cancel_events = {}
        self._paused = False
        self._accepting = True
        self._stop_event = threading.Event()
        self._should_stop = False
        self._processes = {}
        self.effective_parallel = 0
        self.peak_parallel_processes = 0
        self.thread_budget = {}
        self._disabled_encoders = {}
        self._completed = self._failed = self._total_in = self._total_out = 0
        self.results = {}
        self._source_paths = set()
        # Fallbacks can otherwise turn eight GPU jobs into eight CPU-heavy retries.
        # Explicit CPU jobs still use the full user-selected concurrency.
        self._fallback_slots = threading.BoundedSemaphore(2)
        self.checkpoint_callback = None
        self.result_callback = None
        self.enqueue(files)

    def enqueue(self, files):
        """Append independent settings snapshots; [] means this queue has closed."""
        from copy import deepcopy
        added = []
        with self._condition:
            if not self._accepting or self._stop_event.is_set():
                return added
            for item in files:
                file_info = deepcopy(item)
                snapshot = deepcopy(self.settings)
                snapshot.update(deepcopy(file_info.get('settings') or {}))
                if snapshot.get('encoder_key', 'auto') == 'auto':
                    snapshot['encoder_key'] = get_auto_encoder(snapshot.get('available_encoders'))
                file_info['settings'] = snapshot
                index = len(self.files)
                self.files.append(file_info)
                self._source_paths.add(os.path.normcase(os.path.realpath(file_info['path'])))
                self._cancel_events[index] = threading.Event()
                self._pending.append(index)
                added.append(index)
            self._condition.notify_all()
        for index in added:
            self.task_state.emit(index, 'waiting')
        return added

    def pending_indices(self):
        with self._lock:
            return list(self._pending)

    def active_indices(self):
        with self._lock:
            return sorted(self._active)

    def set_paused(self, paused):
        """Let active jobs finish, but do not start another while paused."""
        with self._condition:
            self._paused = bool(paused)
            self._condition.notify_all()

    def prioritize(self, indices):
        from collections import deque
        with self._condition:
            requested = list(dict.fromkeys(indices))
            first = [index for index in requested if index in self._pending]
            if not first:
                return False
            selected = set(first)
            self._pending = deque(first + [i for i in self._pending if i not in selected])
            self._condition.notify_all()
            return True

    def cancel_task(self, index):
        with self._condition:
            if index not in self._cancel_events or index in self.results or index in self._committed:
                return False
            self._cancel_events[index].set()
            pending = index in self._pending
            if pending:
                self._pending.remove(index)
                self._record_result(index, {'status': 'cancelled', 'error_kind': 'cancelled'})
            process = self._processes.get(index)
            self._condition.notify_all()
        if process is not None:
            threading.Thread(target=self._terminate_process, args=(process,), daemon=True).start()
        return True

    def _is_cancelled(self, index):
        return self._stop_event.is_set() or self._cancel_events[index].is_set()

    def run(self):
        parallel = max(1, min(int(self.settings.get('parallel', 2)), 8))
        self.effective_parallel = parallel
        threads = max(1, min(16, CPU_COUNT // parallel))
        self.thread_budget = {'decode': min(2, threads), 'encode': threads,
                              'filter': min(4, threads)}
        logger.info('Queue: %s concurrent jobs, per-job thread budget %s', parallel, self.thread_budget)
        with ThreadPoolExecutor(max_workers=parallel) as pool:
            while True:
                with self._condition:
                    if not self._pending and not self._active:
                        # Enqueue and exhaustion share this lock, so a late arrival
                        # either joins this worker or is explicitly rejected.
                        self._accepting = False
                        break
                    if self._paused or not self._pending or len(self._active) >= parallel:
                        self._condition.wait()
                        continue
                    index = self._pending.popleft()
                    self._active.add(index)
                    self.task_state.emit(index, 'running')
                    pool.submit(self._execute_task, index, threads)
        self.all_done.emit(self._completed, self._failed, len(self.files),
                           self._total_in, self._total_out, self._stop_event.is_set())

    def _execute_task(self, index, threads):
        try:
            file_info = self.files[index]
            encoder_key = file_info['settings'].get('encoder_key')
            self._compress_one(index, file_info, encoder_key, threads)
        except Exception as exc:
            logger.exception('Unexpected compression task failure')
            self._record_result(index, {'status': 'failed', 'error_kind': 'internal_error', 'error': str(exc)})
        finally:
            with self._condition:
                self._active.discard(index)
                self._condition.notify_all()

    def _persist(self, callback, *args):
        if callback is None:
            return
        try:
            callback(*args)
        except Exception as exc:
            logger.exception('Could not save queue recovery state')
            self.persistence_error.emit(_core_message('任务恢复记录保存失败：', 'Could not save queue recovery state: ') + str(exc))

    def _record_result(self, index, result):
        from copy import deepcopy
        result.setdefault('output_path', '')
        result.setdefault('input_size', 0)
        result.setdefault('output_size', 0)
        result.setdefault('encoder_key', '')
        result.setdefault('fallback_used', False)
        result.setdefault('error', '')
        result.setdefault('error_kind', '')
        result.setdefault('settings', deepcopy(self.files[index]['settings']))
        success = result['status'] in ('success', 'kept_original')
        with self._lock:
            if index in self.results:
                return
            self.results[index] = result
            if success:
                self._completed += 1
                self._total_in += result['input_size']
                self._total_out += result['output_size']
            elif result['status'] == 'failed':
                self._failed += 1
        self._persist(self.result_callback, self.files[index].get('id'), deepcopy(result))
        self.result_detail.emit(index, result)
        if result['status'] == 'cancelled':
            self.progress.emit(index, 0, tr('cancelled'))
        else:
            self.file_done.emit(index, success, result['output_size'])

    def _reserve_output(self, in_path, settings=None):
        """An exclusive placeholder reserves the name across workers and app instances."""
        settings = self.settings if settings is None else settings
        out_dir = os.path.abspath(settings.get('output_dir') or os.path.dirname(in_path))
        os.makedirs(out_dir, exist_ok=True)
        stem = Path(in_path).stem
        stem = stem if stem.endswith('_compressed') else stem + '_compressed'
        for suffix in range(1, 100000):
            name = f'{stem}{"" if suffix == 1 else "_" + str(suffix)}.mp4'
            candidate = os.path.join(out_dir, name)
            with self._lock:
                if os.path.normcase(os.path.realpath(candidate)) in self._source_paths:
                    continue
            try:
                fd = os.open(candidate, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            except FileExistsError:
                continue
            try:
                identity = os.fstat(fd)
            finally:
                os.close(fd)
            return candidate, (identity.st_dev, identity.st_ino)
        raise OSError('Could not reserve an unused output filename.')

    @staticmethod
    def _owns_reservation(path, identity):
        try:
            stat = os.stat(path, follow_symlinks=False)
            return (stat.st_dev, stat.st_ino) == identity and stat.st_size == 0
        except OSError:
            return False

    def _build_command(self, in_path, temp_path, config, info, threads, settings=None):
        settings = self.settings if settings is None else settings
        quality = settings.get('quality_key', 'balanced')
        speed = settings.get('speed_key', 'balanced')
        resolution = settings.get('resolution')
        display_width = info['width'] * info.get('sample_aspect_ratio', 1)
        short_edge = min(display_width, info['height'])
        if isinstance(resolution, int) and resolution > 0:
            short_edge = min(short_edge, resolution)
        cmd = [get_ffmpeg_path(), '-hide_banner', '-nostdin', '-loglevel', 'warning',
               '-nostats', '-progress', 'pipe:2', '-filter_threads', str(min(4, threads)),
               '-threads', str(min(2, threads)),
               '-i', in_path, '-map', f"0:{info['video_index']}"]
        if info['audio_index'] is not None:
            cmd += ['-map', f"0:{info['audio_index']}"]
        cmd += ['-sn', '-dn']
        cmd += _encoder_arguments(config, quality, speed, short_edge)
        if needs_scale_filter(info, resolution):
            cmd += ['-vf', build_scale_filter(resolution)]
        else:
            cmd += ['-pix_fmt', 'yuv420p']
        if config['encoder'] == 'libx265':
            pools = str(threads) if threads > 1 else 'none'
            cmd += ['-x265-params', f'pools={pools}:frame-threads={min(2, threads)}:log-level=error']
        if info['audio_index'] is not None:
            audio_bitrate = 48000 if quality == 'extreme' else 128000
            if info['audio_codec'] == 'aac' and 0 < info['audio_bitrate'] <= audio_bitrate:
                cmd += ['-c:a', 'copy']
            else:
                cmd += ['-c:a', 'aac', '-b:a', str(audio_bitrate)]
        cmd += ['-threads', str(threads), '-movflags', '+faststart', '-y', temp_path]
        return cmd

    @staticmethod
    def _terminate_process(process):
        """Escalate cancellation: a child ignoring terminate must not hold QThread open."""
        if process.poll() is not None:
            return
        try:
            process.terminate()
            process.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try:
                process.kill()
                process.wait(timeout=2)
            except (OSError, subprocess.TimeoutExpired):
                logger.warning('Could not reap FFmpeg process %s', process.pid)
        except OSError:
            pass

    def _encode(self, index, command, duration):
        from collections import deque
        errors = deque(maxlen=30)
        kwargs = _subprocess_kwargs(capture=False)
        process = subprocess.Popen(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, **kwargs)
        with self._lock:
            self._processes[index] = process
            self.peak_parallel_processes = max(self.peak_parallel_processes, len(self._processes))
        try:
            if self._is_cancelled(index):
                self._terminate_process(process)
            for line in process.stderr:
                line = line.strip()
                if line.startswith('out_time_us=') and duration > 0:
                    try:
                        current = int(line.split('=', 1)[1]) / 1_000_000
                        percent = min(99, max(0, int(current / duration * 100)))
                        self.progress.emit(index, percent, tr('compressing'))
                    except ValueError:
                        pass
                elif line and not re.match(r'^(frame|fps|stream_\d+_\d+_q|bitrate|total_size|out_time|dup_frames|drop_frames|speed|progress)=', line):
                    errors.append(line)
                if self._is_cancelled(index):
                    self._terminate_process(process)
                    break
            process.wait()
            return process.returncode, '\n'.join(errors)[-4000:]
        finally:
            if process.poll() is None:
                self._terminate_process(process)
            if process.stderr:
                process.stderr.close()
            with self._lock:
                self._processes.pop(index, None)

    def _cpu_fallback_encoder(self, config, settings=None):
        key = 'cpu_h265' if 'hevc' in config['encoder'] else 'cpu_h264'
        settings = self.settings if settings is None else settings
        available = settings.get('available_encoders')
        if available is not None and key not in available:
            raise RuntimeError(_core_message(
                '硬件编码失败，当前 FFmpeg 没有通过测试的同格式 CPU 编码器。',
                'Hardware encoding failed and no tested CPU encoder for this format is available.'))
        return key

    @staticmethod
    def _error_kind(error):
        """Only positively identified device/backend failures may retry on CPU."""
        import errno
        detail = str(error).lower()
        number = getattr(error, 'errno', None)
        if number == errno.ENOSPC or any(s in detail for s in ('no space left', 'disk full', 'not enough space on the disk')):
            return 'disk_full'
        if number in (errno.EACCES, errno.EPERM) or any(s in detail for s in ('permission denied', 'access is denied', 'read-only file system')):
            return 'permission_denied'
        if number == errno.ENOENT or 'no such file or directory' in detail:
            return 'missing_file'
        if any(s in detail for s in ('invalid data found', 'moov atom not found', 'corrupt', 'error while decoding', 'invalid nal unit', 'no video stream')):
            return 'invalid_input'
        if any(s in detail for s in ('too many concurrent sessions', 'all nvenc capable devices are busy', 'encoder busy', 'mfx_err_device_busy')):
            return 'hardware_busy'
        if any(s in detail for s in (
                'unknown encoder', 'cannot load nvcuda', 'cannot load nvencodeapi',
                'cannot load amfrt', 'driver does not support', 'minimum required nvidia driver',
                'no cuda-capable device', 'no capable devices found', 'cannot init cuda',
                'openencodesessionex failed', 'error creating a mfx session',
                'failed to create a mfx session', 'mfx_err_unsupported', 'mfx_err_device_failed',
                'failed to initialise vaapi connection', 'no device available for encoder',
                'cannot load libcuda', 'failed to initialise videotoolbox',
                'cannot create compression session', 'error: cannot create compression session',
                'amf failed to initialise', 'amf failed to initialize', 'initializeencoder failed')):
            return 'hardware_unavailable'
        return 'encoding_failed'

    @staticmethod
    def _error_message(kind, detail):
        messages = {
            'disk_full': ('输出磁盘空间不足，请释放空间后重试。', 'The output disk is full. Free space and retry.'),
            'permission_denied': ('无法读写文件，请检查文件权限或更换输出目录。', 'Cannot read or write the file. Check permissions or choose another output folder.'),
            'missing_file': ('源文件或所需程序不存在，请检查路径后重试。', 'The source file or a required program is missing. Check its path and retry.'),
            'invalid_input': ('无法完整读取视频，文件可能损坏或格式不受支持。', 'The video could not be read completely. It may be damaged or unsupported.'),
            'hardware_busy': ('硬件编码器正忙，请稍后重试或降低并行数。', 'The hardware encoder is busy. Retry later or reduce concurrency.'),
            'hardware_unavailable': ('硬件编码器不可用，请检查显卡驱动。', 'The hardware encoder is unavailable. Check the graphics driver.'),
            'output_invalid': ('输出验证失败，未交付不完整文件；原视频已保留。', 'Output validation failed. No incomplete result was delivered; the original is unchanged.'),
            'no_encoder': ('未检测到可用编码器，请检查 FFmpeg 或显卡驱动。', 'No working encoder found. Check FFmpeg or the graphics driver.'),
            'source_changed': ('原视频在排队或处理期间发生变化，请检查文件后重新处理。', 'The source video changed while queued or processing. Review the file and process it again.'),
        }
        if kind not in messages:
            return str(detail)
        summary = _core_message(*messages[kind])
        return summary + ('\n' + str(detail)[-1800:] if detail else '')

    def _acquire_fallback_slot(self, index):
        while not self._is_cancelled(index):
            if self._fallback_slots.acquire(timeout=0.1):
                if self._is_cancelled(index):
                    self._fallback_slots.release()
                    break
                return
        raise InterruptedError()

    def _remember_hardware_failure(self, encoder_key, error):
        # Busy sessions / unsupported dimensions can affect one file only. Do not
        # disable healthy hardware for the rest of a batch because of those errors.
        permanent = ('unknown encoder', 'cannot load nvcuda', 'cannot load nvencodeapi',
                     'cannot load amfrt', 'driver does not support',
                     'minimum required nvidia driver', 'no cuda-capable device')
        if any(reason in error.lower() for reason in permanent):
            with self._lock:
                self._disabled_encoders.setdefault(encoder_key, error)

    def _compress_one(self, index, file_info, encoder_key, threads):
        import tempfile
        from copy import deepcopy
        in_path = os.path.abspath(file_info['path'])
        settings = file_info['settings']
        cancel_event = self._cancel_events[index]
        temp_path = out_path = None
        reservation = None
        fallback_slot = False
        result = {'status': 'failed', 'input_size': 0, 'output_size': 0,
                  'encoder_key': encoder_key, 'fallback_used': False, 'error': '',
                  'settings': deepcopy(settings), 'error_kind': ''}
        try:
            if self._is_cancelled(index):
                raise InterruptedError()
            if encoder_key not in ENCODER_CONFIGS:
                raise self.TaskFailure('no_encoder', '')
            result['input_size'] = os.path.getsize(in_path)
            source_identity = capture_identity(in_path)
            expected_identity = file_info.get('source_identity')
            if expected_identity is not None and source_identity != expected_identity:
                raise self.TaskFailure('source_changed', '')
            result['source_identity'] = source_identity
            self.progress.emit(index, 0, tr('preparing'))
            info = probe_video_info(in_path, cancel_event)
            if self._is_cancelled(index):
                raise InterruptedError()
            if not info['valid']:
                kind = self._error_kind(info['error'])
                raise self.TaskFailure('invalid_input' if kind == 'encoding_failed' else kind, info['error'])
            if info['color_transfer'] in ('smpte2084', 'arib-std-b67'):
                raise self.TaskFailure('unsupported_hdr', _core_message(
                    '此文件是 HDR 视频。为避免颜色失真，本版本暂不转换 HDR；请先转换为 SDR 后重试。',
                    'This is HDR video. HDR conversion is not yet supported; convert to SDR first to avoid incorrect colors.'))
            out_path, reservation = self._reserve_output(in_path, settings)
            temp_fd, temp_path = tempfile.mkstemp(prefix='.ellapuede-', suffix='.mp4', dir=os.path.dirname(out_path))
            os.close(temp_fd)
            self._persist(self.checkpoint_callback, file_info.get('id'), temp_path, out_path, reservation)
            config = ENCODER_CONFIGS[encoder_key]
            with self._lock:
                disabled_reason = self._disabled_encoders.get(encoder_key)
            if config.get('is_gpu') and disabled_reason:
                result.update(fallback_used=True, fallback_reason=disabled_reason)
                self._acquire_fallback_slot(index)
                fallback_slot = True
                encoder_key = self._cpu_fallback_encoder(config, settings)
                config = ENCODER_CONFIGS[encoder_key]
                result['encoder_key'] = encoder_key
            command = self._build_command(in_path, temp_path, config, info, threads, settings)
            logger.info('Compressing [%s] using %s: %s', index, encoder_key, in_path)
            code, error = self._encode(index, command, info['duration'])
            if self._is_cancelled(index):
                raise InterruptedError()
            if code and config.get('is_gpu') and self._error_kind(error) == 'hardware_busy':
                self.progress.emit(index, 0, _core_message('硬件正忙，正在等待重试', 'Hardware is busy; waiting to retry'))
                if cancel_event.wait(0.5) or self._is_cancelled(index):
                    raise InterruptedError()
                code, error = self._encode(index, command, info['duration'])
            if code and config.get('is_gpu') and self._error_kind(error) in ('hardware_unavailable', 'hardware_busy'):
                result['fallback_used'] = True
                result['fallback_reason'] = error or f'FFmpeg exited with code {code}'
                result['fallback_error_kind'] = self._error_kind(error)
                self._remember_hardware_failure(encoder_key, error)
                self.progress.emit(index, 0, _core_message('正在等待 CPU 重试名额', 'Waiting for a CPU retry slot'))
                self._acquire_fallback_slot(index)
                fallback_slot = True
                encoder_key = self._cpu_fallback_encoder(config, settings)
                result['encoder_key'] = encoder_key
                logger.warning('Hardware failed for [%s], retrying %s: %s', index, encoder_key, error)
                self.progress.emit(index, 0, _core_message('硬件编码失败，正在使用 CPU 重试', 'Hardware encoding failed; retrying with CPU'))
                command = self._build_command(in_path, temp_path, ENCODER_CONFIGS[encoder_key], info, threads, settings)
                code, error = self._encode(index, command, info['duration'])
            if self._is_cancelled(index):
                raise InterruptedError()
            if code:
                raise RuntimeError(error or f'FFmpeg exited with code {code}')
            output_size = os.path.getsize(temp_path)
            if output_size <= 0:
                raise self.TaskFailure('output_invalid', _core_message('FFmpeg 生成了空文件。', 'FFmpeg produced an empty file.'))
            output_info = probe_video_info(temp_path, cancel_event)
            if self._is_cancelled(index):
                raise InterruptedError()
            if not output_info['valid']:
                raise self.TaskFailure('output_invalid', output_info['error'])
            if info['audio_index'] is not None and output_info['audio_index'] is None:
                raise self.TaskFailure('output_invalid', _core_message('输出视频缺少音轨。', 'The output is missing its audio track.'))
            # Allow a few frames of timestamp/container rounding, never a fixed
            # percentage which silently permits minutes missing from long videos.
            frame_rate = info.get('frame_rate') or 0
            tolerance = max(0.25, min(1.0, 3 / frame_rate)) if frame_rate > 0 else 0.5
            source_duration = info.get('video_duration') or info['duration']
            output_duration = output_info.get('video_duration') or output_info['duration']
            if source_duration > 0 and output_duration < source_duration - tolerance:
                raise self.TaskFailure('output_invalid', _core_message('输出视频时长不完整。', 'The output video duration is incomplete.'))
            if capture_identity(in_path) != source_identity:
                raise self.TaskFailure('source_changed', '')
            if output_size >= result['input_size'] and not settings.get('keep_larger', False):
                with self._lock:
                    if self._is_cancelled(index):
                        raise InterruptedError()
                    result.update(status='kept_original', output_path=in_path, output_size=result['input_size'])
                    self._committed.add(index)
            else:
                with self._lock:
                    if self._is_cancelled(index):
                        raise InterruptedError()
                    if not self._owns_reservation(out_path, reservation):
                        raise OSError('Output reservation changed; refusing to overwrite this file.')
                    os.replace(temp_path, out_path)
                    temp_path = None
                    reservation = None
                    result.update(status='success', output_path=out_path, output_size=output_size)
                    self._committed.add(index)
        except InterruptedError:
            result.update(status='cancelled', error_kind='cancelled')
        except Exception as exc:
            kind = exc.kind if isinstance(exc, self.TaskFailure) else self._error_kind(exc)
            result.update(error_kind=kind, error=self._error_message(kind, exc), error_details=str(exc))
            logger.error('Compression failed [%s]: %s', index, exc)
        finally:
            if fallback_slot:
                self._fallback_slots.release()
            if temp_path:
                self._cleanup_file(temp_path)
            if out_path and reservation and self._owns_reservation(out_path, reservation):
                self._cleanup_file(out_path)
            self._record_result(index, result)

    @staticmethod
    def _cleanup_file(path):
        try:
            os.remove(path)
        except FileNotFoundError:
            pass
        except OSError as exc:
            logger.warning('Failed to clean up %s: %s', path, exc)

    def stop(self):
        self._stop_event.set()
        with self._condition:
            self._should_stop = True
            self._accepting = False
            for event in self._cancel_events.values():
                event.set()
            pending = list(self._pending)
            self._pending.clear()
            for index in pending:
                self._record_result(index, {'status': 'cancelled', 'error_kind': 'cancelled'})
            processes = list(self._processes.values())
            self._condition.notify_all()
        for process in processes:
            threading.Thread(target=self._terminate_process, args=(process,), daemon=True).start()


# ============ 拖放区域 ============
class DropArea(QFrame):
    files_dropped = pyqtSignal(list)
    clicked = pyqtSignal()

    def __init__(self):
        super().__init__()
        self.setAcceptDrops(True)
        self.setMinimumHeight(80)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self._update_style(False)

        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.setSpacing(4)

        label = QLabel(tr('drop_hint'))
        label.setStyleSheet("color: #52667f; font-size: 13px; border: none; background: transparent;")
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(label)

        hint = QLabel(tr('format_hint'))
        hint.setStyleSheet("color: #7a8493; font-size: 12px; border: none; background: transparent;")
        hint.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(hint)

    def _update_style(self, hover):
        color = "#2463c4" if hover else "#c2ccda"
        bg = "#eaf0f7" if hover else "#f9fafc"
        self.setStyleSheet(f"QFrame {{ border: 1px dashed {color}; border-radius: 10px; background: {bg}; }}")

    def setEnabled(self, enabled):
        super().setEnabled(enabled)
        self.setAcceptDrops(enabled)
        if not enabled:
            self.setCursor(Qt.CursorShape.ForbiddenCursor)
        else:
            self.setCursor(Qt.CursorShape.PointingHandCursor)

    def mousePressEvent(self, e):
        if self.isEnabled():
            self.clicked.emit()

    def enterEvent(self, e):
        if self.isEnabled():
            self._update_style(True)

    def leaveEvent(self, e):
        self._update_style(False)

    def dragEnterEvent(self, e):
        if self.isEnabled() and e.mimeData().hasUrls():
            e.acceptProposedAction()
            self._update_style(True)

    def dragLeaveEvent(self, e):
        self._update_style(False)

    def dropEvent(self, e):
        self._update_style(False)
        if not self.isEnabled():
            return
        files = [url.toLocalFile() for url in e.mimeData().urls() if url.isLocalFile()]
        if files:
            self.files_dropped.emit(files)


class FileImportWorker(QThread):
    """Scan/stat away from the GUI; bound queued batches so large folders stay usable."""
    batch_ready = pyqtSignal(list)

    def __init__(self, paths, existing_paths=(), parent=None):
        super().__init__(parent)
        self.paths = list(paths)
        self._seen = {os.path.normcase(os.path.realpath(path)) for path in existing_paths}
        self._cancel = threading.Event()
        self._slots = threading.Semaphore(2)
        self.stats = {'duplicate': 0, 'unsupported': 0, 'unreadable': 0}

    def stop(self):
        self._cancel.set()

    def release_batch(self):
        self._slots.release()

    def _candidates(self):
        def scan_error(error):
            self.stats['unreadable'] += 1
            logger.warning('Import: %s', error)
        for path in self.paths:
            if self._cancel.is_set():
                return
            if os.path.isdir(path):
                for root, dirs, names in os.walk(path, followlinks=False, onerror=scan_error):
                    if self._cancel.is_set():
                        return
                    dirs.sort()
                    for name in sorted(names):
                        yield os.path.join(root, name)
            else:
                yield path

    def _send(self, batch):
        while not self._cancel.is_set():
            if self._slots.acquire(timeout=0.1):
                if self._cancel.is_set():
                    self._slots.release()
                    return False
                self.batch_ready.emit(batch)
                return True
        return False

    def run(self):
        batch = []
        try:
            for path in self._candidates():
                if self._cancel.is_set():
                    break
                if Path(path).suffix.lower() not in VIDEO_EXTENSIONS:
                    self.stats['unsupported'] += 1
                    continue
                canonical = os.path.realpath(os.path.abspath(path))
                identity = os.path.normcase(canonical)
                if identity in self._seen:
                    self.stats['duplicate'] += 1
                    continue
                try:
                    if not os.path.isfile(canonical):
                        self.stats['unreadable'] += 1
                        continue
                    size = os.path.getsize(canonical)
                except OSError as exc:
                    self.stats['unreadable'] += 1
                    logger.warning('Cannot import %s: %s', path, exc)
                    continue
                self._seen.add(identity)
                batch.append({'id': uuid.uuid4().hex, 'path': canonical,
                              'name': os.path.basename(canonical), 'size': size})
                if len(batch) >= 64:
                    if not self._send(batch):
                        return
                    batch = []
            if batch and not self._cancel.is_set():
                self._send(batch)
        except Exception:
            logger.exception('Folder import failed')


class EnvironmentWorker(QThread):
    ready = pyqtSignal(list, str)

    def run(self):
        try:
            for tool in (get_ffmpeg_path(), get_ffprobe_path()):
                result = subprocess.run([tool, '-version'], **_subprocess_kwargs(timeout=8))
                if result.returncode != 0:
                    raise RuntimeError((result.stderr or tool)[-500:])
            available = detect_available_encoders()
            self.ready.emit(available, '' if available else tr('no_hardware'))
        except Exception as exc:
            logger.exception('Environment check failed')
            self.ready.emit([], str(exc))


# ============ 主窗口 ============
class MainWindow(QMainWindow):
    # 线程安全的信号，用于从线程池回调更新 UI
    _video_info_signal = pyqtSignal(str, str)

    def __init__(self, auto_check=True, queue_path=None):
        super().__init__()
        self.files = []
        self._file_rows = {}
        self.worker = None
        self.available_encoder_keys = []
        self.detected_encoder_keys = []
        self._environment_ready = False
        self.environment_worker = None
        self._close_pending = False
        self._finished_indices = set()
        self._row_progress = {}
        self._run_rows = []
        self.results = {}
        self._pending_summary = None
        self._is_compressing = False
        self._is_importing = False
        self.import_worker = None
        self._import_start_count = 0
        self._run_started_at = 0.0
        self._progress_weights = []
        self._stopping = False
        self._worker_file_count = 0  # worker 启动时的文件数，用于进度计算
        self._queue_paused = False
        self._late_rows = []
        self._task_store = None
        self._queue_lock = None
        self._store_error = ''
        self._queue_blocked = False
        self._queue_path = queue_path
        self._import_settings = None

        self._video_info_signal.connect(self._on_video_info_from_pool)
        self.info_pool = VideoInfoPool(callback=self._emit_video_info, max_workers=4)

        self.init_ui()
        self._load_preferences()
        if queue_path is not None or auto_check:
            self._open_task_store(queue_path or str(Path(LM._get_config_path()).with_name('tasks.sqlite3')))
        if auto_check:
            QTimer.singleShot(0, self.check_environment)

    def _open_task_store(self, path):
        try:
            path = Path(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            self._queue_lock = QLockFile(str(path) + '.lock')
            self._queue_lock.setStaleLockTime(0)
            if not self._queue_lock.tryLock(0):
                raise RuntimeError(tr('store_locked'))
            self._task_store = TaskStore(path)
            cleanup = self._task_store.recovery_cleanup()
            if cleanup.get('errors'):
                logger.warning('Recovery cleanup: %s', cleanup['errors'])
            entries, results = self._task_store.load()
            self.files = entries
            self.results = results
            self.table.setUpdatesEnabled(False)
            for row, entry in enumerate(entries):
                self._append_file_row(entry)
                self.table.item(row, 1).setText(entry.get('duration_text', '…'))
                if row in results:
                    self._display_result(row, results[row])
            self.table.setUpdatesEnabled(True)
            if entries:
                self.queue_notice.setText(tr('restored').format(count=len(entries)))
                self.queue_notice.show()
            self.update_count()
        except Exception as exc:
            self._queue_blocked = True
            self._store_error = str(exc)
            self.queue_notice.setText(tr('store_unavailable').format(error=exc))
            self.queue_notice.show()
            self.table.setUpdatesEnabled(True)
        self._set_compressing(False)

    def _persist_queue(self):
        if self._queue_blocked:
            return False
        if self._task_store is None:
            return True
        try:
            self._task_store.save(self.files, self.results)
            return True
        except Exception as exc:
            self._on_store_error(str(exc))
            return False

    def _on_store_error(self, error):
        self._store_error = str(error)
        self.queue_notice.setText(tr('store_error').format(error=error))
        self.queue_notice.show()
        logger.error('Task history unavailable: %s', error)

    def _current_settings(self):
        return {
            'encoder_key': self._selected_encoder_key(), 'available_encoders': self.detected_encoder_keys[:],
            'quality_key': QUALITY_KEYS[self.quality_combo.currentIndex()],
            'speed_key': SPEED_KEYS[self.speed_combo.currentIndex()],
            'resolution': RESOLUTION_OPTIONS[self.resolution_combo.currentIndex()][1],
            'output_dir': self.output_edit.text() or None, 'parallel': self.parallel_spin.value(),
            'keep_larger': self.keep_larger_check.isChecked(),
        }

    def _settings_description(self, settings):
        quality = settings.get('quality_key', 'balanced')
        resolution = settings.get('resolution')
        return ' · '.join((tr(QUALITY_TR_KEYS[QUALITY_KEYS.index(quality)]) if quality in QUALITY_KEYS else quality,
                           f'{resolution}p' if resolution else tr('keep_original'),
                           tr('enc_' + settings.get('encoder_key', 'auto')),
                           str(settings.get('output_dir') or tr('output_placeholder'))))

    def _update_policy_summary(self, *_):
        if not hasattr(self, 'policy_summary') or not hasattr(self, 'keep_larger_check'):
            return
        text = tr('settings_summary').format(
            quality=self.quality_combo.currentText(), resolution=self.resolution_combo.currentText(),
            parallel=self.parallel_spin.value(), larger=tr('larger_summary') if self.keep_larger_check.isChecked() else '')
        if self._is_compressing or any(f.get('settings') for f in self.files):
            text += '\n' + tr('new_task_settings')
        self.policy_summary.setText(text)

    def _enqueue_rows(self, rows):
        if not rows or self._stopping or self._close_pending:
            return
        for row in rows:
            self.files[row].setdefault('settings', self._current_settings())
            self.files[row]['status'] = 'queued'
            self.files[row]['source_identity'] = capture_identity(self.files[row]['path'])
        if not self._persist_queue():
            return
        assigned = self.worker.enqueue([self.files[row].copy() for row in rows]) if self.worker else []
        if not assigned:
            self._late_rows.extend(row for row in rows if row not in self._late_rows)
            return
        for index, row in zip(assigned, rows):
            if index != len(self._run_rows):
                raise RuntimeError('Queue index mismatch')
            self._run_rows.append(row)
            self.files[row]['status'] = 'waiting'
            self._progress_weights.append(max(1, self.files[row]['size']))
        self._worker_file_count = len(self._run_rows)
        self._update_batch_progress()

    def _on_task_state(self, index, state):
        row = self._table_row(index)
        if not 0 <= row < len(self.files) or row in self.results:
            return
        self.files[row]['status'] = state
        self.table.item(row, 5).setText(tr(state))
        self._update_batch_progress()

    def toggle_queue_pause(self):
        if not self.worker or not self._is_compressing:
            return
        self._queue_paused = not self._queue_paused
        self.worker.set_paused(self._queue_paused)
        self.pause_btn.setText(tr('resume_queue' if self._queue_paused else 'pause_queue'))
        self._update_batch_progress()

    def cancel_rows(self, rows):
        if not self.worker:
            return
        for row in rows:
            if row in self._run_rows and row not in self.results:
                self.files[row]['excluded'] = True
                self.worker.cancel_task(self._run_rows.index(row))
        self._persist_queue()

    def prioritize_rows(self, rows):
        if not self.worker:
            return
        pending = set(self.worker.pending_indices())
        indices = [self._run_rows.index(row) for row in rows if row in self._run_rows and self._run_rows.index(row) in pending]
        self.worker.prioritize(indices)
        priority = min((f.get('priority', 0) for f in self.files), default=0) - len(indices)
        for offset, index in enumerate(indices):
            self.files[self._run_rows[index]]['priority'] = priority + offset
        self._persist_queue()

    def requeue_with_current_settings(self, rows):
        if self._is_compressing or self._is_importing:
            return
        for row in rows:
            self.files[row]['settings'] = self._current_settings()
            self.files[row]['excluded'] = False
            self.files[row]['status'] = 'queued'
            self.results.pop(row, None)
        self.start_compression(rows=rows)

    def export_diagnostics(self):
        path, _ = QFileDialog.getSaveFileName(self, tr('diagnostics'), f'EllaPuede-{VERSION}-diagnostics.json', 'JSON (*.json)')
        if not path:
            return
        # Do not include raw stderr or absolute paths: both may contain customer filenames.
        report = {'version': VERSION, 'platform': platform.platform(),
                  'encoders': self.detected_encoder_keys, 'logical_cpus': CPU_COUNT,
                  'queue_count': len(self.files), 'persistence_ok': not bool(self._store_error),
                  'results': [{'task_id': self.files[row]['id'],
                               **{key: result.get(key) for key in ('status', 'error_kind', 'encoder_key', 'fallback_used', 'input_size', 'output_size')}}
                              for row, result in self.results.items() if row < len(self.files)]}
        try:
            Path(path).write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
            self.queue_notice.setText(tr('diagnostics_saved'))
            self.queue_notice.show()
        except OSError as exc:
            QMessageBox.warning(self, tr('diagnostics'), str(exc))

    def _emit_video_info(self, row, duration_str):
        """线程池回调 → 发射信号到主线程"""
        self._video_info_signal.emit(row, duration_str)

    def _on_video_info_from_pool(self, token, duration_str):
        row = self._file_rows.get(token)
        if row is not None and row < len(self.files) and self.files[row]['id'] == token:
            self.files[row]['duration_text'] = duration_str
            if self.table.item(row, 1):
                self.table.item(row, 1).setText(duration_str)

    def init_ui(self):
        self.setWindowTitle(f"{tr('app_title')} · {VERSION}")
        self.setWindowIcon(QIcon(str(Path(__file__).with_name('icon.png'))))
        self.setMinimumSize(900, 660)
        self.setStyleSheet("""
            QMainWindow { background: #f6f7f9; }
            QWidget { color: #252b36; font-size: 13px; }
            QLabel { background: transparent; border: none; }
            QFrame#card { background: white; border: 1px solid #e1e5eb; border-radius: 10px; }
            QPushButton { background: white; border: 1px solid #d4dae3; border-radius: 6px;
                          padding: 6px 12px; min-height: 20px; }
            QPushButton:hover { background: #eef2f7; border-color: #9aa8ba; }
            QPushButton:pressed { background: #e4eaf2; }
            QPushButton:disabled { color: #929ba8; background: #eff1f4; border-color: #e5e8ed; }
            QPushButton:focus { border: 2px solid #2463c4; }
            QPushButton#quiet { background: transparent; border: none; color: #52667f; }
            QPushButton#quiet:hover { background: #eaf0f7; color: #214a85; }
            QPushButton#primary { background: #2463c4; border: 1px solid #2463c4;
                                  color: white; font-weight: 600; padding: 8px 24px; }
            QPushButton#primary:hover { background: #1c52a7; }
            QPushButton#primary:disabled { background: #ccd4df; border-color: #ccd4df; color: white; }
            QComboBox { background: white; border: 1px solid #cfd6e0; border-radius: 6px;
                        padding: 6px 28px 6px 10px; combobox-popup: 0; }
            QComboBox:focus, QComboBox:hover { border-color: #2463c4; }
            QComboBox::drop-down { border: none; width: 24px; }
            QComboBox::down-arrow { image: url("__CHEVRON__"); width: 10px; height: 6px; }
            QSpinBox::up-button { subcontrol-origin: border; subcontrol-position: top right;
                width: 22px; height: 17px; border: none; background: #f2f5f9; }
            QSpinBox::down-button { subcontrol-origin: border; subcontrol-position: bottom right;
                width: 22px; height: 17px; border: none; background: #f2f5f9; }
            QSpinBox::up-arrow { image: url("__UP__"); width: 8px; height: 5px; }
            QSpinBox::down-arrow { image: url("__DOWN__"); width: 8px; height: 5px; }
            QComboBox QAbstractItemView { background: white; color: #252b36;
                selection-background-color: #e4edfc; selection-color: #143d7b;
                border: 1px solid #d4dae3; border-radius: 6px; padding: 4px; outline: 0; }
            QComboBox QAbstractItemView::item { min-height: 32px; padding: 0px 10px; border-radius: 4px; }
            QComboBox QAbstractItemView::item:selected { background: #e4edfc; color: #143d7b; }
            QComboBox QAbstractItemView::item:hover { background: #eef2f7; }
            QComboBox:disabled { background: #f1f3f6; color: #8a929e; }
            QLineEdit { background: white; border: 1px solid #d4dae3; border-radius: 6px;
                        padding: 7px 10px; color: #4b5768; }
            QSpinBox { background: white; border: 1px solid #cfd6e0; border-radius: 5px;
                       padding: 5px 4px; }
            QTableWidget { background: white; alternate-background-color: #fafbfc;
                border: 1px solid #e0e5ec; border-radius: 8px; gridline-color: #f0f2f5; }
            QTableWidget::item { padding: 6px 8px; }
            QTableWidget::item:selected { background: #e6effd; color: #143d7b; }
            QHeaderView::section { background: #f9fafc; color: #687386; border: none;
                border-bottom: 1px solid #e7ebf0; padding: 9px 6px; font-size: 12px; }
            QProgressBar { background: #e5eaf1; border: none; border-radius: 3px; }
            QProgressBar::chunk { background: #2463c4; border-radius: 3px; }
            QCheckBox { spacing: 7px; }
            QMenu { background: white; border: 1px solid #d4dae3; border-radius: 6px; padding: 4px; }
            QMenu::item { padding: 8px 18px; border-radius: 4px; }
            QMenu::item:selected { background: #e4edfc; color: #143d7b; }
            QScrollArea { border: 1px solid #e1e5eb; border-radius: 6px; background: #f9fafc; }
        """.replace('__CHEVRON__', str(Path(__file__).with_name('ui-chevron.svg')).replace('\\', '/'))
            .replace('__UP__', str(Path(__file__).with_name('ui-up.svg')).replace('\\', '/'))
            .replace('__DOWN__', str(Path(__file__).with_name('ui-down.svg')).replace('\\', '/')))
        menubar = self.menuBar()
        menubar.clear()
        self.language_menu = menubar.addMenu(tr('language'))
        self.language_menu.addAction(tr('chinese'), lambda: self.switch_language('zh'))
        self.language_menu.addAction(tr('english'), lambda: self.switch_language('en'))
        tools_menu = menubar.addMenu(tr('tools'))
        self.refresh_action = tools_menu.addAction(tr('refresh_hardware'), self.check_environment)
        tools_menu.addAction(tr('open_logs'), lambda: QDesktopServices.openUrl(QUrl.fromLocalFile(LOG_DIR)))
        tools_menu.addAction(tr('diagnostics'), self.export_diagnostics)

        central = QWidget()
        self.setCentralWidget(central)
        layout = QVBoxLayout(central)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(14)
        header = QHBoxLayout()
        title = QLabel(tr('simple_title'))
        title.setStyleSheet('font-size: 20px; font-weight: 600; color: #1e293b;')
        header.addWidget(title)
        header.addStretch()
        self.status_indicator = QLabel(tr('detecting'))
        self.status_indicator.setStyleSheet('font-size: 12px; color: #6b778a;')
        header.addWidget(self.status_indicator)
        layout.addLayout(header)

        def combo(labels, width):
            widget = QComboBox()
            view = QListView(widget)
            view.setUniformItemSizes(True)
            view.setMouseTracking(True)
            view.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
            widget.setView(view)
            widget.setItemDelegate(QStyledItemDelegate(widget))
            widget.setMaxVisibleItems(8)
            widget.addItems(labels)
            widget.setProperty('baseMinimumWidth', width)
            widget.setMinimumWidth(width)
            widget.setFixedHeight(34)
            widget.setSizeAdjustPolicy(QComboBox.SizeAdjustPolicy.AdjustToContents)
            return widget

        self.quality_combo = combo([tr(k) for k in QUALITY_TR_KEYS], 140)
        self.quality_combo.setCurrentIndex(1)
        self.resolution_combo = combo([tr(k) if h is None else k for k, h in RESOLUTION_OPTIONS], 160)
        basic = QFrame()
        basic.setObjectName('card')
        row = QHBoxLayout(basic)
        row.setContentsMargins(16, 13, 16, 13)
        row.setSpacing(12)
        for label, widget in [(tr('quality'), self.quality_combo), (tr('resolution'), self.resolution_combo)]:
            text = QLabel(label)
            text.setBuddy(widget)
            widget.setAccessibleName(label)
            row.addWidget(text)
            row.addWidget(widget)
            row.addSpacing(8)
        row.addStretch()
        self.advanced_btn = QPushButton(tr('advanced'))
        self.advanced_btn.setObjectName('quiet')
        self.advanced_btn.setCheckable(True)
        row.addWidget(self.advanced_btn)
        layout.addWidget(basic)
        self.policy_summary = QLabel()
        self.policy_summary.setWordWrap(True)
        self.policy_summary.setStyleSheet('font-size: 12px; color: #52667f;')
        layout.addWidget(self.policy_summary)
        self.queue_notice = QLabel()
        self.queue_notice.setWordWrap(True)
        self.queue_notice.setStyleSheet('color: #955323; font-size: 12px;')
        self.queue_notice.hide()
        layout.addWidget(self.queue_notice)

        self.advanced_panel = QFrame()
        self.advanced_panel.setObjectName('card')
        advanced = QVBoxLayout(self.advanced_panel)
        advanced.setContentsMargins(16, 12, 16, 12)
        advanced.setSpacing(10)
        enc_row = QHBoxLayout()
        enc_label = QLabel(tr('encoder_mode'))
        self.encoder_combo = combo([], 280)
        self.encoder_combo.currentIndexChanged.connect(self.on_encoder_changed)
        enc_label.setBuddy(self.encoder_combo)
        self.encoder_combo.setAccessibleName(tr('encoder_mode'))
        enc_row.addWidget(enc_label)
        enc_row.addWidget(self.encoder_combo, 1)
        self.speed_combo = combo([tr(k) for k in SPEED_TR_KEYS], 140)
        self.speed_combo.setCurrentIndex(1)
        speed_label = QLabel(tr('speed'))
        speed_label.setBuddy(self.speed_combo)
        self.speed_combo.setAccessibleName(tr('speed'))
        enc_row.addSpacing(12)
        enc_row.addWidget(speed_label)
        enc_row.addWidget(self.speed_combo)
        self.speed_auto_label = QLabel(tr('speed_auto'))
        self.speed_auto_label.setStyleSheet('color: #52667f;')
        self.speed_auto_label.setToolTip(tr('speed_not_available'))
        self.speed_auto_label.hide()
        enc_row.addWidget(self.speed_auto_label)
        self.parallel_spin = QSpinBox()
        self.parallel_spin.setRange(1, 8)
        self.parallel_spin.setValue(2)
        self.parallel_spin.setFixedSize(84, 34)
        self.parallel_spin.setToolTip(tr('parallel_tip'))
        self.parallel_spin.setAccessibleName(tr('parallel'))
        parallel_label = QLabel(tr('parallel'))
        parallel_label.setBuddy(self.parallel_spin)
        enc_row.addSpacing(12)
        enc_row.addWidget(parallel_label)
        enc_row.addWidget(self.parallel_spin)
        advanced.addLayout(enc_row)
        self.encoder_info = QLabel()
        self.encoder_info.setWordWrap(True)
        self.encoder_info.setStyleSheet('color: #6b778a; font-size: 12px;')
        advanced.addWidget(self.encoder_info)
        details_row = QHBoxLayout()
        self.keep_larger_check = QCheckBox(tr('keep_larger'))
        details_row.addWidget(self.keep_larger_check)
        details_row.addStretch()
        self.guide_btn = QPushButton(tr('guide_toggle'))
        self.guide_btn.setObjectName('quiet')
        self.guide_btn.setCheckable(True)
        self.guide_btn.clicked.connect(self._toggle_guide)
        details_row.addWidget(self.guide_btn)
        advanced.addLayout(details_row)
        safety_note = QLabel(tr('safety_note'))
        safety_note.setWordWrap(True)
        safety_note.setStyleSheet('color: #6b778a; font-size: 11px;')
        advanced.addWidget(safety_note)
        self.guide_panel = QScrollArea()
        self.guide_panel.setWidgetResizable(True)
        self.guide_panel.setFixedHeight(130)
        self.guide_label = QLabel(tr('guide_content'))
        self.guide_label.setWordWrap(True)
        self.guide_label.setMargin(10)
        self.guide_panel.setWidget(self.guide_label)
        self.guide_panel.hide()
        advanced.addWidget(self.guide_panel)
        self.advanced_panel.setMinimumHeight(146)
        self.advanced_panel.hide()
        self.advanced_btn.toggled.connect(self._toggle_advanced)
        layout.addWidget(self.advanced_panel)

        output_row = QHBoxLayout()
        out_label = QLabel(tr('output_dir'))
        output_row.addWidget(out_label)
        self.output_edit = QLineEdit()
        self.output_edit.setReadOnly(True)
        self.output_edit.setPlaceholderText(tr('output_placeholder'))
        self.output_edit.setToolTip(tr('source_safe'))
        out_label.setBuddy(self.output_edit)
        self.output_edit.setAccessibleName(tr('output_dir'))
        output_row.addWidget(self.output_edit, 1)
        self.browse_output_btn = QPushButton(tr('select'))
        self.browse_output_btn.clicked.connect(self.browse_output)
        output_row.addWidget(self.browse_output_btn)
        self.clear_output_btn = QPushButton(tr('clear'))
        self.clear_output_btn.setObjectName('quiet')
        self.clear_output_btn.clicked.connect(self.output_edit.clear)
        self.clear_output_btn.hide()
        self.output_edit.textChanged.connect(lambda text: self.clear_output_btn.setVisible(bool(text)))
        output_row.addWidget(self.clear_output_btn)
        layout.addLayout(output_row)

        self.drop_area = DropArea()
        self.drop_area.setMinimumHeight(68)
        self.drop_area.files_dropped.connect(self.import_paths)
        self.drop_area.clicked.connect(self.browse_files)
        layout.addWidget(self.drop_area)
        toolbar = QHBoxLayout()
        self.add_file_btn = QPushButton(tr('add_files'))
        self.add_file_btn.clicked.connect(self.browse_files)
        toolbar.addWidget(self.add_file_btn)
        self.add_folder_btn = QPushButton(tr('add_folder'))
        self.add_folder_btn.setObjectName('quiet')
        self.add_folder_btn.clicked.connect(self.browse_folder)
        toolbar.addWidget(self.add_folder_btn)
        self.file_count_label = QLabel()
        self.file_count_label.setStyleSheet('color: #7a8493; font-size: 12px;')
        toolbar.addSpacing(8)
        toolbar.addWidget(self.file_count_label)
        toolbar.addStretch()
        self.retry_btn = QPushButton(tr('retry_failed'))
        self.retry_btn.setObjectName('quiet')
        self.retry_btn.clicked.connect(self.retry_failed)
        self.retry_btn.hide()
        toolbar.addWidget(self.retry_btn)
        self.open_output_btn = QPushButton(tr('open_output'))
        self.open_output_btn.setObjectName('quiet')
        self.open_output_btn.clicked.connect(self.open_output_folder)
        self.open_output_btn.hide()
        toolbar.addWidget(self.open_output_btn)
        self.remove_btn = QPushButton(tr('remove_selected'))
        self.remove_btn.setObjectName('quiet')
        self.remove_btn.clicked.connect(self.remove_selected)
        toolbar.addWidget(self.remove_btn)
        self.clear_btn = QPushButton(tr('clear_list'))
        self.clear_btn.setObjectName('quiet')
        self.clear_btn.clicked.connect(self.clear_files)
        toolbar.addWidget(self.clear_btn)
        layout.addLayout(toolbar)

        self.table = QTableWidget(0, 6)
        self._file_rows.clear()
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setHorizontalHeaderLabels([tr('col_filename'), tr('col_duration'), tr('col_size'),
                                              tr('col_progress'), tr('col_output'), tr('col_status')])
        self.table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.Stretch)
        for column, width in [(1, 70), (2, 80), (3, 90), (4, 90), (5, 145)]:
            self.table.horizontalHeader().setSectionResizeMode(column, QHeaderView.ResizeMode.Fixed)
            self.table.setColumnWidth(column, width)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.setMinimumHeight(145)
        self.table.verticalHeader().setDefaultSectionSize(38)
        self.table.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.table.customContextMenuRequested.connect(self._show_table_menu)
        self.table.cellDoubleClicked.connect(self.show_result_details)
        self.table.itemSelectionChanged.connect(self._update_result_actions)
        QShortcut(QKeySequence.StandardKey.Delete, self.table, self.remove_selected)
        QShortcut(QKeySequence(Qt.Key.Key_Backspace), self.table, self.remove_selected)
        layout.addWidget(self.table, 1)

        self.total_progress = QProgressBar()
        self.total_progress.setFixedHeight(5)
        self.total_progress.setTextVisible(False)
        self.total_progress.setValue(0)
        self.total_progress.hide()
        layout.addWidget(self.total_progress)
        bottom = QHBoxLayout()
        self.progress_label = QLabel(tr('source_safe'))
        self.progress_label.setWordWrap(True)
        self.progress_label.setStyleSheet('color: #778293; font-size: 12px;')
        bottom.addWidget(self.progress_label)
        bottom.addStretch()
        self.pause_btn = QPushButton(tr('pause_queue'))
        self.pause_btn.setToolTip(tr('pause_tip'))
        self.pause_btn.clicked.connect(self.toggle_queue_pause)
        self.pause_btn.hide()
        bottom.addWidget(self.pause_btn)
        self.stop_btn = QPushButton(tr('stop'))
        self.stop_btn.clicked.connect(self.stop_compression)
        self.stop_btn.setEnabled(False)
        self.stop_btn.hide()
        bottom.addWidget(self.stop_btn)
        self.start_btn = QPushButton(tr('start'))
        self.start_btn.setObjectName('primary')
        self.start_btn.setMinimumWidth(124)
        self.start_btn.clicked.connect(self.start_compression)
        self.start_btn.setEnabled(False)
        bottom.addWidget(self.start_btn)
        layout.addLayout(bottom)
        for widget in (self.quality_combo, self.resolution_combo, self.encoder_combo, self.speed_combo):
            self._fit_combo_width(widget)
            widget.currentIndexChanged.connect(self._update_policy_summary)
        self.parallel_spin.valueChanged.connect(self._update_policy_summary)
        self.keep_larger_check.toggled.connect(self._update_policy_summary)
        self._update_policy_summary()
        self.update_count()


    # ---- UI 状态管理 ----

    def _set_compressing(self, active):
        self._is_compressing = active
        busy = active or self._is_importing
        closing = self._close_pending or self._queue_blocked
        for widget in (self.add_file_btn, self.add_folder_btn, self.drop_area):
            widget.setEnabled(not self._is_importing and not closing)
        for widget in (self.quality_combo, self.resolution_combo, self.browse_output_btn,
                       self.clear_output_btn, self.output_edit, self.keep_larger_check):
            widget.setEnabled(not closing)
        self.parallel_spin.setEnabled(not busy and not closing)
        self.remove_btn.setEnabled(not busy)
        self.clear_btn.setEnabled(not busy)
        self.encoder_combo.setEnabled(self._environment_ready and not closing)
        self.language_menu.setEnabled(not busy)
        self.refresh_action.setEnabled(not busy)
        self.retry_btn.setEnabled(not busy and any(r.get('status') == 'failed' for r in self.results.values()))
        self._update_start_action()
        self.stop_btn.setEnabled(busy and not self._stopping)
        self.stop_btn.setVisible(busy)
        self.stop_btn.setText(tr('stop_import' if self._is_importing and not active else 'stop'))
        self.pause_btn.setVisible(active)
        self.pause_btn.setEnabled(active and not self._stopping)
        self.pause_btn.setText(tr('resume_queue' if self._queue_paused else 'pause_queue'))
        self.total_progress.setVisible(active or bool(self.results))
        self.advanced_btn.setEnabled(not closing)
        self._update_result_actions()
        self._update_speed_enabled()
        self._update_policy_summary()

    def _update_result_actions(self):
        busy = self._is_compressing or self._is_importing
        self.retry_btn.setVisible(not busy and any(r.get('status') == 'failed' for r in self.results.values()))
        self.open_output_btn.setVisible(any(r.get('status') == 'success' for r in self.results.values()))
        self.clear_btn.setVisible(bool(self.files) and not busy)
        self.remove_btn.setVisible(bool(self.table.selectedIndexes()) and not busy)

    def _pending_rows(self):
        return [row for row in range(len(self.files))
                if self.results.get(row, {}).get('status') not in ('success', 'kept_original')
                and not self.files[row].get('excluded')]

    def _update_start_action(self):
        pending = self._pending_rows()
        complete = len(self.files) - len(pending)
        key = 'recompress' if self.files and not pending else ('resume' if complete or any(f.get('settings') for f in self.files) else 'start')
        self.start_btn.setText(tr(key))
        self.start_btn.setToolTip(tr('retry_from_start'))
        self.start_btn.setEnabled(bool(self.files) and self._environment_ready
                                  and not self._is_compressing and not self._is_importing
                                  and not self._queue_blocked and not self._close_pending)

    def _selected_encoder_key(self):
        idx = self.encoder_combo.currentIndex()
        return self.available_encoder_keys[idx] if 0 <= idx < len(self.available_encoder_keys) else 'auto'

    def _update_speed_enabled(self):
        key = self._selected_encoder_key()
        if key == 'auto':
            key = get_auto_encoder(self.detected_encoder_keys)
        enabled = ENCODER_CONFIGS.get(key, {}).get('has_preset', False)
        self.speed_combo.setEnabled(enabled and not self._close_pending)
        self.speed_combo.setVisible(enabled)
        self.speed_combo.setToolTip('' if enabled else tr('speed_not_available'))
        if hasattr(self, 'speed_auto_label'):
            self.speed_auto_label.setVisible(not enabled)

    def _toggle_advanced(self, visible):
        if visible:
            self._collapsed_height = self.height()
        self.advanced_panel.setVisible(visible)
        self._fit_visible_settings()
        if not visible:
            self.resize(self.width(), max(660, getattr(self, '_collapsed_height', 660)))

    @staticmethod
    def _fit_combo_width(widget):
        # AdjustToContents does not include all stylesheet padding on every
        # platform. Measure the actual edit field, including the arrow gutter.
        widget.ensurePolished()
        option = QStyleOptionComboBox()
        widget.initStyleOption(option)
        edit = widget.style().subControlRect(
            QStyle.ComplexControl.CC_ComboBox, option,
            QStyle.SubControl.SC_ComboBoxEditField, widget)
        chrome = option.rect.width() - edit.width()
        text = max((widget.fontMetrics().horizontalAdvance(widget.itemText(i))
                    for i in range(widget.count())), default=0)
        widget.setMinimumWidth(max(widget.property('baseMinimumWidth'), text + chrome))

    def _fit_visible_settings(self):
        if getattr(self, '_fitting_settings', False):
            return
        self._fitting_settings = True
        try:
            self.setMinimumWidth(max(900, self.minimumSizeHint().width()))
            self.centralWidget().layout().activate()
            advanced = self.advanced_panel.layout()
            advanced.invalidate()
            height = max(146, advanced.totalMinimumSize().height(),
                         advanced.totalHeightForWidth(self.advanced_panel.width()))
            self.advanced_panel.setMinimumHeight(height)
            self.centralWidget().layout().activate()
            self.setMinimumHeight(max(660, self.minimumSizeHint().height()))
            if self.height() < self.minimumHeight():
                self.resize(self.width(), self.minimumHeight())
        finally:
            self._fitting_settings = False

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if hasattr(self, 'advanced_panel') and self.advanced_panel.isVisible():
            self._fit_visible_settings()

    def _toggle_guide(self):
        visible = self.guide_btn.isChecked()
        self.guide_panel.setVisible(visible)
        self._fit_visible_settings()

    def _preferences(self):
        return {'quality': self.quality_combo.currentIndex(), 'speed': self.speed_combo.currentIndex(),
                'resolution': self.resolution_combo.currentIndex(), 'parallel': self.parallel_spin.value(),
                'output': self.output_edit.text(), 'keep_larger': self.keep_larger_check.isChecked()}

    def _apply_preferences(self, prefs):
        for name, combo in [('quality', self.quality_combo), ('speed', self.speed_combo),
                            ('resolution', self.resolution_combo)]:
            index = prefs.get(name)
            if isinstance(index, int) and 0 <= index < combo.count():
                combo.setCurrentIndex(index)
        self.parallel_spin.setValue(max(1, min(8, int(prefs.get('parallel', 2)))))
        self.output_edit.setText(str(prefs.get('output', '')))
        self.keep_larger_check.setChecked(bool(prefs.get('keep_larger', False)))

    def _load_preferences(self):
        try:
            data = json.loads(Path(LM._get_config_path()).read_text(encoding='utf-8'))
            self._apply_preferences(data.get('preferences', {}))
        except (OSError, ValueError, TypeError, AttributeError):
            pass

    def _save_preferences(self):
        try:
            path = Path(LM._get_config_path())
            try:
                data = json.loads(path.read_text(encoding='utf-8'))
            except (OSError, ValueError):
                data = {}
            data.update(language=get_lang(), preferences=self._preferences())
            path.parent.mkdir(parents=True, exist_ok=True)
            temp = path.with_suffix('.tmp')
            temp.write_text(json.dumps(data, ensure_ascii=False), encoding='utf-8')
            os.replace(temp, path)
        except (OSError, TypeError, AttributeError):
            logger.exception('Cannot save preferences')

    def switch_language(self, lang):
        if lang == get_lang() or self._is_compressing or self._is_importing or self._close_pending:
            return
        prefs = self._preferences()
        entries, results = self.files[:], self.results.copy()
        selected = self._selected_encoder_key()
        LM.save_language(lang)
        old = self.takeCentralWidget()
        self.files = []
        self.results = {}
        self.init_ui()
        self._apply_preferences(prefs)
        self.files = entries
        for row, entry in enumerate(entries):
            self._append_file_row(entry)
            self.table.item(row, 1).setText(entry.get('duration_text', '…'))
        self.update_count()
        self._on_environment_ready(self.detected_encoder_keys, '')
        if selected in self.available_encoder_keys:
            self.encoder_combo.setCurrentIndex(self.available_encoder_keys.index(selected))
        self.results = results
        for row, detail in results.items():
            self._display_result(row, detail)
        self._set_compressing(False)
        if self.isVisible():
            # Give the replacement controls real geometry before subsequent
            # actions (such as opening Advanced) calculate their layout.
            self.centralWidget().show()
        old.deleteLater()

    def on_encoder_changed(self, index):
        key = self._selected_encoder_key()
        if key == 'auto':
            actual = get_auto_encoder(self.detected_encoder_keys) or 'cpu_h264'
            self.encoder_info.setText(tr('auto_info').format(encoder=tr('enc_' + actual)))
        else:
            self.encoder_info.setText(tr(ENCODER_CONFIGS.get(key, {}).get('info_key', 'info_cpu')))
        if hasattr(self, 'speed_combo'):
            self._update_speed_enabled()
        if self._environment_ready:
            self._update_hardware_summary()
        if hasattr(self, 'advanced_panel') and self.advanced_panel.isVisible():
            self._fit_visible_settings()

    def _update_hardware_summary(self):
        key = self._selected_encoder_key()
        actual = get_auto_encoder(self.detected_encoder_keys) if key == 'auto' else key
        names = {'apple_h264': 'Apple GPU', 'apple_h265': 'Apple GPU', 'nvidia': 'NVIDIA GPU',
                 'amd': 'AMD GPU', 'intel': 'Intel GPU', 'cpu_h264': 'CPU', 'cpu_h265': 'CPU'}
        self.status_indicator.setText(tr('hardware_auto' if key == 'auto' else 'hardware_manual').format(device=names.get(actual, 'CPU')))
        self.status_indicator.setToolTip(tr('auto_info').format(encoder=tr('enc_' + (actual or 'cpu_h264'))))
        self.status_indicator.setStyleSheet('font-size: 12px; color: #6b778a;')

    def _populate_encoders(self):
        self.available_encoder_keys = ['auto'] + self.detected_encoder_keys if self._environment_ready else []
        self.encoder_combo.blockSignals(True)
        self.encoder_combo.clear()
        self.encoder_combo.addItems([tr('enc_' + key) for key in self.available_encoder_keys])
        self._fit_combo_width(self.encoder_combo)
        self.encoder_combo.blockSignals(False)
        self.on_encoder_changed(0)

    def check_environment(self):
        if self._is_compressing or self._is_importing or (self.environment_worker and self.environment_worker.isRunning()):
            return
        self._environment_ready = False
        self._set_compressing(False)
        self.status_indicator.setText(tr('detecting'))
        self.status_indicator.setStyleSheet('font-size: 12px; color: #52647d;')
        self.environment_worker = EnvironmentWorker(self)
        self.environment_worker.ready.connect(self._on_environment_ready)
        self.environment_worker.finished.connect(self._on_background_finished)
        self.environment_worker.start()

    def _on_environment_ready(self, available_keys, error):
        self.detected_encoder_keys = list(available_keys)
        self._environment_ready = bool(available_keys) and not error
        self._populate_encoders()
        self.status_indicator.setText(tr('ffmpeg_ready') if self._environment_ready else tr('ffmpeg_not_found'))
        self.status_indicator.setToolTip(error)
        self.status_indicator.setStyleSheet('font-size: 12px; color: #a33a3a;')
        if self._environment_ready:
            self._update_hardware_summary()
        self._set_compressing(False)
        if error:
            self.encoder_info.setText(tr('no_hardware'))
            self.encoder_info.setToolTip(error)

    def _show_ffmpeg_error(self):
        self._on_environment_ready([], tr('ffmpeg_error_mac') if IS_MAC else tr('ffmpeg_error_win'))

    # ---- 文件操作 ----

    def browse_output(self):
        folder = QFileDialog.getExistingDirectory(self, tr('select_output'))
        if folder:
            self.output_edit.setText(folder)

    def browse_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self, tr('select_video'), "",
            f"{tr('video_files')} ({VIDEO_FILTER_STR});;{tr('all_files')} (*)"
        )
        if files:
            self.import_paths(files)

    def browse_folder(self):
        folder = QFileDialog.getExistingDirectory(self, tr('select_folder'))
        if folder:
            self.import_paths([folder])

    def import_paths(self, paths):
        if not paths or self._is_importing or self._close_pending or self._queue_blocked:
            return
        self._is_importing = True
        self._import_start_count = len(self.files)
        self._import_settings = self._current_settings() if self._is_compressing else None
        self._set_compressing(self._is_compressing)
        if not self._is_compressing:
            self.progress_label.setText(tr('importing').format(count=0))
        self.import_worker = FileImportWorker(paths, (f['path'] for f in self.files), self)
        self.import_worker.batch_ready.connect(self._on_import_batch)
        self.import_worker.finished.connect(self._on_import_finished)
        self.import_worker.start()

    def _on_import_batch(self, entries):
        try:
            if self._close_pending or (self.import_worker and self.import_worker._cancel.is_set()):
                return
            self.table.setUpdatesEnabled(False)
            rows = []
            for entry in entries:
                entry['status'] = 'queued'
                if self._import_settings:
                    entry['settings'] = dict(self._import_settings)
                rows.append(len(self.files))
                self.files.append(entry)
                self._append_file_row(entry)
            self._persist_queue()
            if self._is_compressing:
                self._enqueue_rows(rows)
            elif self._import_settings and not self._stopping:
                self._late_rows.extend(row for row in rows if row not in self._late_rows)
            self.update_count()
            if not self._is_compressing:
                self.progress_label.setText(tr('importing').format(count=len(self.files) - self._import_start_count))
        finally:
            self.table.setUpdatesEnabled(True)
            if self.import_worker:
                self.import_worker.release_batch()

    def _on_import_finished(self):
        finished = self.import_worker
        stopped = bool(finished and finished._cancel.is_set())
        added = len(self.files) - self._import_start_count
        stats = getattr(finished, 'stats', {}) if finished else {}
        self.import_worker = None
        self._is_importing = False
        if finished:
            finished.deleteLater()
        self._set_compressing(self._is_compressing)
        self.update_count()
        if not self._is_compressing:
            if stopped:
                self.progress_label.setText(tr('import_stopped').format(count=added))
            elif not added:
                self.progress_label.setText(tr('import_empty'))
        if any(stats.get(key, 0) for key in ('duplicate', 'unsupported', 'unreadable')):
            self.queue_notice.setText(tr('import_report').format(added=added, **{k: stats.get(k, 0) for k in ('duplicate', 'unsupported', 'unreadable')}))
            self.queue_notice.show()
        self._persist_queue()
        if self._late_rows and not self._is_compressing and not self._close_pending and not self._stopping:
            rows, self._late_rows = self._late_rows, []
            self.start_compression(rows=rows)
        self._on_background_finished()

    def add_files(self, paths):
        """Synchronous entry point for small selections and tests."""
        if self._is_importing or self._close_pending or self._queue_blocked:
            return
        existing = {os.path.normcase(f['path']) for f in self.files}
        rows = []
        for p in paths:
            p = os.path.realpath(os.path.abspath(p))
            identity = os.path.normcase(p)
            if not os.path.isfile(p) or Path(p).suffix.lower() not in VIDEO_EXTENSIONS or identity in existing:
                continue
            try:
                entry = {'id': uuid.uuid4().hex, 'path': p, 'name': os.path.basename(p),
                         'size': os.path.getsize(p), 'status': 'queued'}
                if self._is_compressing:
                    entry['settings'] = self._current_settings()
                rows.append(len(self.files))
                self.files.append(entry)
                existing.add(identity)
                self._append_file_row(entry)
            except OSError as exc:
                logger.warning('Failed to add file %s: %s', p, exc)
        self._persist_queue()
        if self._is_compressing:
            self._enqueue_rows(rows)
        self.update_count()

    def _append_file_row(self, entry):
        p, name, size, token = entry['path'], entry['name'], entry['size'], entry['id']
        row = self.table.rowCount()
        self._file_rows[token] = row
        self.table.insertRow(row)

        name_item = QTableWidgetItem(name)
        name_item.setToolTip(p)
        self.table.setItem(row, 0, name_item)

        dur_item = QTableWidgetItem("...")
        dur_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        self.table.setItem(row, 1, dur_item)

        size_item = QTableWidgetItem(fmt_size(size))
        size_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        self.table.setItem(row, 2, size_item)

        progress_bar = QProgressBar()
        progress_bar.setRange(0, 100)
        progress_bar.setValue(0)
        progress_bar.setTextVisible(True)
        progress_bar.setFormat("%p%")
        progress_bar.setStyleSheet("""
            QProgressBar { border: none; border-radius: 3px; background: #e5eaf1; height: 16px; text-align: center; font-size: 11px; color: #252b36; }
            QProgressBar::chunk { background: #93b6ec; border-radius: 3px; }
        """)
        self.table.setCellWidget(row, 3, progress_bar)

        out_item = QTableWidgetItem("-")
        out_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        self.table.setItem(row, 4, out_item)

        status_item = QTableWidgetItem(tr('waiting'))
        status_item.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
        status_item.setForeground(QColor("#687386"))
        self.table.setItem(row, 5, status_item)

        # 线程池获取时长
        self.info_pool.submit(token, p)

    def _show_table_menu(self, pos):
        menu = QMenu(self)
        rows = sorted({index.row() for index in self.table.selectedIndexes()})
        if rows:
            if self._is_compressing:
                menu.addAction(tr('prioritize'), lambda: self.prioritize_rows(rows))
                menu.addAction(tr('cancel_selected'), lambda: self.cancel_rows(rows))
            elif not self._is_importing:
                menu.addAction(tr('recompress_selected'), lambda: self.start_compression(rows=rows))
                menu.addAction(tr('apply_settings'), lambda: self.requeue_with_current_settings(rows))
                menu.addAction(tr('remove_selected'), self.remove_selected)
        row = self.table.currentRow()
        if row >= 0:
            menu.addAction(tr('details'), lambda: self.show_result_details(row, 0))
            if self.results.get(row, {}).get('status') in ('success', 'kept_original'):
                menu.addAction(tr('open_output'), self.open_output_folder)
        if not self._is_compressing and not self._is_importing:
            menu.addAction(tr('clear_list'), self.clear_files)
        menu.exec(self.table.viewport().mapToGlobal(pos))

    def remove_selected(self):
        if self._is_compressing or self._is_importing:
            return
        rows = sorted(set(idx.row() for idx in self.table.selectedIndexes()), reverse=True)
        old_results = {f['id']: self.results[i] for i, f in enumerate(self.files) if i in self.results}
        for row in rows:
            if row < len(self.files):
                del self.files[row]
            self.table.removeRow(row)
        self.results = {i: old_results[f['id']] for i, f in enumerate(self.files) if f['id'] in old_results}
        self._file_rows = {entry['id']: row for row, entry in enumerate(self.files)}
        self.update_count()
        self._persist_queue()

    def clear_files(self):
        if self._is_compressing or self._is_importing:
            return
        if hasattr(self.info_pool, 'cancel_pending'):
            self.info_pool.cancel_pending()
        self.files.clear()
        self._file_rows.clear()
        self.results.clear()
        self.table.setRowCount(0)
        self.update_count()
        self._persist_queue()

    def update_count(self):
        count = len(self.files)
        total_size = sum(f['size'] for f in self.files)
        self.file_count_label.setText(
            tr('file_count').format(count=count, size=fmt_size(total_size))
        )

        self._update_start_action()
        self.retry_btn.setEnabled(not self._is_compressing and any(r.get('status') == 'failed' for r in self.results.values()))
        self._update_result_actions()
        if not self.files:
            self.total_progress.setValue(0)
            self.total_progress.hide()
            self.progress_label.setText(tr('source_safe'))
        elif not self._is_compressing and not self._is_importing and self._pending_rows():
            self.total_progress.setValue(0)
            self.total_progress.hide()
            self.progress_label.setText(tr('pending_count').format(count=len(self._pending_rows()))
                                       if self.results else tr('source_safe'))


    # ---- 压缩控制 ----

    def start_compression(self, checked=False, rows=None):
        if self._is_compressing or self._is_importing or not self._environment_ready or self._close_pending or self._queue_blocked:
            return
        if not self.files:
            return
        self._save_preferences()
        self._run_rows = (self._pending_rows() or list(range(len(self.files)))) if rows is None else list(dict.fromkeys(rows))
        self._run_rows = [row for row in self._run_rows if 0 <= row < len(self.files)]
        self._run_rows.sort(key=lambda row: (self.files[row].get('priority', 0), row))
        if not self._run_rows:
            return
        settings = self._current_settings()
        for row in self._run_rows:
            entry = self.files[row]
            entry['excluded'] = False
            if not entry.get('settings'):
                entry['settings'] = dict(settings)
            # Capability inventory is refreshed on this host; the requested output goal is retained.
            entry['settings']['available_encoders'] = self.detected_encoder_keys[:]
            entry['status'] = 'queued'
            entry['source_identity'] = capture_identity(entry['path'])
            self.results.pop(row, None)
            self.table.cellWidget(row, 3).setValue(0)
            self.table.item(row, 4).setText('-')
            self.table.item(row, 5).setText(tr('waiting'))
            self.table.item(row, 5).setToolTip('')
        if not self._persist_queue():
            return
        if not self._store_error:
            self.queue_notice.hide()
        self._finished_indices = set()
        self._row_progress = {}
        self._pending_summary = None
        self._late_rows = []
        self.total_progress.setValue(0)
        self.progress_label.setText(tr('preparing'))
        self._worker_file_count = len(self._run_rows)
        self._run_started_at = time.monotonic()
        self._stopping = False
        self._queue_paused = False
        self._progress_weights = [max(1, self.files[row]['size']) for row in self._run_rows]
        self._set_compressing(True)
        self.worker = CompressionWorker([self.files[row].copy() for row in self._run_rows], settings)
        for row in self._run_rows:
            self.files[row]['status'] = 'waiting'
        self.worker.setParent(self)
        if self._task_store:
            self.worker.result_callback = self._task_store.update_result
            self.worker.checkpoint_callback = self._task_store.record_artifacts
        self.worker.progress.connect(self.on_progress)
        self.worker.task_state.connect(self._on_task_state)
        self.worker.persistence_error.connect(self._on_store_error)
        self.worker.result_detail.connect(self.on_result_detail)
        self.worker.file_done.connect(self.on_file_done)
        self.worker.all_done.connect(self.on_all_done)
        self.worker.finished.connect(self._on_worker_finished)
        self.worker.start()

    def retry_failed(self):
        rows = sorted(row for row, result in self.results.items() if result.get('status') == 'failed')
        self.start_compression(rows=rows)

    def stop_compression(self):
        if self.import_worker and self._is_importing:
            self.import_worker.stop()
        if self.worker and self._is_compressing:
            self._stopping = True
            self.worker.stop()
        self.stop_btn.setEnabled(False)
        self.progress_label.setText(tr('stopping'))

    def _table_row(self, index):
        return self._run_rows[index] if 0 <= index < len(self._run_rows) else index

    def on_progress(self, index, percent, status):
        if index in self._finished_indices:
            return
        row = self._table_row(index)
        if row < self.table.rowCount():
            self.table.cellWidget(row, 3).setValue(percent)
            self.table.item(row, 5).setText(status)
            self._row_progress[index] = percent
            self._update_batch_progress()

    def _update_batch_progress(self):
        if not self._worker_file_count:
            return
        weights = self._progress_weights or [1] * self._worker_file_count
        fraction = sum(weights[i] * self._row_progress.get(i, 0) for i in range(len(weights))) / sum(weights) / 100
        self.total_progress.setValue(min(100, int(fraction * 100)))
        if self._stopping:
            return
        active = len(self.worker.active_indices()) if self.worker else 0
        pending = len(self.worker.pending_indices()) if self.worker else 0
        if self._queue_paused:
            text = tr('queue_paused').format(active=active, pending=pending)
        else:
            text = tr('queue_running').format(done=len(self._finished_indices), total=self._worker_file_count,
                                              active=active, pending=pending)
        elapsed = max(0, time.monotonic() - self._run_started_at) if self._run_started_at else 0
        if elapsed >= 1:
            text += ' · ' + tr('elapsed').format(time=fmt_duration(elapsed))
        # Mixed jobs and live additions invalidate a bytes-based ETA. Avoid false precision.
        self.progress_label.setText(text)

    def on_result_detail(self, index, detail):
        row = self._table_row(index)
        self.results[row] = detail
        if row < len(self.files):
            self.files[row]['status'] = detail.get('status', 'failed')
        if detail.get('status') == 'cancelled':
            self._finished_indices.add(index)
            self._row_progress[index] = 100
        self._display_result(row, detail)
        self._update_result_actions()
        if detail.get('fallback_used'):
            self.status_indicator.setText(_core_message('部分任务已转为 CPU', 'Some jobs switched to CPU'))
        self._update_batch_progress()

    def _display_result(self, row, detail):
        if row >= self.table.rowCount():
            return
        state = detail.get('status', 'failed')
        status, out = self.table.item(row, 5), self.table.item(row, 4)
        if state == 'success':
            before, after = detail.get('input_size', self.files[row]['size']), detail.get('output_size', 0)
            pct = (1 - after / before) * 100 if before else 0
            status.setText(tr('result_saved' if pct >= 0 else 'result_larger').format(percent=abs(pct)))
            status.setForeground(QColor('#157246'))
            out.setText(fmt_size(after))
        else:
            status.setText(_core_message('未变小', 'Not smaller') if state == 'kept_original' else tr(state))
            status.setForeground(QColor('#bd2525' if state == 'failed' else '#5e6672'))
            out.setText('—')
        tooltip = self._result_text(detail)
        status.setToolTip(tooltip)
        out.setToolTip(tooltip)
        self.table.cellWidget(row, 3).setValue(100 if state in ('success', 'kept_original') else 0)

    def _result_text(self, detail):
        state = detail.get('status', 'queued')
        pieces = [tr('result_kept') if state == 'kept_original' else tr(state)]
        if detail.get('output_path'):
            pieces.append(detail['output_path'])
        if detail.get('encoder_key'):
            pieces.append(tr('enc_' + detail['encoder_key']))
        settings = detail.get('settings')
        if settings:
            pieces.append(tr('task_settings') + ': ' + self._settings_description(settings))
        if detail.get('fallback_used'):
            pieces.append(_core_message('硬件失败，已回退 CPU', 'Hardware failed; retried on CPU'))
            if detail.get('fallback_reason'):
                pieces.append(str(detail['fallback_reason']))
        if detail.get('error'):
            pieces.append(str(detail['error']))
        return '\n\n'.join(pieces)

    def show_result_details(self, row, column=0):
        if not 0 <= row < len(self.files):
            return
        detail = dict(self.results.get(row, {'status': self.files[row].get('status', 'queued')}))
        detail.setdefault('settings', self.files[row].get('settings') or self._current_settings())
        box = QMessageBox(self)
        box.setWindowTitle(tr('details'))
        box.setTextFormat(Qt.TextFormat.PlainText)
        box.setText(self._result_text(detail))
        box.exec()

    def open_output_folder(self):
        row = self.table.currentRow()
        result = self.results.get(row, {})
        if result.get('status') != 'success':
            result = next((r for r in self.results.values() if r.get('status') == 'success'), result)
        path = result.get('output_path')
        if path:
            folder = os.path.dirname(path)
        else:
            folder = self.output_edit.text()
            if not folder and self.files:
                folder = os.path.dirname(self.files[max(0, row)]['path'])
        if folder:
            QDesktopServices.openUrl(QUrl.fromLocalFile(folder))

    def on_file_done(self, index, success, output_size):
        row = self._table_row(index)
        if row not in self.results:
            self.results[row] = {'status': 'success' if success else 'failed', 'output_size': output_size}
        self._display_result(row, self.results[row])
        self._finished_indices.add(index)
        self._row_progress[index] = 100
        self._update_batch_progress()

    def on_all_done(self, completed, failed, total, input_size, output_size, was_stopped):
        # finished is the lifetime boundary, not this signal emitted from run().
        self._pending_summary = (completed, failed, total, input_size, output_size, was_stopped)

    def _on_worker_finished(self):
        finished_worker = self.worker
        self.worker = None
        if finished_worker is not None:
            finished_worker.deleteLater()
        self._queue_paused = False
        self._set_compressing(False)
        self._persist_queue()
        if self._close_pending:
            self._on_background_finished()
            return
        if self._late_rows and not self._is_importing and not self._stopping:
            rows, self._late_rows = self._late_rows, []
            self.start_compression(rows=rows)
            return
        counts = {key: sum(self.results.get(row, {}).get('status') == key for row in self._run_rows)
                  for key in ('success', 'kept_original', 'failed', 'cancelled')}
        self.progress_label.setText(tr('batch_summary').format(success=counts['success'], kept=counts['kept_original'],
                                                              failed=counts['failed'], cancelled=counts['cancelled']))
        self.total_progress.setValue(100)
        self._pending_summary = None

    def _on_background_finished(self):
        if self._close_pending:
            if self.worker and self.worker.isRunning():
                return
            if self.environment_worker and self.environment_worker.isRunning():
                return
            if self.import_worker and self.import_worker.isRunning():
                return
            self.close()

    def closeEvent(self, event):
        running = ((self.worker and self.worker.isRunning()) or (self.environment_worker and self.environment_worker.isRunning())
                   or (self.import_worker and self.import_worker.isRunning()))
        if running:
            self._close_pending = True
            self._persist_queue()
            self.setEnabled(False)
            if self.worker and self.worker.isRunning():
                self.worker.stop()
            if self.import_worker and self.import_worker.isRunning():
                self.import_worker.stop()
            event.ignore()
            return
        self._save_preferences()
        self._persist_queue()
        self.info_pool.shutdown()
        if self._queue_lock:
            self._queue_lock.unlock()
            self._queue_lock = None
            self._task_store = None
        event.accept()


# ============ 主函数 ============
def main():
    if '--self-test' in sys.argv:
        from package_self_test import run
        report = None
        if '--report' in sys.argv:
            report = sys.argv[sys.argv.index('--report') + 1]
        sys.exit(run(sys.modules[__name__], report_path=report))
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    app.setOrganizationName(APP_NAME)
    app.setApplicationName(tr('app_title'))
    app.setApplicationVersion(VERSION)
    app.setWindowIcon(QIcon(str(Path(__file__).with_name('icon.png'))))
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
