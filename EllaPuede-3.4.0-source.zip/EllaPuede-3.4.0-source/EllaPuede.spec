# Build on the target operating system with scripts/build_app.py.
import os
import platform
from pathlib import Path

root = Path(SPECPATH)
name = 'EllaPuede视频压缩工具'
version = '3.4.0'
ffmpeg_dir = Path(os.environ['ELLAPUEDE_BUILD_FFMPEG_DIR'])
suffix = '.exe' if platform.system() == 'Windows' else ''
binaries = [(str(ffmpeg_dir / (tool + suffix)), 'ffmpeg') for tool in ('ffmpeg', 'ffprobe')]
datas = [(str(root / 'THIRD_PARTY_NOTICES.txt'), '.'),
         (str(root / 'build-inputs.json'), '.')]
for filename in ('icon.png', 'icon.ico', 'icon.icns',
                 'ui-chevron.svg', 'ui-up.svg', 'ui-down.svg'):
    if not (root / filename).is_file():
        raise FileNotFoundError(f'Required UI resource is missing: {filename}')
    datas.append((str(root / filename), '.'))
license_roots = [ffmpeg_dir]
if platform.system() == 'Darwin':
    license_roots.append((ffmpeg_dir / 'ffmpeg').resolve().parent.parent)
seen_licenses = set()
for license_root in license_roots:
    for pattern in ('LICENSE*', 'COPYING*', 'ffmpeg-source.txt'):
        for path in license_root.glob(pattern):
            if path.is_file() and path.name not in seen_licenses:
                datas.append((str(path), 'ffmpeg'))
                seen_licenses.add(path.name)

a = Analysis([str(root / 'video_compressor.py')], pathex=[str(root)],
             binaries=binaries, datas=datas, hiddenimports=['package_self_test'],
             hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=[], noarchive=False)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True, name=name, debug=False,
          bootloader_ignore_signals=False, strip=False, upx=False,
          console=False, disable_windowed_traceback=False,
          icon=str(root / ('icon.icns' if platform.system() == 'Darwin' else 'icon.ico')),
          version=str(root / 'windows-version.txt') if platform.system() == 'Windows' else None)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False, name=name)
if platform.system() == 'Darwin':
    app = BUNDLE(coll, name=name + '.app', icon=str(root / 'icon.icns'),
                 bundle_identifier='com.ellapuede.videocompressor',
                 info_plist={'CFBundleShortVersionString': version,
                             'CFBundleVersion': version,
                             'CFBundleDisplayName': name,
                             'NSHighResolutionCapable': True})
