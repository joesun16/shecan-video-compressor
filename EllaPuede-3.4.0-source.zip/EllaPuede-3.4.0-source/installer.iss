; Windows x64 installer for EllaPuede Video Compressor 3.4.0.
#define AppVersion "3.4.0"
#define AppName "EllaPuede视频压缩工具"

[Setup]
; Preserve the legacy AppName identity to upgrade earlier releases in place.
AppId={#AppName}
AppName={#AppName}
AppVersion={#AppVersion}
AppPublisher=EllaPuede
VersionInfoVersion={#AppVersion}
DefaultDirName={autopf}\{#AppName}
DefaultGroupName={#AppName}
UninstallDisplayIcon={app}\{#AppName}.exe
OutputDir=installer_output
OutputBaseFilename=EllaPuede视频压缩工具_{#AppVersion}_Windows_x64_Setup
SetupIconFile=icon.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
PrivilegesRequired=lowest
CloseApplications=yes
RestartApplications=no

[Tasks]
Name: "desktopicon"; Description: "Create desktop shortcut"; GroupDescription: "Additional options:"; Flags: unchecked

[Files]
Source: "dist\{#AppName}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\{#AppName}"; Filename: "{app}\{#AppName}.exe"; WorkingDir: "{app}"
Name: "{group}\Uninstall"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#AppName}"; Filename: "{app}\{#AppName}.exe"; WorkingDir: "{app}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#AppName}.exe"; Description: "Launch EllaPuede Video Compressor"; Flags: nowait postinstall skipifsilent
