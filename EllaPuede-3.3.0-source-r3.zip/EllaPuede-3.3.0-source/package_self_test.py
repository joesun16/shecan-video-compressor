"""Packaged application end-to-end test; never uses the user's videos/settings.

Called by video_compressor.py --self-test --report <json>. It exercises the same
Qt window, hardware discovery, worker, subprocess plumbing, and bundled tools as
the interactive application. It deliberately runs without offscreen Qt so the
platform plugin and actual window creation are checked on each native runner.
"""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import traceback


def _bundle_path_status(runtime_path, bundle_root):
    """An empty PATH or absolute entries inside this bundle cannot find host tools."""
    entries = runtime_path.split(os.pathsep) if runtime_path else []
    root = Path(bundle_root).resolve()
    outside = []
    for entry in entries:
        path = Path(entry)
        # An empty segment or relative entry would implicitly search the working directory.
        if not entry or not path.is_absolute() or not path.resolve().is_relative_to(root):
            outside.append(entry)
    return entries, outside


def _check_native_layout(application, window, app_module, report_path, report):
    """Measure actual native fonts and the visible layout in both shipped languages."""
    from PyQt6.QtCore import QPoint, QRect
    from PyQt6.QtGui import QFontDatabase, QFontInfo
    from PyQt6.QtWidgets import QStyle, QStyleOptionComboBox

    original_language = app_module.get_lang()
    layouts = report.setdefault('native_layouts', [])
    report['native_font_families'] = len(QFontDatabase.families())
    if not report['native_font_families']:
        raise AssertionError('The native platform did not expose any usable font families')
    try:
        for language in ('zh', 'en'):
            window.switch_language(language)
            window.advanced_btn.setChecked(True)
            for guide in (False, True):
                window.guide_btn.setChecked(guide)
                window._toggle_guide()
                window.resize(window.minimumWidth(), window.minimumHeight())
                application.processEvents()
                central = window.centralWidget()
                screenshot = report_path.with_name(
                    f'{report_path.stem}-{language}-advanced{"-guide" if guide else ""}.png')
                detail = {'language': language, 'guide_visible': guide,
                          'width': window.width(), 'height': window.height(),
                          'font_family': QFontInfo(window.quality_combo.font()).family(),
                          'balanced_text_width': window.speed_combo.fontMetrics().horizontalAdvance('Balanced'),
                          'screenshot': screenshot.name, 'combo_labels': []}
                layouts.append(detail)

                def bounds(widget):
                    return QRect(widget.mapTo(central, QPoint(0, 0)), widget.size())

                try:
                    if not window.advanced_panel.isVisible() or window.guide_panel.isVisible() != guide:
                        raise AssertionError(f'Advanced/guide visibility is incorrect for {language}')
                    for name in ('quality_combo', 'resolution_combo', 'encoder_combo', 'speed_combo'):
                        combo = getattr(window, name)
                        selected = combo.currentIndex()
                        for index in range(combo.count()):
                            combo.setCurrentIndex(index)
                            application.processEvents()
                            option = QStyleOptionComboBox()
                            combo.initStyleOption(option)
                            field = combo.style().subControlRect(
                                QStyle.ComplexControl.CC_ComboBox, option,
                                QStyle.SubControl.SC_ComboBoxEditField, combo)
                            text_width = combo.fontMetrics().horizontalAdvance(combo.currentText())
                            detail['combo_labels'].append({
                                'control': name, 'label': combo.currentText(),
                                'available_width': field.width(), 'text_width': text_width})
                            if field.width() < text_width:
                                raise AssertionError(
                                    f'{language} {name} clips {combo.currentText()!r}: '
                                    f'{field.width()}px available, {text_width}px required')
                        combo.setCurrentIndex(selected)
                        application.processEvents()
                    sections = [window.advanced_panel, window.output_edit, window.drop_area,
                                window.add_file_btn, window.table, window.start_btn]
                    for before, after in zip(sections, sections[1:]):
                        if bounds(before).bottom() >= bounds(after).top():
                            raise AssertionError(f'Visible native sections overlap in {language}, guide={guide}')
                    if any(not central.rect().contains(bounds(widget)) for widget in sections):
                        raise AssertionError(f'Visible native section escapes the window in {language}, guide={guide}')
                    if window.table.height() < 145:
                        raise AssertionError('Advanced settings squeezed the queue below its minimum height')
                    if guide and not bounds(window.advanced_panel).contains(bounds(window.guide_panel)):
                        raise AssertionError(f'The guide escapes its advanced settings card in {language}')
                    detail['status'] = 'passed'
                finally:
                    if not window.grab().save(str(screenshot)):
                        raise AssertionError(f'Could not capture native layout: {screenshot.name}')
    finally:
        window.switch_language(original_language)
    return layouts


def run(app_module, report_path=None):
    report_path = Path(report_path or 'package-test.json').resolve()
    report_path.parent.mkdir(parents=True, exist_ok=True)
    launch_path = json.loads(os.environ.get('ELLAPUEDE_SELF_TEST_LAUNCH_PATH_JSON', 'null'))
    report = {'status': 'running', 'platform': platform.platform(),
              'architecture': platform.machine(), 'app_version': app_module.VERSION,
              'frozen': bool(getattr(sys, 'frozen', False)),
              'empty_path': not bool(os.environ.get('PATH')), 'checks': [],
              'launch_path': launch_path,
              'runtime_path': os.environ.get('PATH', ''),
              'launch_path_empty': launch_path == '',
              'clean_path': False,
              'hardware_limit': 'This run verifies only hardware present on this machine.'}
    started = time.monotonic()
    window = None

    def checked(name, details=None):
        report['checks'].append({'name': name, 'status': 'passed', 'details': details})

    def invoke(command):
        kwargs = app_module._subprocess_kwargs(timeout=60)
        result = subprocess.run(command, **kwargs)
        if result.returncode:
            raise RuntimeError(f'Command failed ({result.returncode}): {result.stderr[-4000:]}')
        return result.stdout

    def fingerprint(path):
        with path.open('rb') as stream:
            return hashlib.file_digest(stream, 'sha256').hexdigest()

    try:
        if report['frozen']:
            bundle = (Path(sys.executable).parent.parent if sys.platform == 'darwin'
                      else Path(sys.executable).parent).resolve()
            entries, outside = _bundle_path_status(report['runtime_path'], bundle)
            report.update(bundle_root=str(bundle), runtime_path_entries=entries,
                          external_runtime_path_entries=outside,
                          runtime_path_bundle_only=not outside)
            report['clean_path'] = report['launch_path_empty'] and not outside
            if not report['clean_path']:
                raise AssertionError('Packaged tests require an empty launch PATH and only bundle-local '
                                     f'runtime PATH entries; external entries: {outside!r}')
            # PyInstaller's PyQt6 Windows runtime hook legitimately prepends _MEIPASS to PATH.
            checked('isolated_runtime_path', {
                'launch_path_empty': report['launch_path_empty'],
                'runtime_path_entries': entries, 'bundle_root': str(bundle)})
        # Dependency paths must belong to this package, not a developer installation.
        ffmpeg = Path(app_module.get_ffmpeg_path()).resolve()
        ffprobe = Path(app_module.get_ffprobe_path()).resolve()
        if report['frozen']:
            for binary in (ffmpeg, ffprobe):
                if not binary.is_relative_to(bundle):
                    raise AssertionError(f'External dependency used by package: {binary}')
        report['bundled_tool_paths'] = {'ffmpeg': str(ffmpeg), 'ffprobe': str(ffprobe)}
        report['ffmpeg'] = invoke([str(ffmpeg), '-version']).splitlines()[0]
        report['ffprobe'] = invoke([str(ffprobe), '-version']).splitlines()[0]
        checked('bundled_tools_execute')
        keys = app_module.detect_available_encoders()
        if 'cpu_h264' not in keys:
            raise AssertionError(f'CPU H.264 unavailable: {keys}')
        checked('real_encoder_capability_detection', keys)

        from PyQt6.QtWidgets import QApplication
        application = QApplication.instance() or QApplication(['EllaPuede self test'])
        application.setStyle('Fusion')
        report['qt_platform'] = application.platformName()
        window = app_module.MainWindow(auto_check=False)
        window._on_environment_ready(keys, '')
        if window.available_encoder_keys != ['auto'] + keys:
            raise AssertionError('UI exposed encoders that did not pass capability checks')
        if window._selected_encoder_key() != 'auto':
            raise AssertionError('Automatic encoding is not the default')
        if (window.parallel_spin.minimum(), window.parallel_spin.maximum()) != (1, 8):
            raise AssertionError('The parallel setting must accept exactly 1–8 tasks')
        initial_parallel = window.parallel_spin.value()
        window.parallel_spin.setValue(8)
        if window._preferences().get('parallel') != 8:
            raise AssertionError('The UI did not preserve the requested parallel setting')
        window.parallel_spin.setValue(initial_parallel)
        if window.table.rowCount() != 0 or window.start_btn.isEnabled():
            raise AssertionError('An empty new window must not offer to start compression')
        checked('ui_parallel_range_and_preferences', {
            'minimum': 1, 'maximum': 8, 'default': initial_parallel})
        window.show()
        application.processEvents()
        if not window.isVisible() or window.grab().isNull():
            raise AssertionError('Main window did not render')
        screenshot = report_path.with_suffix('.png')
        if not window.grab().save(str(screenshot)):
            raise AssertionError('Could not save main-window screenshot')
        checked('qt_main_window', {'screenshot': screenshot.name,
                                   'platform_plugin': application.platformName()})
        window.quality_combo.showPopup()
        application.processEvents()
        popup_view = window.quality_combo.view()
        item_height = popup_view.visualRect(popup_view.model().index(0, 0)).height()
        if item_height < 32:
            raise AssertionError(f'Quality popup row is too cramped: {item_height}px')
        popup_image = report_path.with_name(report_path.stem + '-popup.png')
        popup_window = popup_view.window()
        if not popup_window.isVisible() or not popup_window.grab().save(str(popup_image)):
            raise AssertionError('Quality popup did not render or could not be captured')
        checked('native_quality_popup', {'screenshot': popup_image.name,
                                         'first_row_height': item_height})
        window.quality_combo.hidePopup()
        application.processEvents()
        native_layouts = _check_native_layout(application, window, app_module, report_path, report)
        checked('native_bilingual_advanced_layout', {
            'states_verified': len(native_layouts),
            'screenshots': [layout['screenshot'] for layout in native_layouts]})
        window.close()
        application.processEvents()
        window = None

        with tempfile.TemporaryDirectory(prefix='EllaPuede 压缩 测试 ') as tmp:
            base = Path(tmp)
            source = base / '输入 视频_中文 café.mp4'
            original_size = 0
            invoke([str(ffmpeg), '-hide_banner', '-y', '-f', 'lavfi', '-i',
                    'testsrc2=size=640x360:rate=24', '-f', 'lavfi', '-i',
                    'sine=frequency=1000:sample_rate=48000', '-t', '1.5',
                    '-c:v', 'libx264', '-preset', 'ultrafast', '-crf', '10',
                    '-pix_fmt', 'yuv420p', '-c:a', 'aac', str(source)])
            original_hash = fingerprint(source)
            original_size = source.stat().st_size
            checked('unicode_input_fixture', {'bytes': original_size})
            info = app_module.probe_video_info(str(source))
            if not info or info.get('duration', 0) <= 0:
                raise AssertionError(f'Input metadata probe failed: {info}')
            checked('application_metadata_probe')
            # CPU is always tested. Each available GPU is tested only after its
            # real hardware initialization has passed on this particular machine.
            candidates = ['cpu_h264'] + [k for k in keys if k != 'cpu_h264'
                                         and app_module.ENCODER_CONFIGS[k].get('is_gpu')]
            for encoder in candidates:
                output_dir = base / f'输出 files {encoder}'
                output_dir.mkdir()
                settings = {'encoder_key': encoder, 'quality_key': 'balanced',
                            'speed_key': 'fast', 'resolution': None, 'parallel': 1,
                            'output_dir': str(output_dir), 'keep_larger': True}
                item = {'path': str(source), 'name': source.name, 'size': original_size}
                worker = app_module.CompressionWorker([item], settings)
                worker.run()
                application.processEvents()
                if len(worker.results) != 1:
                    raise AssertionError(f'Worker results missing for {encoder}: {worker.results}')
                result = worker.results[0]
                if result.get('status') != 'success':
                    raise AssertionError(f'Compression failed for {encoder}: {result}')
                output = Path(result['output_path'])
                metadata = json.loads(invoke([str(ffprobe), '-v', 'error', '-show_streams',
                                               '-show_format', '-of', 'json', str(output)]))
                video = [s for s in metadata['streams'] if s['codec_type'] == 'video']
                audio = [s for s in metadata['streams'] if s['codec_type'] == 'audio']
                if not video or not audio or float(metadata['format']['duration']) <= 1:
                    raise AssertionError('Encoded file has invalid or missing streams')
                invoke([str(ffmpeg), '-v', 'error', '-i', str(output), '-f', 'null', '-'])
                if fingerprint(source) != original_hash:
                    raise AssertionError('Original input changed during compression')
                checked(f'worker_encode_decode_{encoder}', {
                    'actual_encoder': result.get('encoder_key'),
                    'fallback_used': result.get('fallback_used', False),
                    'input_bytes': original_size, 'output_bytes': output.stat().st_size,
                    'video_codec': video[0]['codec_name'], 'audio_codec': audio[0]['codec_name']})
            batch_dir = base / '八文件并行 输出'
            batch_dir.mkdir()
            batch_items = []
            for index in range(8):
                path = base / f'并行输入 {index + 1}.mp4'
                shutil.copyfile(source, path)
                batch_items.append({'path': str(path), 'name': path.name, 'size': original_size})
            batch_worker = app_module.CompressionWorker(batch_items, {
                'encoder_key': 'cpu_h264', 'quality_key': 'balanced', 'speed_key': 'fast',
                'resolution': None, 'parallel': 8, 'output_dir': str(batch_dir),
                'keep_larger': True})
            batch_worker.run()
            application.processEvents()
            if getattr(batch_worker, 'effective_parallel', None) != 8:
                raise AssertionError('The worker silently reduced the requested parallel count of 8')
            if len(batch_worker.results) != 8:
                raise AssertionError(f'Expected eight batch results: {batch_worker.results}')
            output_paths = set()
            for index, item in enumerate(batch_items):
                result = batch_worker.results[index]
                if result.get('status') != 'success':
                    raise AssertionError(f'Eight-file batch failed: {result}')
                output = Path(result['output_path'])
                if not output.is_file() or output.stat().st_size <= 0:
                    raise AssertionError(f'Batch output missing or empty: {output}')
                metadata = json.loads(invoke([str(ffprobe), '-v', 'error', '-show_streams',
                                             '-show_format', '-of', 'json', str(output)]))
                kinds = {stream['codec_type'] for stream in metadata['streams']}
                if not {'video', 'audio'} <= kinds or float(metadata['format']['duration']) <= 1:
                    raise AssertionError(f'Batch output is missing streams: {output}')
                invoke([str(ffmpeg), '-v', 'error', '-i', str(output), '-f', 'null', '-'])
                if fingerprint(Path(item['path'])) != original_hash:
                    raise AssertionError('An eight-file batch input was changed')
                output_paths.add(str(output.resolve()))
            if len(output_paths) != 8:
                raise AssertionError('Batch outputs were not assigned unique paths')
            checked('real_eight_file_batch_encode_decode', {
                'requested_parallel': 8,
                'effective_parallel': batch_worker.effective_parallel,
                'peak_parallel_processes': getattr(batch_worker, 'peak_parallel_processes', None),
                'files_verified': 8})
            checked('original_file_unchanged')
        report['status'] = 'passed'
    except Exception as exc:
        report['status'] = 'failed'
        report['error'] = f'{type(exc).__name__}: {exc}'
        report['traceback'] = traceback.format_exc()
    finally:
        if window is not None:
            window.close()
        report['elapsed_seconds'] = round(time.monotonic() - started, 2)
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    return 0 if report['status'] == 'passed' else 1
