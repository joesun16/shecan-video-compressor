#!/usr/bin/env python3
"""Run the real application executable with a clean PATH and isolated settings."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from package_self_test import _bundle_path_status


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('executable', type=Path)
    parser.add_argument('--report', type=Path, default=Path('package-test.json'))
    args = parser.parse_args()
    executable = args.executable.resolve()
    report = args.report.resolve()
    report.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='EllaPuede package 测试 ') as tmp:
        env = dict(os.environ, PATH='', ELLAPUEDE_DATA_DIR=str(Path(tmp) / 'settings'),
                   PYTHONIOENCODING='utf-8')
        # Prevent an installed Qt or Python from masking missing package components.
        for key in ('PYTHONPATH', 'PYTHONHOME', 'QT_PLUGIN_PATH', 'QT_QPA_PLATFORM_PLUGIN_PATH'):
            env.pop(key, None)
        # Record the environment actually supplied to CreateProcess, before runtime hooks run.
        env['ELLAPUEDE_SELF_TEST_LAUNCH_PATH_JSON'] = json.dumps(env['PATH'])
        bundle = (executable.parent.parent if sys.platform == 'darwin' else executable.parent).resolve()
        launch = {'executable': str(executable), 'path': env['PATH'],
                  'path_empty': env['PATH'] == '', 'bundle_root': str(bundle)}
        launch_report = report.with_name(report.stem + '-launch.json')
        launch_report.write_text(json.dumps(launch, ensure_ascii=False, indent=2), encoding='utf-8')
        # A stale successful report must never mask a failed launch.
        report.unlink(missing_ok=True)
        process = subprocess.run([str(executable), '--self-test', '--report', str(report)],
                                 cwd=tmp, env=env, timeout=240, capture_output=True)
        for stream in (process.stdout, process.stderr):
            if stream:
                print(stream.decode('utf-8', errors='replace'))
        if not report.exists():
            raise SystemExit(f'App exited {process.returncode} without a self-test report.')
        result = json.loads(report.read_text(encoding='utf-8'))
        launch['return_code'] = process.returncode
        runtime_path = result.get('runtime_path')
        entries, outside = _bundle_path_status(runtime_path, bundle) if isinstance(runtime_path, str) else ([], ['<missing runtime PATH>'])
        launch['runtime_path_bundle_only'] = not outside
        result['launcher'] = launch
        # Verify using our actual launch env and executable location, not only child assertions.
        verified = (launch['path_empty'] and result.get('frozen') is True
                    and result.get('launch_path') == env['PATH']
                    and isinstance(result.get('bundle_root'), str)
                    and Path(result['bundle_root']).is_absolute()
                    and Path(result['bundle_root']).resolve() == bundle
                    and result.get('runtime_path_entries') == entries and not outside)
        result['clean_path'] = result.get('clean_path') is True and verified
        if not result['clean_path']:
            result.update(status='failed', launcher_error='Empty launch PATH / bundle-only runtime PATH verification failed')
        report.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
        launch_report.write_text(json.dumps(launch, ensure_ascii=False, indent=2), encoding='utf-8')
        print(json.dumps(result, ensure_ascii=False, indent=2))
        if process.returncode != 0 or result.get('status') != 'passed':
            raise SystemExit(f'Packaged self-test failed: return code {process.returncode}')


if __name__ == '__main__':
    main()
